#!/usr/bin/env python3
"""
카메라 화면에서 수면 테두리를 찍어 솥 회전축의 로봇 base x, y 를 구한다.

    ./measure_kettle_axis.sh                      카메라를 띄우고 창을 연다 (권장)
    ./measure_kettle_axis.sh --snapshot out.png   창 없이 한 장 받아 겹쳐 그린 그림만 저장
    python3 measure_kettle_axis.py --apply        저장된 측정값을 kettle_profile.yaml 에 다시 넣는다
    python3 measure_kettle_axis.py --self-test    카메라 없이 계산 검증
    python3 measure_kettle_axis.py --image frame.png --intrinsics fx fy cx cy [--points "u,v u,v"] [--no-window --out o.png]

원리
  평면 보정(plane_calibration.yaml)은 수면 높이의 평면에서 픽셀 → 로봇 x, y 호모그래피를 학습했다.
  국물 100 L 의 수면이 벽과 만나는 선은 바로 그 평면 위의 원(CAD 반경 474.1 mm)이므로,
  그 선을 여러 곳 클릭하면 시차 없이 로봇 좌표의 점들이 되고, 원을 맞추면 중심이 솥 축이다.
  결과는 호모그래피 기준으로 저장한다. 로봇 파이프라인이 음식 좌표를 같은 호모그래피로 구하므로
  벽 근처 음식과 솥 축이 같은 변환을 공유한다.

  림(테두리)은 수면보다 161 mm 높아서 비스듬한 카메라에서는 시차가 크다. 클릭하지 말 것.

  PnP 확인: 같은 보정점으로 카메라 내부 파라미터 K 를 고정하고 자세만 맞춘 물리적 카메라 모델로
  같은 클릭을 한 번 더 맞춘다. 호모그래피는 화면 가운데 보정점 영역 밖에서 외삽 오차가 커질 수 있는데,
  보정점이 없는 가장자리에서는 어느 쪽이 맞는지 알 수 없다. 그래서 두 축의 차이를 불확실성으로 보여준다.
  CAD 림 원도 이 PnP 카메라로 겹쳐 그린다 (참고용).

창 조작 (화면 글자는 영어)
  왼쪽 클릭    수면이 벽과 만나는 점 추가         오른쪽 클릭  가까운 점 삭제
  u / x        마지막 점 취소 / 전부 지우기       f            영상 멈춤 · 재생
  m            CAD 반경 고정 ↔ 반경 자유 맞춤     i k / j l    중심을 로봇 +x −x / +y −y 로 1 mm (대문자 5 mm)
  0            미세 조정 초기화                   r / g        림 참고 원 / 로봇 좌표 격자 표시
  s            저장 (측정 기록 + kettle_profile.yaml 의 축 위치)       q, Esc      끝내기

저장 결과
  kettle_axis_measurement.yaml   클릭한 점, 맞춤 결과, PnP 확인, 보정 · 카메라 정보
  kettle_axis_measurement.png    겹쳐 그린 화면
  kettle_profile.yaml            placement.axis_xy_in_base_m 과 axis_xy_source 만 바꾼다
                                 (extract_profile.py 를 다시 돌리면 비워지므로 --apply 로 다시 넣는다)
"""

import argparse
import datetime as dt
import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import yaml
from scipy.optimize import least_squares

sys.dont_write_bytecode = True

HERE = Path(__file__).resolve().parent
WS = next(p for p in HERE.parents if (p / 'src' / 'RIA_kettle').is_dir())   # 워크스페이스 (이 폴더 위치와 무관)
PROFILE_YAML = HERE / 'kettle_profile.yaml'
CALIBRATION_YAML = WS / 'src' / 'RIA_calibration' / 'config' / 'plane_calibration.yaml'
MEASUREMENT_YAML = HERE / 'kettle_axis_measurement.yaml'
MEASUREMENT_PNG = HERE / 'kettle_axis_measurement.png'
WINDOW = 'kettle axis - click where the WATER meets the WALL'

# 평면 보정 모듈은 ROS 에 의존하지 않는다. 고치지 않고 가져다 쓴다.
sys.path.insert(0, str(WS / 'src' / 'RIA_calibration'))
from ria_calibration.plane_homography import base_to_pixel, pixel_to_base, undistort_pixel  # noqa: E402

MIN_POINTS = 5
MIN_COVERAGE_DEG = 120.0
MAX_RMS_MM = 5.0
MAX_RADIUS_DIFF_MM = 20.0
MAX_PNP_DIFF_MM = 15.0
PANEL_WIDTH = 330        # 영상 오른쪽 글자 패널 폭 [px]. 글자가 수면선을 가리지 않게 영상 밖에 둔다
PANEL_CHARS = 42


# -- 입력 --------------------------------------------------------------------

@dataclass
class PlaneCalibration:
    H: np.ndarray
    surface_z: float
    undistort: bool
    rms_m: float
    samples_uv: np.ndarray
    samples_xyz: np.ndarray
    path: Path

    @classmethod
    def load(cls, path=CALIBRATION_YAML):
        doc = yaml.safe_load(Path(path).read_text(encoding='utf-8'))['plane_calibrator']['ros__parameters']
        if not doc.get('calibrated', False):
            raise SystemExit(f'평면 보정이 되어 있지 않습니다: {path}')
        samples = doc.get('samples', [])
        uv = np.array([[s['u'], s['v']] for s in samples], dtype=float).reshape(-1, 2)
        xyz = np.array([[s['x'], s['y'], s.get('z', doc['cooking_surface_z'])] for s in samples], dtype=float).reshape(-1, 3)
        return cls(np.array(doc['homography'], dtype=float).reshape(3, 3), float(doc['cooking_surface_z']),
                   bool(doc.get('undistort_applied', True)), float(doc.get('calibration_rms_error_m', -1.0)),
                   uv, xyz, Path(path))


@dataclass
class KettleCad:
    surface_radius_m: float
    level_h_m: float
    rim_top_r_m: float
    rim_top_h_m: float
    soup_volume_L: float

    @classmethod
    def load(cls, path=PROFILE_YAML):
        doc = yaml.safe_load(Path(path).read_text(encoding='utf-8'))
        op, summary = doc['operating'], doc['summary']
        return cls(float(op['surface_radius_m']), float(op['level_h_m']), float(summary['rim_top_r_m']),
                   float(summary['rim_top_h_m']), float(op['soup_volume_L']))


# -- 카메라 기하 ----------------------------------------------------------------

def distort_pixel(u, v, K, D):
    """undistort_pixel 의 반대. 이상적 픽셀 → 실제(왜곡된) 픽셀. plumb_bob 모델."""
    D = np.asarray(D, dtype=float).ravel()
    if D.size == 0 or not np.any(D):
        return float(u), float(v)
    k1, k2, p1, p2 = D[:4]
    k3 = D[4] if D.size > 4 else 0.0
    fx, fy, cx, cy = K[0, 0], K[1, 1], K[0, 2], K[1, 2]
    x, y = (u - cx) / fx, (v - cy) / fy
    r2 = x * x + y * y
    radial = 1.0 + k1 * r2 + k2 * r2 * r2 + k3 * r2 ** 3
    xd = x * radial + 2 * p1 * x * y + p2 * (r2 + 2 * x * x)
    yd = y * radial + p1 * (r2 + 2 * y * y) + 2 * p2 * x * y
    return float(xd * fx + cx), float(yd * fy + cy)


@dataclass
class PnpCamera:
    """K 를 고정하고 보정점으로 자세만 맞춘 물리적 카메라. R 은 로봇 base → 카메라."""
    R: np.ndarray
    position: np.ndarray
    reprojection_rms_px: float
    plane_rms_m: float
    height_above_surface_m: float
    tilt_deg: float


class CameraGeometry:
    """픽셀 ↔ 수면 평면(로봇 x, y). 호모그래피가 기준이고, K 가 있으면 PnP 카메라로도 계산한다."""

    def __init__(self, calib, K=None, D=None):
        self.calib = calib
        self.K = None if K is None else np.asarray(K, dtype=float).reshape(3, 3)
        self.D = np.zeros(5) if D is None else np.asarray(D, dtype=float).ravel()
        self._H_inv = np.linalg.inv(calib.H)
        ref = calib.samples_xyz[:, :2].mean(axis=0) if len(calib.samples_xyz) else np.array([0.0, 0.0])
        self._w_sign = np.sign((self._H_inv @ np.array([ref[0], ref[1], 1.0]))[2])
        self.pnp = self._solve_pnp()

    def _ideal(self, u, v):
        if self.calib.undistort and self.K is not None:
            return undistort_pixel(u, v, self.K, self.D)
        return float(u), float(v)

    def _real(self, u, v):
        if self.calib.undistort and self.K is not None:
            return distort_pixel(u, v, self.K, self.D)
        return float(u), float(v)

    def _solve_pnp(self):
        if self.K is None or len(self.calib.samples_uv) < 6:
            return None
        import cv2
        uv = np.array([self._ideal(u, v) for u, v in self.calib.samples_uv], dtype=float)
        xyz = self.calib.samples_xyz
        ok, rvec, tvec = cv2.solvePnP(xyz, uv, self.K, None, flags=cv2.SOLVEPNP_ITERATIVE)
        if not ok:
            return None
        ok, rvec, tvec = cv2.solvePnP(xyz, uv, self.K, None, rvec, tvec, useExtrinsicGuess=True,
                                      flags=cv2.SOLVEPNP_ITERATIVE)
        R, _ = cv2.Rodrigues(rvec)
        position = (-R.T @ tvec).ravel()
        proj = (self.K @ (R @ (xyz - position).T)).T
        proj = proj[:, :2] / proj[:, 2:3]
        camera = PnpCamera(R, position, float(np.sqrt(np.mean(np.sum((proj - uv) ** 2, axis=1)))), 0.0,
                           float(position[2] - self.calib.surface_z),
                           float(np.degrees(np.arccos(np.clip(-R.T[2, 2], -1.0, 1.0)))))
        self.pnp = camera
        plane = np.array([self.pixel_to_plane_pnp(u, v, z) for (u, v), z in zip(self.calib.samples_uv, xyz[:, 2])])
        camera.plane_rms_m = float(np.sqrt(np.mean(np.sum((plane - xyz[:, :2]) ** 2, axis=1))))
        return camera

    # 호모그래피 (기준)
    def pixel_to_plane(self, u, v):
        return np.array(pixel_to_base(self.calib.H, *self._ideal(u, v)))

    def plane_to_pixel(self, x, y):
        p = self._H_inv @ np.array([x, y, 1.0])
        if abs(p[2]) < 1e-12 or np.sign(p[2]) != self._w_sign:
            return None                                    # 수평선 너머 (카메라 뒤쪽)
        u, v = base_to_pixel(self.calib.H, x, y)
        return self._real(u, v)

    # PnP 카메라 (확인용)
    def pixel_to_plane_pnp(self, u, v, z=None):
        cam = self.pnp
        z = self.calib.surface_z if z is None else z
        ray = cam.R.T @ (np.linalg.inv(self.K) @ np.array([*self._ideal(u, v), 1.0]))
        s = (z - cam.position[2]) / ray[2]
        return (cam.position + s * ray)[:2]

    def point_to_pixel(self, point):
        cam = self.pnp
        if cam is None:
            return None
        c = cam.R @ (np.asarray(point, dtype=float) - cam.position)
        if c[2] <= 1e-6:
            return None
        uv = self.K @ (c / c[2])
        return self._real(uv[0], uv[1])


# -- 원 맞춤 --------------------------------------------------------------------

@dataclass
class CircleFit:
    center: np.ndarray
    radius: float
    residuals: np.ndarray
    coverage_deg: float
    center_sigma_m: float
    fixed_radius: bool

    @property
    def rms_m(self):
        return float(np.sqrt(np.mean(self.residuals ** 2)))

    @property
    def max_abs_m(self):
        return float(np.abs(self.residuals).max())

    def to_doc(self):
        return {
            'center_xy_m': [float(self.center[0]), float(self.center[1])],
            'radius_m': float(self.radius),
            'rms_mm': round(self.rms_m * 1000, 2), 'max_mm': round(self.max_abs_m * 1000, 2),
            'coverage_deg': round(self.coverage_deg, 1),
            'center_sigma_mm': None if not np.isfinite(self.center_sigma_m) else round(self.center_sigma_m * 1000, 2),
            'residuals_mm': [round(float(r) * 1000, 2) for r in self.residuals],
        }


def coverage_deg(points, center):
    """점들이 원 둘레를 덮는 각도 = 360° − 가장 큰 빈틈."""
    angles = np.sort(np.arctan2(points[:, 1] - center[1], points[:, 0] - center[0]))
    gaps = np.diff(np.r_[angles, angles[0] + 2 * np.pi])
    return float(360.0 - np.degrees(gaps.max()))


def _center_sigma(result, n_params):
    r = result.fun
    if len(r) <= n_params:
        return float('nan')
    s2 = float(r @ r) / (len(r) - n_params)
    try:
        cov = np.linalg.inv(result.jac.T @ result.jac) * s2
    except np.linalg.LinAlgError:
        return float('nan')
    return float(np.sqrt(max(np.linalg.eigvalsh(cov[:2, :2]).max(), 0.0)))


def fit_free(points):
    """반경까지 맞춘다. 점 3개 이상."""
    if len(points) < 3:
        return None
    x, y = points[:, 0], points[:, 1]
    sol, *_ = np.linalg.lstsq(np.c_[2 * x, 2 * y, np.ones(len(x))], x * x + y * y, rcond=None)
    c0 = sol[:2]
    r0 = np.sqrt(max(sol[2] + c0 @ c0, 1e-12))
    if not np.all(np.isfinite([*c0, r0])):
        return None
    res = least_squares(lambda p: np.hypot(x - p[0], y - p[1]) - p[2], [c0[0], c0[1], r0])
    center = res.x[:2]
    return CircleFit(center, float(abs(res.x[2])), res.fun, coverage_deg(points, center), _center_sigma(res, 3), False)


def fit_fixed(points, radius, init=None):
    """반경을 고정하고 중심만 맞춘다. 점 3개 이상."""
    if len(points) < 3:
        return None
    x, y = points[:, 0], points[:, 1]
    start = points.mean(axis=0) if init is None else np.asarray(init, dtype=float)
    res = least_squares(lambda p: np.hypot(x - p[0], y - p[1]) - radius, start)
    return CircleFit(res.x.copy(), float(radius), res.fun, coverage_deg(points, res.x), _center_sigma(res, 2), True)


# -- 측정 상태 · 그리기 ------------------------------------------------------------

def draw_polyline(img, points, color, thickness=1, dashed=False):
    import cv2
    h, w = img.shape[:2]

    def ok(p):
        return p is not None and -w < p[0] < 2 * w and -h < p[1] < 2 * h
    for i in range(len(points) - 1):
        a, b = points[i], points[i + 1]
        if ok(a) and ok(b) and (not dashed or i % 2 == 0):
            cv2.line(img, (int(round(a[0])), int(round(a[1]))), (int(round(b[0])), int(round(b[1]))),
                     color, thickness, cv2.LINE_AA)


def put_text(img, text, org, color=(255, 255, 255), scale=0.5):
    import cv2
    cv2.putText(img, text, org, cv2.FONT_HERSHEY_SIMPLEX, scale, (0, 0, 0), 3, cv2.LINE_AA)
    cv2.putText(img, text, org, cv2.FONT_HERSHEY_SIMPLEX, scale, color, 1, cv2.LINE_AA)


def _wrap(text, width):
    lines, line = [], ''
    for word in text.split():
        if line and len(line) + 1 + len(word) > width:
            lines.append(line)
            line = '  ' + word
        else:
            line = f'{line} {word}' if line else word
    return lines + ([line] if line else [])


class AxisMeasurement:
    def __init__(self, geometry, cad, radius_m=None):
        self.geometry = geometry
        self.cad = cad
        self.radius_m = float(radius_m) if radius_m else cad.surface_radius_m
        self.points_uv = []
        self.use_fixed = True
        self.offset = np.zeros(2)
        self.show_rim = True
        self.show_grid = False
        self.message = ''
        self._key = None
        self._fits = (None, None, None)
        samples = geometry.calib.samples_uv
        self._hull = None
        if len(samples) >= 3:
            import cv2
            self._hull = cv2.convexHull(samples.astype(np.float32))

    # 점
    def add_point(self, u, v):
        self.points_uv.append((float(u), float(v)))

    def delete_near(self, u, v, tol_px=15.0):
        if not self.points_uv:
            return
        d = [np.hypot(u - p[0], v - p[1]) for p in self.points_uv]
        i = int(np.argmin(d))
        if d[i] <= tol_px:
            self.points_uv.pop(i)

    def base_points(self):
        return np.array([self.geometry.pixel_to_plane(u, v) for u, v in self.points_uv], dtype=float).reshape(-1, 2)

    def base_points_pnp(self):
        return np.array([self.geometry.pixel_to_plane_pnp(u, v) for u, v in self.points_uv], dtype=float).reshape(-1, 2)

    def outside_calibrated_area(self):
        if self._hull is None:
            return 0
        import cv2
        return sum(cv2.pointPolygonTest(self._hull, (u, v), True) < -10 for u, v in self.points_uv)

    # 맞춤
    def fits(self):
        """(반경 자유, CAD 반경 고정, PnP 로 본 CAD 반경 고정)."""
        key = tuple(self.points_uv)
        if key != self._key:
            points = self.base_points()
            free = fit_free(points)
            init = free.center if free is not None and abs(free.radius - self.radius_m) < self.radius_m else None
            fixed = fit_fixed(points, self.radius_m, init)
            pnp = None
            if self.geometry.pnp is not None and fixed is not None:
                pnp = fit_fixed(self.base_points_pnp(), self.radius_m, fixed.center)
            self._key, self._fits = key, (free, fixed, pnp)
        return self._fits

    def selected(self):
        free, fixed, _ = self.fits()
        fit = fixed if self.use_fixed else free
        if fit is None:
            return None, None
        return fit, fit.center + self.offset

    def pnp_difference_m(self):
        _, fixed, pnp = self.fits()
        if fixed is None or pnp is None:
            return None
        return float(np.hypot(*(fixed.center - pnp.center)))

    def warnings(self):
        out = []
        free, fixed, _ = self.fits()
        fit, _ = self.selected()
        if len(self.points_uv) < MIN_POINTS:
            out.append(f'add at least {MIN_POINTS} points spread around the pot')
        if fit is not None and fit.coverage_deg < MIN_COVERAGE_DEG:
            out.append(f'points cover only {fit.coverage_deg:.0f} deg of the circle: spread them wider')
        if fit is not None and fit.rms_m * 1000 > MAX_RMS_MM:
            out.append(f'rms {fit.rms_m * 1000:.1f} mm: some clicks may be off the waterline')
        if free is not None and abs(free.radius - self.radius_m) * 1000 > MAX_RADIUS_DIFF_MM:
            out.append(f'free radius differs from CAD by {(free.radius - self.radius_m) * 1000:+.0f} mm '
                       '(waterline, not the rim?)')
        n_out = self.outside_calibrated_area()
        if n_out:
            out.append(f'{n_out} point(s) outside the calibrated area: less accurate')
        diff = self.pnp_difference_m()
        if diff is not None and diff * 1000 > MAX_PNP_DIFF_MM:
            out.append(f'homography vs PnP axis differ by {diff * 1000:.0f} mm: calibration does not cover the waterline')
        return out

    # 그리기
    def draw(self, frame, frozen=False):
        import cv2
        img = frame.copy()
        g = self.geometry
        if self._hull is not None:
            cv2.polylines(img, [self._hull.astype(np.int32)], True, (170, 170, 170), 1, cv2.LINE_AA)
            top = self._hull[:, 0, :][np.argmin(self._hull[:, 0, 1])]
            put_text(img, 'calibrated area', (int(top[0]) - 40, int(top[1]) - 6), (200, 200, 200), 0.4)
        if self.show_grid:
            for x in np.arange(0.3, 1.41, 0.1):
                draw_polyline(img, [g.plane_to_pixel(x, y) for y in np.linspace(-0.7, 0.7, 80)], (0, 170, 0))
            for y in np.arange(-0.6, 0.61, 0.1):
                draw_polyline(img, [g.plane_to_pixel(x, y) for x in np.linspace(0.2, 1.5, 80)], (200, 110, 0))

        free, fixed, pnp = self.fits()
        fit, center = self.selected()
        t = np.linspace(0, 2 * np.pi, 241)
        for other, is_selected in ((free, not self.use_fixed), (fixed, self.use_fixed)):
            if other is None:
                continue
            c = other.center + (self.offset if is_selected else 0.0)
            pts = [g.plane_to_pixel(c[0] + other.radius * np.cos(a), c[1] + other.radius * np.sin(a)) for a in t]
            draw_polyline(img, pts, (80, 230, 80) if is_selected else (0, 220, 255), 2 if is_selected else 1,
                          dashed=not is_selected)

        if center is not None:
            cp = g.plane_to_pixel(*center)
            if cp is not None:
                u, v = int(round(cp[0])), int(round(cp[1]))
                cv2.drawMarker(img, (u, v), (80, 230, 80), cv2.MARKER_CROSS, 18, 2)
                for d, label in (((0.08, 0.0), '+x'), ((0.0, 0.08), '+y')):
                    tip = g.plane_to_pixel(center[0] + d[0], center[1] + d[1])
                    if tip is not None:
                        cv2.arrowedLine(img, (u, v), (int(round(tip[0])), int(round(tip[1]))), (80, 230, 80), 1,
                                        cv2.LINE_AA, tipLength=0.2)
                        put_text(img, label, (int(round(tip[0])) + 3, int(round(tip[1]))), (80, 230, 80), 0.45)
        if self.show_rim and pnp is not None:
            z_rim = g.calib.surface_z + (self.cad.rim_top_h_m - self.cad.level_h_m)
            c = pnp.center
            rim = [g.point_to_pixel((c[0] + self.cad.rim_top_r_m * np.cos(a), c[1] + self.cad.rim_top_r_m * np.sin(a),
                                     z_rim)) for a in t]
            draw_polyline(img, rim, (0, 150, 255), 1, dashed=True)
            visible = [p for p in rim if p is not None and 0 <= p[0] < img.shape[1] and 0 <= p[1] < img.shape[0]]
            if visible:
                top = min(visible, key=lambda p: p[1])
                put_text(img, 'CAD rim (PnP camera, reference)', (int(top[0]) - 110, int(top[1]) - 8), (0, 150, 255), 0.4)

        for i, (u, v) in enumerate(self.points_uv):
            cv2.circle(img, (int(round(u)), int(round(v))), 4, (255, 0, 255), -1, cv2.LINE_AA)
            label = f'{i + 1}'
            if fit is not None and i < len(fit.residuals):
                label += f' {fit.residuals[i] * 1000:+.0f}'
            put_text(img, label, (int(round(u)) + 6, int(round(v)) - 6), (255, 160, 255), 0.4)

        return self._with_panel(img, frozen)

    def _with_panel(self, img, frozen):
        """영상 오른쪽에 글자 패널을 붙인다. 클릭은 영상 영역에서만 받는다."""
        import cv2
        free, fixed, pnp = self.fits()
        white, gray, green = (255, 255, 255), (175, 175, 175), (80, 230, 80)
        yellow, orange, cyan = (0, 220, 255), (0, 170, 255), (255, 200, 120)
        rows = [('KETTLE AXIS', white), ('click where the WATER meets the WALL', gray), ('(not the rim)', gray),
                (f'points {len(self.points_uv)}' + ('   [FROZEN]' if frozen else ''), white), ('', white)]
        for title, other, is_selected, color in (('CAD radius', fixed, self.use_fixed, green),
                                                 ('free radius', free, not self.use_fixed, yellow)):
            if other is None:
                continue
            c = other.center + (self.offset if is_selected else 0.0)
            sigma = '' if not np.isfinite(other.center_sigma_m) else f'   sigma {other.center_sigma_m * 1000:.1f} mm'
            rows += [(f'{">" if is_selected else " "} {title} {other.radius * 1000:.1f} mm', color),
                     (f'   axis x {c[0]:+.4f}  y {c[1]:+.4f}', color),
                     (f'   rms {other.rms_m * 1000:.1f}  max {other.max_abs_m * 1000:.1f} mm', color),
                     (f'   cover {other.coverage_deg:.0f} deg{sigma}', color)]
        if pnp is not None:
            rows += [('  PnP check (uncertainty)', cyan),
                     (f'   axis x {pnp.center[0]:+.4f}  y {pnp.center[1]:+.4f}', cyan),
                     (f'   diff {self.pnp_difference_m() * 1000:.0f} mm   reproj {self.geometry.pnp.reprojection_rms_px:.1f} px', cyan)]
        if np.any(self.offset):
            rows.append((f'  offset dx {self.offset[0] * 1000:+.0f}  dy {self.offset[1] * 1000:+.0f} mm', white))
        warnings = self.warnings()
        if warnings:
            rows += [('', white), ('WARNINGS', orange)]
            for w in warnings:
                rows += [(line, orange) for line in _wrap('- ' + w, PANEL_CHARS)]
        if self.message:
            rows += [('', white)] + [(line, green) for line in _wrap(self.message, PANEL_CHARS)]
        rows += [('', white), ('KEYS', gray)] + [(k, gray) for k in (
            'L-click add     R-click delete', 'u undo   x clear   f freeze', 'm CAD / free radius',
            'i k  +x -x     j l  +y -y   (caps x5)', '0 reset offset   r rim   g grid', 's save     q quit')]

        h, w = img.shape[:2]
        canvas = np.full((max(h, 16 + 16 * len(rows)), w + PANEL_WIDTH, 3), 32, dtype=np.uint8)
        canvas[:h, :w] = img
        for i, (text, color) in enumerate(rows):
            cv2.putText(canvas, text, (w + 10, 20 + i * 16), cv2.FONT_HERSHEY_SIMPLEX, 0.42, color, 1, cv2.LINE_AA)
        return canvas

    # 기록
    def document(self, image_size):
        free, fixed, pnp = self.fits()
        fit, center = self.selected()
        g, c = self.geometry, self.geometry.calib
        cam = g.pnp
        return {
            'measured_at': dt.datetime.now().isoformat(timespec='seconds'),
            'method': '카메라 화면에서 수면이 벽과 만나는 점을 클릭 → 평면 보정 호모그래피로 로봇 x, y → 원 맞춤',
            'calibration': {
                'file': str(c.path), 'cooking_surface_z_m': c.surface_z,
                'calibration_rms_error_m': c.rms_m, 'undistort_applied': c.undistort,
                'sample_count': int(len(c.samples_uv)),
            },
            'camera': {
                'image_size': list(image_size),
                'K': None if g.K is None else g.K.ravel().tolist(), 'D': g.D.tolist(),
            },
            'cad': {'soup_volume_L': self.cad.soup_volume_L, 'waterline_radius_m': self.radius_m},
            'clicks': {
                'pixels_uv': [list(p) for p in self.points_uv],
                'base_xy_m': self.base_points().tolist(),
                'outside_calibrated_area': int(self.outside_calibrated_area()),
            },
            'fits': {
                'cad_radius': None if fixed is None else fixed.to_doc(),
                'free_radius': None if free is None else free.to_doc(),
            },
            'selected': 'cad_radius' if self.use_fixed else 'free_radius',
            'manual_offset_m': self.offset.tolist(),
            'pnp_check': None if cam is None else {
                'note': 'K 고정, 보정점으로 자세만 맞춘 카메라로 같은 클릭을 CAD 반경 고정으로 맞춘 결과. 차이가 곧 불확실성.',
                'reprojection_rms_px': round(cam.reprojection_rms_px, 2),
                'calibration_plane_rms_mm': round(cam.plane_rms_m * 1000, 2),
                'camera_position_m': cam.position.tolist(),
                'height_above_surface_m': cam.height_above_surface_m,
                'tilt_deg': round(cam.tilt_deg, 2),
                'axis_xy_m': None if pnp is None else pnp.center.tolist(),
                'axis_difference_mm': None if self.pnp_difference_m() is None else round(self.pnp_difference_m() * 1000, 1),
            },
            'result': {
                'axis_xy_in_base_m': None if center is None else [float(center[0]), float(center[1])],
                'warnings': self.warnings(),
            },
        }


# -- 저장 · 적용 -----------------------------------------------------------------

def _source_note(doc):
    fit = doc['fits'][doc['selected']]
    kind = 'CAD 반경 고정' if doc['selected'] == 'cad_radius' else '반경 자유'
    sigma = '' if fit['center_sigma_mm'] is None else f", 중심 1σ {fit['center_sigma_mm']} mm"
    offset = np.asarray(doc['manual_offset_m'], dtype=float) * 1000
    manual = '' if not np.any(offset) else f', 수동 조정 ({offset[0]:+.0f}, {offset[1]:+.0f}) mm'
    pnp = doc.get('pnp_check') or {}
    check = '' if pnp.get('axis_difference_mm') is None else f", PnP 확인과 차이 {pnp['axis_difference_mm']} mm"
    return (f"카메라 수면 테두리 {len(doc['clicks']['pixels_uv'])}점 · {kind} 원 맞춤 · RMS {fit['rms_mm']} mm · "
            f"둘레 {fit['coverage_deg']}°{sigma}{check}{manual} ({doc['measured_at']}). {MEASUREMENT_YAML.name} 참고.")


def apply_to_profile(axis_xy, note, path=PROFILE_YAML):
    """kettle_profile.yaml 의 placement.axis_xy_in_base_m 과 axis_xy_source 만 바꾼다."""
    from extract_profile import write_yaml
    path = Path(path)
    text = path.read_text(encoding='utf-8')
    header = []
    for line in text.splitlines():
        if not line.startswith('#'):
            break
        header.append(line[2:] if line.startswith('# ') else line[1:].strip())
    doc = yaml.safe_load(text)
    old = doc.get('placement') or {}
    placement = {}
    value = [float(axis_xy[0]), float(axis_xy[1])]
    for key, item in old.items():
        if key == 'axis_xy_source':
            continue
        placement[key] = value if key == 'axis_xy_in_base_m' else item
        if key == 'axis_xy_in_base_m':
            placement['axis_xy_source'] = note
    if 'axis_xy_in_base_m' not in old:
        placement = {'axis_xy_in_base_m': value, 'axis_xy_source': note, **placement}
    doc['placement'] = placement
    write_yaml(path, header, doc)


def save_measurement(tool, frame, frozen=False):
    import cv2
    from extract_profile import write_yaml
    fit, center = tool.selected()
    if center is None:
        return None
    doc = tool.document(frame.shape[1::-1])
    write_yaml(MEASUREMENT_YAML, ['measure_kettle_axis.py 가 저장한 측정 기록.',
                                  'python3 measure_kettle_axis.py --apply 로 kettle_profile.yaml 에 다시 넣을 수 있다.'], doc)
    cv2.imwrite(str(MEASUREMENT_PNG), tool.draw(frame, frozen))
    apply_to_profile(center, _source_note(doc))
    return doc


def print_summary(tool):
    free, fixed, pnp = tool.fits()
    fit, center = tool.selected()
    print(f'\n클릭한 점 {len(tool.points_uv)}개')
    for name, other in (('CAD 반경 고정', fixed), ('반경 자유', free), ('PnP 확인', pnp)):
        if other is not None:
            print(f'  {name:10s} 반경 {other.radius * 1000:6.1f} mm  축 ({other.center[0]:+.4f}, {other.center[1]:+.4f}) m  '
                  f'RMS {other.rms_m * 1000:.1f} mm  최대 {other.max_abs_m * 1000:.1f} mm  둘레 {other.coverage_deg:.0f}°')
    if center is not None:
        print(f'  선택: {"CAD 반경 고정" if tool.use_fixed else "반경 자유"} → 축 ({center[0]:+.4f}, {center[1]:+.4f}) m')
    diff = tool.pnp_difference_m()
    if diff is not None:
        print(f'  호모그래피 ↔ PnP 축 차이 {diff * 1000:.1f} mm (측정 불확실성의 대략적인 크기)')
    for w in tool.warnings():
        print(f'  ! {w}')


# -- 창 --------------------------------------------------------------------------

def run_window(get_tool, next_frame, spin=None):
    """get_tool(): 준비되면 AxisMeasurement, 아니면 None. next_frame(): 최신 영상 또는 None."""
    import cv2
    cv2.namedWindow(WINDOW, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(WINDOW, int((640 + PANEL_WIDTH) * 1.6), int(480 * 1.6))
    holder = {'tool': None, 'frozen': None, 'width': None}

    def on_mouse(event, x, y, flags, param):
        tool = holder['tool']
        if tool is None or holder['width'] is None or x >= holder['width']:
            return                                         # 오른쪽 글자 패널 클릭은 무시
        if event == cv2.EVENT_LBUTTONDOWN:
            tool.add_point(x, y)
            tool.message = ''
        elif event == cv2.EVENT_RBUTTONDOWN:
            tool.delete_near(x, y)
    cv2.setMouseCallback(WINDOW, on_mouse)

    while True:
        if spin is not None:
            spin()
        holder['tool'] = holder['tool'] or get_tool()
        tool = holder['tool']
        frame = holder['frozen'] if holder['frozen'] is not None else next_frame()
        holder['width'] = None if frame is None else frame.shape[1]
        if tool is None or frame is None:
            blank = np.zeros((480, 640, 3), dtype=np.uint8)
            put_text(blank, 'waiting for camera image and camera_info ...', (20, 240))
            cv2.imshow(WINDOW, blank)
        else:
            cv2.imshow(WINDOW, tool.draw(frame, holder['frozen'] is not None))

        key = cv2.waitKey(15) & 0xFF
        if key in (ord('q'), 27):
            break
        if cv2.getWindowProperty(WINDOW, cv2.WND_PROP_VISIBLE) < 1:
            break
        if tool is None or key == 255:
            continue
        step = 0.005 if chr(key).isupper() else 0.001
        nudges = {'i': (step, 0.0), 'k': (-step, 0.0), 'j': (0.0, step), 'l': (0.0, -step)}
        if chr(key).lower() in nudges:
            tool.offset += np.array(nudges[chr(key).lower()])
        elif key == ord('u') and tool.points_uv:
            tool.points_uv.pop()
        elif key == ord('x'):
            tool.points_uv.clear()
        elif key == ord('0'):
            tool.offset[:] = 0.0
        elif key == ord('m'):
            tool.use_fixed = not tool.use_fixed
            tool.offset[:] = 0.0
        elif key == ord('r'):
            tool.show_rim = not tool.show_rim
        elif key == ord('g'):
            tool.show_grid = not tool.show_grid
        elif key == ord('f'):
            holder['frozen'] = None if holder['frozen'] is not None else (None if frame is None else frame.copy())
        elif key == ord('s'):
            if frame is None:
                continue
            doc = save_measurement(tool, frame, holder['frozen'] is not None)
            if doc is None:
                tool.message = 'need at least 3 points to save'
            else:
                axis = doc['result']['axis_xy_in_base_m']
                tool.message = f'saved: axis x {axis[0]:+.4f} y {axis[1]:+.4f} -> kettle_profile.yaml'
                print(f'\n저장: {MEASUREMENT_YAML.name}, {MEASUREMENT_PNG.name}, {PROFILE_YAML.name} (placement.axis_xy_in_base_m)')
                print(f'  축 ({axis[0]:+.4f}, {axis[1]:+.4f}) m')
    cv2.destroyAllWindows()
    return holder['tool']


def run_ros(args, calib, cad):
    import rclpy
    from cv_bridge import CvBridge
    from rclpy.node import Node
    from rclpy.qos import qos_profile_sensor_data
    from sensor_msgs.msg import CameraInfo, Image

    class CameraFeed(Node):
        def __init__(self):
            super().__init__('kettle_axis_measure')
            self.bridge = CvBridge()
            self.frame = None
            self.K = self.D = self.size = None
            # 영상은 BEST_EFFORT, camera_info 는 기본 QoS 로 받아야 realsense2_camera 와 맞는다.
            self.create_subscription(Image, args.image_topic, self._on_image, qos_profile_sensor_data)
            self.create_subscription(CameraInfo, args.info_topic, self._on_info, 10)

        def _on_image(self, msg):
            self.frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')

        def _on_info(self, msg):
            if self.K is None:
                self.K = np.array(msg.k, dtype=float).reshape(3, 3)
                self.D = np.array(msg.d, dtype=float)
                self.size = (msg.width, msg.height)

    rclpy.init()
    feed = CameraFeed()
    tool_box = {}

    def get_tool():
        if 'tool' not in tool_box and feed.K is not None:
            if feed.size != (640, 480):
                print(f'! camera_info 해상도 {feed.size} 가 보정 때(640x480)와 다릅니다. 좌표가 틀어집니다.')
            tool = AxisMeasurement(CameraGeometry(calib, feed.K, feed.D), cad, args.radius_mm and args.radius_mm / 1000)
            for p in parse_points(args.points):
                tool.add_point(*p)
            tool_box['tool'] = tool
        return tool_box.get('tool')

    try:
        if args.snapshot:
            import cv2
            import time
            deadline = time.time() + 30
            while (feed.frame is None or feed.K is None) and time.time() < deadline:
                rclpy.spin_once(feed, timeout_sec=0.1)
            for _ in range(10):
                rclpy.spin_once(feed, timeout_sec=0.05)
            tool = get_tool()
            if tool is None or feed.frame is None:
                raise SystemExit(f'영상을 받지 못했습니다: {args.image_topic}')
            cv2.imwrite(args.snapshot, tool.draw(feed.frame))
            print(f'저장: {args.snapshot}')
            print_summary(tool)
            return
        tool = run_window(get_tool, lambda: feed.frame, lambda: rclpy.spin_once(feed, timeout_sec=0.0))
        if tool is not None:
            print_summary(tool)
    finally:
        feed.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


def parse_points(text):
    if not text:
        return []
    return [tuple(float(v) for v in item.split(',')) for item in text.replace(';', ' ').split()]


# -- 자체 점검 --------------------------------------------------------------------

def self_test(calib, cad):
    import tempfile
    results = []

    def report(name, ok, detail):
        results.append(bool(ok))
        print(f'  [{"OK" if ok else "FAIL"}] {name}: {detail}')

    # 2026-09-13 realsense2_camera 의 camera_info (640x480). 계산 검증에만 쓴다.
    K = np.array([[606.53, 0.0, 311.57], [0.0, 606.04, 251.44], [0.0, 0.0, 1.0]])
    D_test = np.array([0.08, -0.15, 0.001, -0.0015, 0.05])
    err = max(np.hypot(*(np.array(undistort_pixel(*distort_pixel(u, v, K, D_test), K, D_test)) - (u, v)))
              for u, v in [(10, 10), (320, 240), (630, 470), (100, 400)])
    report('왜곡 적용 ↔ 제거 왕복', err < 1e-3, f'최대 {err:.2e} px (가상 왜곡계수)')

    g = CameraGeometry(calib, K, np.zeros(5))
    err = max(np.hypot(*(g.pixel_to_plane(*g.plane_to_pixel(x, y)) - (x, y))) for x, y in [(0.7, 0.0), (0.9, -0.2), (0.6, 0.25)])
    report('수면 평면 ↔ 픽셀 왕복 (호모그래피)', err < 1e-9, f'최대 {err:.2e} m')

    cam = g.pnp
    report('PnP 카메라가 보정점을 재투영', cam is not None and cam.reprojection_rms_px < 5.0,
           'PnP 실패' if cam is None else
           f'RMS {cam.reprojection_rms_px:.2f} px, 평면 RMS {cam.plane_rms_m * 1000:.2f} mm, '
           f'수면 위 {cam.height_above_surface_m:.3f} m, 기울기 {cam.tilt_deg:.1f}°')
    err = max(np.hypot(*(np.array(g.point_to_pixel((*g.pixel_to_plane_pnp(u, v), calib.surface_z))) - (u, v)))
              for u, v in [(80, 300), (320, 240), (520, 300), (300, 450)])
    report('PnP 픽셀 → 수면 평면 → 픽셀 왕복', err < 1e-6, f'최대 {err:.2e} px')

    rng = np.random.default_rng(0)
    truth = np.array([0.52, 0.08])
    angles = np.radians(np.linspace(-40, 170, 9))
    pixels = []
    for a in angles:
        uv = g.plane_to_pixel(truth[0] + cad.surface_radius_m * np.cos(a), truth[1] + cad.surface_radius_m * np.sin(a))
        if uv is not None:
            pixels.append(np.round(np.array(uv) + rng.normal(0, 0.7, 2)))
    tool = AxisMeasurement(g, cad)
    for p in pixels:
        tool.add_point(*p)
    free, fixed, _ = tool.fits()
    e_fixed = np.hypot(*(fixed.center - truth)) * 1000
    report('가상 수면선 클릭(픽셀 반올림 + 잡음 0.7 px) → CAD 반경 고정 맞춤', e_fixed < 5.0,
           f'점 {len(pixels)}개, 축 오차 {e_fixed:.2f} mm, 둘레 {fixed.coverage_deg:.0f}°, 1σ {fixed.center_sigma_m * 1000:.2f} mm')
    report('같은 점 → 반경 자유 맞춤', abs(free.radius - cad.surface_radius_m) * 1000 < 10.0,
           f'반경 오차 {(free.radius - cad.surface_radius_m) * 1000:+.2f} mm, 축 오차 {np.hypot(*(free.center - truth)) * 1000:.2f} mm')

    pixels = [g.point_to_pixel((truth[0] + cad.surface_radius_m * np.cos(a), truth[1] + cad.surface_radius_m * np.sin(a),
                                calib.surface_z)) for a in angles]
    tool = AxisMeasurement(g, cad)
    for p in pixels:
        if p is not None:
            tool.add_point(*p)
    _, _, pnp = tool.fits()
    report('PnP 카메라로 만든 가상 클릭 → PnP 확인 맞춤이 축을 되찾음', np.hypot(*(pnp.center - truth)) < 1e-6,
           f'축 오차 {np.hypot(*(pnp.center - truth)) * 1000:.4f} mm')

    with tempfile.TemporaryDirectory() as tmp:
        copy = Path(tmp) / 'kettle_profile.yaml'
        copy.write_text(PROFILE_YAML.read_text(encoding='utf-8'), encoding='utf-8')
        before = yaml.safe_load(copy.read_text(encoding='utf-8'))
        apply_to_profile((0.5123, -0.0456), '자체 점검', copy)
        after = yaml.safe_load(copy.read_text(encoding='utf-8'))
        same = all(before[k] == after[k] for k in before if k != 'placement')
        placement_ok = (after['placement']['axis_xy_in_base_m'] == [0.5123, -0.0456]
                        and after['placement']['bottom_z_in_base_m'] == before['placement']['bottom_z_in_base_m']
                        and copy.read_text(encoding='utf-8').startswith('# '))
        report('kettle_profile.yaml 적용 (임시 사본): placement 축만 바뀐다', same and placement_ok,
               f'다른 섹션 동일 {same}, 축 · 바닥 z · 머리 주석 {placement_ok}')

    probes = {'화면 가운데': (320, 240), '왼쪽 가운데': (80, 300), '오른쪽 가운데': (520, 300), '오른쪽 아래': (500, 460)}
    print('  [정보] 같은 픽셀에서 호모그래피 ↔ PnP 수면 좌표 차이 (보정점이 없는 곳일수록 커진다)')
    for name, (u, v) in probes.items():
        d = np.hypot(*(g.pixel_to_plane(u, v) - g.pixel_to_plane_pnp(u, v))) * 1000
        print(f'         {name:8s} ({u:3d},{v:3d})  {d:6.1f} mm')
    return all(results)


# -- 진입점 ----------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description='카메라 화면의 수면 테두리로 솥 축(로봇 x, y)을 구한다.')
    parser.add_argument('--apply', action='store_true', help='저장된 측정값을 kettle_profile.yaml 에 다시 넣는다')
    parser.add_argument('--self-test', action='store_true', help='카메라 없이 계산 검증')
    parser.add_argument('--snapshot', metavar='PNG', help='(ROS) 창 없이 한 장 받아 겹쳐 그린 그림 저장')
    parser.add_argument('--image', metavar='PNG', help='(오프라인) 저장된 영상으로 연다')
    parser.add_argument('--intrinsics', nargs=4, type=float, metavar=('FX', 'FY', 'CX', 'CY'),
                        help='--image 와 함께. 없으면 마지막 측정 기록의 K')
    parser.add_argument('--points', help='미리 넣을 클릭 점 "u,v u,v ..."')
    parser.add_argument('--no-window', action='store_true', help='--image 와 함께: 창 없이 --out 으로 저장')
    parser.add_argument('--out', metavar='PNG', help='--no-window 결과 그림')
    parser.add_argument('--radius-mm', type=float, help='수면 원 반경 (기본: kettle_profile.yaml 의 100 L 수면 반경)')
    parser.add_argument('--image-topic', default='/camera/camera/color/image_raw')
    parser.add_argument('--info-topic', default='/camera/camera/color/camera_info')
    args = parser.parse_args()

    calib = PlaneCalibration.load()
    cad = KettleCad.load()

    if args.apply:
        if not MEASUREMENT_YAML.exists():
            raise SystemExit(f'{MEASUREMENT_YAML.name} 가 없습니다. 먼저 측정해서 저장하세요.')
        doc = yaml.safe_load(MEASUREMENT_YAML.read_text(encoding='utf-8'))
        axis = doc['result']['axis_xy_in_base_m']
        apply_to_profile(axis, _source_note(doc))
        print(f'적용: {PROFILE_YAML.name} placement.axis_xy_in_base_m = ({axis[0]:+.4f}, {axis[1]:+.4f}) m')
        return 0

    if args.self_test:
        print('자체 점검')
        return 0 if self_test(calib, cad) else 1

    if args.image:
        import cv2
        frame = cv2.imread(args.image)
        if frame is None:
            raise SystemExit(f'영상을 읽지 못했습니다: {args.image}')
        K = None
        if args.intrinsics:
            fx, fy, cx, cy = args.intrinsics
            K = np.array([[fx, 0, cx], [0, fy, cy], [0, 0, 1.0]])
        elif MEASUREMENT_YAML.exists():
            saved = yaml.safe_load(MEASUREMENT_YAML.read_text(encoding='utf-8'))['camera']['K']
            K = None if saved is None else np.array(saved).reshape(3, 3)
        tool = AxisMeasurement(CameraGeometry(calib, K), cad, args.radius_mm and args.radius_mm / 1000)
        for p in parse_points(args.points):
            tool.add_point(*p)
        if args.no_window:
            out = args.out or 'kettle_axis_preview.png'
            cv2.imwrite(out, tool.draw(frame))
            print(f'저장: {out}')
        else:
            tool = run_window(lambda: tool, lambda: frame)
        print_summary(tool)
        return 0

    run_ros(args, calib, cad)
    return 0


if __name__ == '__main__':
    sys.exit(main())
