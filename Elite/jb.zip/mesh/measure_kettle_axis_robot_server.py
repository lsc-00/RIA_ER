#!/usr/bin/env python3
"""measure_kettle_axis_robot의 비차단 RTSI 웹 서버 진입점.

Elite SDK 연결이 Python GIL을 오래 잡을 수 있어 RTSI는 별도 프로세스에서 읽는다.
로봇이 꺼져 있거나 네트워크가 끊겨도 Flask 화면과 API는 즉시 응답한다.
"""

import argparse
import math
import multiprocessing as mp
import os
import queue
import threading
import time

from measure_kettle_axis_robot import (
    AxisConfig,
    MeasurementSession,
    RTSI_INPUT_RECIPE,
    RTSI_OUTPUT_RECIPE,
    create_app,
    load_profile,
    self_test,
)


def _send_latest(messages, item):
    try:
        messages.put_nowait(item)
        return
    except queue.Full:
        pass
    try:
        messages.get_nowait()
    except queue.Empty:
        pass
    try:
        messages.put_nowait(item)
    except queue.Full:
        pass


def _rtsi_worker(robot_ip, frequency_hz, messages, stop_event):
    """자식 프로세스에서만 Elite SDK를 연결하고 TCP를 읽는다."""
    import elite_cs_sdk as cs

    while not stop_event.is_set():
        io = None
        try:
            _send_latest(messages, ('status', time.monotonic(),
                                     f'RTSI 연결 중: {robot_ip}:30004'))
            io = cs.RtsiIOInterface(
                str(RTSI_OUTPUT_RECIPE), str(RTSI_INPUT_RECIPE), frequency_hz)
            if not io.connect(robot_ip):
                raise ConnectionError(f'RTSI 연결 실패: {robot_ip}:30004')
            while not stop_event.is_set():
                pose = [float(v) for v in io.getActualTCPPose()]
                if len(pose) != 6 or not all(math.isfinite(v) for v in pose):
                    raise RuntimeError(f'유효하지 않은 actual_TCP_pose: {pose}')
                _send_latest(messages, ('pose', time.monotonic(), pose))
                stop_event.wait(1.0 / max(frequency_hz, 1.0))
        except Exception as exc:
            _send_latest(messages, ('error', time.monotonic(), str(exc)))
        finally:
            if io is not None:
                try:
                    io.disconnect()
                except Exception:
                    pass
        stop_event.wait(1.0)


class ProcessRtsiPoseReader:
    """RTSI 자식 프로세스가 보낸 최신 TCP를 Flask에 비차단으로 제공한다."""

    def __init__(self, robot_ip, frequency_hz=20.0, stale_after_sec=1.0):
        self.robot_ip = robot_ip
        self.frequency_hz = float(frequency_hz)
        self.stale_after_sec = float(stale_after_sec)
        context = mp.get_context('spawn')
        self._messages = context.Queue(maxsize=4)
        self._stop = context.Event()
        self._process = context.Process(
            target=_rtsi_worker,
            args=(robot_ip, self.frequency_hz, self._messages, self._stop),
            daemon=True)
        self._lock = threading.Lock()
        self._latest_pose = None
        self._latest_at = 0.0
        self._message = 'RTSI 연결 준비 중'

    def start(self):
        if not self._process.is_alive():
            self._process.start()

    def _drain(self):
        while True:
            try:
                kind, timestamp, value = self._messages.get_nowait()
            except queue.Empty:
                break
            if kind == 'pose':
                self._latest_pose = list(value)
                self._latest_at = float(timestamp)
                self._message = ''
            else:
                self._message = str(value)
                if kind == 'error':
                    self._latest_pose = None

    def read_pose(self):
        with self._lock:
            self._drain()
            pose = None if self._latest_pose is None else list(self._latest_pose)
            age = time.monotonic() - self._latest_at
            message = self._message
        if pose is None or age > self.stale_after_sec:
            raise ConnectionError(message or 'RTSI TCP 자세가 1초 이상 갱신되지 않았습니다.')
        return pose

    def close(self):
        self._stop.set()
        if self._process.is_alive():
            self._process.join(timeout=1.0)
        if self._process.is_alive():
            self._process.terminate()
            self._process.join(timeout=1.0)
        self._messages.close()


def main():
    parser = argparse.ArgumentParser(
        description='로봇 TCP 접촉점으로 솥 중심의 base x, y를 측정하는 읽기 전용 웹 도구')
    parser.add_argument('--ip', default=os.environ.get('ROBOT_IP', '192.168.0.100'))
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=5001)
    parser.add_argument('--probe-radius-mm', type=float, default=0.0,
                        help='구형 프로브 반경. 뾰족한 TCP 포인터는 0')
    parser.add_argument('--wall-radius-mm', type=float,
                        help='측정 높이의 CAD 내벽 반경. 기본은 100 L 수면 반경')
    parser.add_argument('--z-m', type=float,
                        help='측정할 base z. 기본은 100 L 수면 높이')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()

    if args.self_test:
        print('로봇 TCP 솥 중심 측정 자체 점검')
        return 0 if self_test() else 1

    profile_radius, profile_z = load_profile()
    config = AxisConfig(
        args.ip,
        profile_radius if args.wall_radius_mm is None else args.wall_radius_mm / 1000,
        args.probe_radius_mm / 1000,
        profile_z if args.z_m is None else args.z_m)
    config.validate()
    reader = ProcessRtsiPoseReader(args.ip)
    reader.start()
    session = MeasurementSession(config)
    app = create_app(reader, session)
    print('로봇 TCP 솥 중심 측정 웹 화면')
    print(f'  http://{args.host}:{args.port}')
    print(f'  로봇: {args.ip}:30004 (RTSI 읽기 전용)')
    print(f'  기준 z: {config.expected_z_m:.6f} m')
    print(f'  CAD 벽 반경: {config.cad_wall_radius_m * 1000:.2f} mm')
    print(f'  프로브 반경: {config.probe_radius_m * 1000:.2f} mm')
    print('  주의: 접촉 전에 조그 동작을 완전히 정지하세요.')
    try:
        app.run(host=args.host, port=args.port, debug=False, threaded=True)
    finally:
        reader.close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
