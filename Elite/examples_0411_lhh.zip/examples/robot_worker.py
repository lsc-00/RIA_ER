# robot_worker.py
# UI와 완전히 분리된 멀티프로세싱 워커입니다.
# cmd_queue에서 명령을 받아 robot_controller에 전달하고,
# 결과를 log_queue를 통해 UI로 전송합니다.

def robot_worker(cmd_queue, log_queue):
    from robot_controller import RobotController

    def log_callback(msg):
        log_queue.put(("LOG", msg))

    robot = RobotController(log_callback)

    while True:
        try:
            cmd_data = cmd_queue.get()
            if cmd_data is None:
                break

            task_type, params = cmd_data

            if task_type == "BOOTING":
                log_callback("시스템 부팅 중...")
                if robot.dashboard_power_on():
                    log_callback("준비완료")
                    log_queue.put(("BOOT_SUCCESS", None))
                    cmd_queue.put(("HOME", None))
                else:
                    log_callback("❌ 부팅 실패")
                    log_queue.put(("BOOT_FAILED", None))

            elif task_type == "RESTART":
                robot.dashboard_power_off()
                log_callback("🔄 시스템 초기화 및 재부팅 중...")
                cmd_queue.put(("BOOTING", None))

            elif task_type == "SHUTDOWN":
                robot.dashboard_power_off()
                log_queue.put(("SHUTDOWN_DONE", None))
                break

            else:
                log_queue.put(("TASK_START", task_type))
                if not robot.connect_primary():
                    log_callback("❌ 로봇 연결 실패")
                    log_queue.put(("TASK_END", task_type))
                    continue
                try:
                    if   task_type == "INIT":      robot.run_init_pose()
                    elif task_type == "STIR":      robot.run_stirring(params)
                    elif task_type == "SCOOP":     robot.run_scooping(params)
                    elif task_type == "SHAKE":     robot.run_shaking(params)
                    elif task_type == "DISCHARGE": robot.run_discharge(params)
                    elif task_type == "ALL":       robot.run_integrated_test(params)
                    elif task_type == "HOME":      robot.run_home_pose()
                except Exception as ex:
                    log_callback(f"⚠️ 에러: {ex}")
                finally:
                    robot.disconnect_primary()
                    log_queue.put(("TASK_END", task_type))

        except Exception as e:
            log_callback(f"⚠️ 워커 에러: {e}")