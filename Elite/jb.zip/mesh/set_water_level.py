#!/usr/bin/env python3
"""
지금 수면 높이를 재서 src/RIA_kettle/config/water_level.yaml 에 넣는다. 로봇에 명령을 보내지 않는다 (TCP 읽기만).

    python3 set_water_level.py                          지금 설정 보기 (수면 z · 부피 · 수면 반경 · 최근 기록)
    python3 set_water_level.py --from-robot             로봇 TCP z 를 읽어 보여 주기만
    python3 set_water_level.py --from-robot --apply     읽은 z 를 저장
    python3 set_water_level.py --z -0.225 --apply       펜던트에서 읽은 값을 직접
    python3 set_water_level.py --volume 80 --apply      부피로 (솥 CAD 모델로 계산 — 실측보다 부정확)
    python3 set_water_level.py --design --apply         설계 수위 100 L 로 되돌리기 (null)
    python3 set_water_level.py --self-test

재는 법
  스쿱 가운데 검은 테이프(= 펜던트 TCP) 가 물 표면에 막 닿게 조그한 뒤 --from-robot.
  로봇의 TCP 오프셋이 robot_runtime.yaml 과 다르면 저장하지 않는다 (오프셋이 0 이면 플랜지 높이를 읽어 약 450 mm 틀린다).
저장하면
  계획기 · run_target_motion · click_target_motion 은 다음 실행부터, food_motion_node · pixel_to_base_node 는 다시 시작할 때 반영.
  이전 값은 history 에 남는다 (증발 · 음식 넣은 뒤 수위 변화 추적).
"""

import argparse
import datetime as dt
import sys
import tempfile
from pathlib import Path

import numpy as np
import yaml

sys.dont_write_bytecode = True

from runtime_config import RT, tcp_offset  # noqa: E402  (ria_kettle 경로를 잡는다)

from ria_kettle import KettleModel, find_config  # noqa: E402
from ria_kettle.kettle_model import WATER_FILE, read_water_level  # noqa: E402

HISTORY_MAX = 20
LARGE_CHANGE_M = 0.05          # 지금 값과 이보다 크게 다르면 한 번 더 확인하라고 알림
HEADER = """\
# water_level.yaml — 지금 수면 높이 (물을 채우거나 줄면 바뀌는 값). 계획 설정(zone_motion.yaml)과 따로 둔다.
# 재서 넣기: python3 ~/cs612_ws/src/vendor/dev_log/jb/mesh/set_water_level.py --from-robot --apply
#   (스쿱 가운데 검은 테이프 = 펜던트 TCP 가 물 표면에 막 닿게 조그한 뒤). 손으로 고쳐도 된다.
# 읽는 곳 (KettleModel.from_yaml 기본): 계획기 zone_motion · target_policy, run_target_motion · click_target_motion (클릭 좌표도 이 높이),
#   food_motion_node · pixel_to_base_node 의 수면 원 · 발행 z (노드는 시작할 때 읽음). 소스 트리 파일을 바로 읽어 빌드 불필요.
#
# 항목 (set_water_level.py 가 다시 쓰면 이 머리말은 그대로 두고 아래 값만 바꾼다)
#   surface_z_in_base_m  지금 수면의 로봇 base z [m] = 표식(TCP)이 물 표면에 닿을 때의 TCP z.
#                        null = kettle_profile.yaml 설계 수위 (100 L, z −0.150)
#   measured_at          잰 시각
#   method               잰 방법: robot_tcp (로봇에서 읽음) · manual (직접 입력) · volume (부피로 계산) · design (설계 수위로 되돌림)
#   note                 메모 (예: 튀김 넣은 뒤)
#   history              이전 값들 (최근 것이 위, 20개까지) — 증발 · 음식 넣은 뒤 수위 변화 추적

"""


def summary(kettle, z):
    """수면 z 한 줄 설명 (설계 수위 모델 기준으로 계산)."""
    bottom = float(kettle.placement['bottom_z_in_base_m'])
    level = z - bottom
    radius = float(kettle.wall_radius(level))
    rc = float(yaml.safe_load(find_config('zone_motion.yaml').read_text(encoding='utf-8'))['zones']['center_radius_m'])
    return (f'수면 z {z:+.4f} m · 바닥 위 {level * 1000:.1f} mm · 약 {float(kettle.volume_L(level)):.1f} L · '
            f'수면 반경 {radius * 1000:.0f} mm (가운데 구역 {rc * 100:.0f} cm 밖 가장자리 폭 {(radius - rc) * 100:.1f} cm)')


def write_water_level(path, z, method, note='', previous=None, now=None):
    """water_level.yaml 을 쓴다. previous(이전 문서)의 값은 history 맨 앞으로."""
    previous = previous or {}
    history = list(previous.get('history') or [])
    if 'surface_z_in_base_m' in previous:
        history.insert(0, {k: previous.get(k) for k in ('surface_z_in_base_m', 'measured_at', 'method', 'note')})
    now = now or dt.datetime.now()
    body = {'surface_z_in_base_m': None if z is None else round(float(z), 4),
            'measured_at': now.strftime('%Y-%m-%d %H:%M'), 'method': method, 'note': note,
            'history': history[:HISTORY_MAX]}
    Path(path).write_text(HEADER + yaml.safe_dump(body, allow_unicode=True, sort_keys=False, default_flow_style=None),
                          encoding='utf-8')


def read_from_robot(ip):
    """(TCP z, 설명). TCP 오프셋이 설정과 다르면 SystemExit."""
    from check_tcp_offset import read_robot
    pose, offset = read_robot(ip, 1500)
    expected = np.asarray(tcp_offset())
    gap = np.abs(np.asarray(offset) - expected)
    if (np.linalg.norm(gap[:3]) > float(RT.checks.tcp_offset_tolerance_m)
            or np.degrees(gap[3:]).max() > float(RT.checks.tcp_offset_tolerance_deg)):
        raise SystemExit(f'로봇 TCP 오프셋 {np.round(np.asarray(offset[:3]) * 1000, 1).tolist()} mm 가 설정 '
                         f'{np.round(expected[:3] * 1000, 1).tolist()} mm 와 달라 표식 높이가 아닙니다. 펜던트 TCP 먼저 확인.')
    return float(pose[2]), f'로봇 TCP (x {pose[0]:+.3f}, y {pose[1]:+.3f}, z {pose[2]:+.4f})'


def self_test():
    ok = True

    def check(name, good):
        nonlocal ok
        ok &= bool(good)
        print(f'  [{"OK" if good else "FAIL"}] {name}')

    design = KettleModel.from_yaml(water_surface_z=None)
    bottom = float(design.placement['bottom_z_in_base_m'])
    z52 = bottom + float(design.level_for_volume(52.0))
    k = KettleModel.from_yaml(water_surface_z=z52)
    check(f'수면 z {z52:+.3f} → 약 {float(k.volume_L(k.level_h)):.1f} L, 수면 반경 {k.surface_radius * 1000:.0f} mm '
          f'(설계 100 L {design.surface_radius * 1000:.0f} mm)',
          abs(float(k.volume_L(k.level_h)) - 52.0) < 0.1 and k.surface_radius < design.surface_radius
          and abs(k.surface_z_in_base - z52) < 1e-9)
    try:
        KettleModel.from_yaml(water_surface_z=bottom + 0.01)
        check('바닥 바로 위 수면 z 는 거부', False)
    except ValueError:
        check('바닥 바로 위 수면 z 는 거부', True)
    with tempfile.TemporaryDirectory() as d:
        p = Path(d) / WATER_FILE
        write_water_level(p, -0.150, 'manual', 'first')
        _, first = read_water_level(p)
        write_water_level(p, -0.225, 'robot_tcp', '', first)
        z, doc = read_water_level(p)
        check('저장 → 읽기, 이전 값은 history 로, 머리 설명 유지',
              z == -0.225 and doc['history'][0]['surface_z_in_base_m'] == -0.15 and p.read_text(encoding='utf-8').startswith('# water_level.yaml'))
        write_water_level(p, None, 'design', '', doc)
        z, doc = read_water_level(p)
        check('설계 수위로 되돌리기 (null)', z is None and len(doc['history']) == 2)
    from ria_kettle.zone_motion import ZoneMotionPlanner
    z, _ = read_water_level()
    planner = ZoneMotionPlanner.from_yaml()
    expect = design.surface_z_in_base if z is None else z
    check(f'계획기가 {WATER_FILE} 을 따라감 ({planner.surface_source})', abs(planner.surface_z - expect) < 1e-9)
    return 0 if ok else 1


def main():
    parser = argparse.ArgumentParser(description='지금 수면 높이를 재서 water_level.yaml 에 넣는다 (로봇은 읽기만).')
    how = parser.add_mutually_exclusive_group()
    how.add_argument('--from-robot', action='store_true', help='로봇 TCP z 를 읽는다 (테이프가 물 표면에 닿은 상태)')
    how.add_argument('--z', type=float, help='수면 z [m, 로봇 base] 직접')
    how.add_argument('--volume', type=float, metavar='L', help='부피로 (솥 CAD 모델 계산, 실측보다 부정확)')
    how.add_argument('--design', action='store_true', help='설계 수위 100 L 로 되돌림 (null)')
    parser.add_argument('--apply', action='store_true', help='water_level.yaml 에 저장')
    parser.add_argument('--note', default='', help='메모 (예: "튀김 넣은 뒤")')
    parser.add_argument('--ip', default=RT.robot.ip)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        return self_test()

    path = find_config(WATER_FILE)
    design = KettleModel.from_yaml(water_surface_z=None)
    current, doc = read_water_level(path)
    print(f'설정 파일: {path}')
    if current is None:
        print('지금: 설계 수위 (null) · ' + summary(design, design.surface_z_in_base))
    else:
        print(f'지금: {summary(design, current)} · {doc.get("measured_at")} {doc.get("method")} {doc.get("note") or ""}'.rstrip())
    for h in (doc.get('history') or [])[:5]:
        print(f'  이전: z {h.get("surface_z_in_base_m")} · {h.get("measured_at")} {h.get("method")} {h.get("note") or ""}'.rstrip())

    if args.from_robot:
        z, where = read_from_robot(args.ip)
        method = 'robot_tcp'
        print(f'읽음: {where}')
    elif args.z is not None:
        z, method = args.z, 'manual'
    elif args.volume is not None:
        level = float(design.level_for_volume(args.volume))
        if not np.isfinite(level):
            raise SystemExit(f'{args.volume} L 는 벽 끝까지 부피({design.max_volume_L:.0f} L)보다 많습니다.')
        z, method = float(design.placement['bottom_z_in_base_m']) + level, 'volume'
    elif args.design:
        z, method = None, 'design'
    else:
        return 0

    if z is not None:
        try:
            KettleModel.from_yaml(water_surface_z=z)
        except ValueError as exc:
            raise SystemExit(f'저장하지 않음: {exc}')
        print('새 값: ' + summary(design, z))
        if current is not None and abs(z - current) > LARGE_CHANGE_M:
            print(f'주의: 지금 값보다 {(z - current) * 1000:+.0f} mm — 테이프가 물에 닿은 상태에서 읽었는지 확인')
    else:
        print('새 값: 설계 수위 (null) · ' + summary(design, design.surface_z_in_base))
    if not args.apply:
        print('--apply 가 없어 저장하지 않았습니다.')
        return 0
    write_water_level(path, z, method, args.note, doc)
    print(f'저장: {path}\n  계획 도구는 다음 실행부터, food_motion_node · pixel_to_base_node 는 다시 시작할 때 반영.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
