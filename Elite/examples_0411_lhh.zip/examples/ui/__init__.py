# ui/__init__.py
from ui.app import build_ui