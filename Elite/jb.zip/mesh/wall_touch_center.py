#!/usr/bin/env python3
"""
스쿱 테두리를 솥 벽 네 방향에 대고 TCP(스쿱 표식)를 기록해 솥 중심 x, y 를 구한다. 로봇에 명령을 보내지 않는다.

    python3 wall_touch_center.py far       먼 쪽(+X) 벽에 닿았을 때 기록
    python3 wall_touch_center.py near      가까운 쪽(-X, 로봇 쪽)
    python3 wall_touch_center.py left      로봇에서 솥을 볼 때 왼쪽(+Y)
    python3 wall_touch_center.py right     오른쪽(-Y)
    python3 wall_touch_center.py show      기록 · 계산 결과 보기
    python3 wall_touch_center.py apply     계산한 중심을 kettle_profile.yaml 에 넣기
    python3 wall_touch_center.py clear     기록 지우기
    python3 wall_touch_center.py --self-test

두 가지 방식 (기록된 손목 방향으로 자동 판단)
  같은 테두리 점 방식 (권장)
    테두리의 한 점에 테이프로 표시하고, 표식(TCP)을 지나는 수직축으로 손목을 90° 씩 돌려
    그 점이 매번 벽을 향하게 한 뒤 댄다. 표식이 테두리 원 중심에서 벗어나 있어도 평균에서 정확히 상쇄된다.
    필요 조건: 스쿱 수평 유지, 회전축이 표식을 지남 (TCP 제자리 회전 시험으로 확인).
  고정 자세 방식
    손목을 돌리지 않고 네 벽에 댄다. 테두리 원 중심이 표식과 일치할 때만 정확하다.

  어느 방식이든 같은 높이에서 마주 보는 두 벽의 표식 위치 평균이 솥 중심이다.
      중심 X = (far.x + near.x) / 2,   중심 Y = (left.y + right.y) / 2

조건 (show 에서 검사)
  - 네 점의 TCP z 차이 5 mm 이하
  - 수직축 회전을 뺀 자세 차이 2° 이하 (도구 축이 기울어 있어도 손목과 함께 돌았으면 괜찮음)
  - 손목 방향: 모두 같거나(고정 방식), far/near · left/right 는 180°, far/left 는 90° 차이 (±5°)
  - far/near 의 y, left/right 의 x 가 서로 비슷할 것 (벽에 수직으로 다가갔는지)

기록 파일: wall_touch_points.yaml
"""

import argparse
import datetime as dt
import sys
from pathlib import Path

import numpy as np
import yaml

sys.dont_write_bytecode = True

HERE = Path(__file__).resolve().parent
RECORD = HERE / 'wall_touch_points.yaml'
LABELS = {'far': '먼 쪽 (+X)', 'near': '가까운 쪽 (-X)', 'left': '왼쪽 (+Y)', 'right': '오른쪽 (-Y)'}
WALL_DIR_DEG = {'far': 0.0, 'left': 90.0, 'near': 180.0, 'right': -90.0}   # 솥 중심에서 본 벽 방향 (로봇 base)
MAX_Z_SPREAD_M = 0.005
MAX_TILT_SPREAD_DEG = 2.0
YAW_TOL_DEG = 5.0
MAX_CROSS_M = 0.05


def load():
    if RECORD.exists():
        return yaml.safe_load(RECORD.read_text(encoding='utf-8')) or {}
    return {}


def save(doc):
    RECORD.write_text('# wall_touch_center.py 가 기록한 벽 짚기 TCP. 단위 m, 자세는 RPY rad.\n'
                      + yaml.safe_dump(doc, allow_unicode=True, sort_keys=False), encoding='utf-8')


def _matrix(pose):
    from check_tcp_offset import rpy_to_matrix
    return rpy_to_matrix(pose[3:])


def _rz(deg):
    a = np.radians(deg)
    return np.array([[np.cos(a), -np.sin(a), 0.0], [np.sin(a), np.cos(a), 0.0], [0.0, 0.0, 1.0]])


def tilt_spread_deg(poses):
    """수직축 회전을 뺀 자세끼리의 최대 각도 차이 [deg].

    같은 자세를 수직축으로만 돌렸으면 0 이다. 도구 축이 연직에서 기울어 있어도 그 기울기가
    손목과 함께 돌았으면 (벽에 대한 스쿱 모양이 같으면) 0 으로 본다.
    """
    local = [_rz(-yaw_deg(p)) @ _matrix(p) for p in poses]
    return max(float(np.degrees(np.arccos(np.clip((np.trace(a @ b.T) - 1.0) / 2.0, -1.0, 1.0))))
               for a in local for b in local)


def tilt_from_vertical_deg(pose):
    return float(np.degrees(np.arccos(np.clip(-_matrix(pose)[2, 2], -1.0, 1.0))))


def yaw_deg(pose):
    """도구 x 축의 수평 방향 [deg]."""
    x = _matrix(pose)[:, 0]
    return float(np.degrees(np.arctan2(x[1], x[0])))


def wrap_deg(d):
    return (d + 180.0) % 360.0 - 180.0


def check_orientation(points, have, msgs, problems):
    poses = [points[k] for k in have]
    tilt = tilt_spread_deg(poses)
    vertical = [tilt_from_vertical_deg(p) for p in poses]
    msgs.append(f'수직축 회전을 뺀 자세 차이 최대 {tilt:.2f}° (기준 {MAX_TILT_SPREAD_DEG:.0f}°), '
                f'도구 축 연직 기울기 {min(vertical):.1f}~{max(vertical):.1f}°')
    if tilt > MAX_TILT_SPREAD_DEG:
        problems.append('스쿱 자세가 수직축 회전 말고도 다름 — RX/RY 는 건드리지 말고 RZ 로만 돌릴 것')

    yaw = {k: yaw_deg(points[k]) for k in have}
    ref = have[0]
    if max(abs(wrap_deg(yaw[k] - yaw[ref])) for k in have) <= YAW_TOL_DEG:
        msgs.append('손목 방향이 모두 같음 → 고정 자세 방식 (테두리 원 중심 = 표식이라고 가정)')
        return
    msgs.append('손목 방향이 다름 → 같은 테두리 점 방식: ' +
                ', '.join(f'{LABELS[k].split()[0]} {yaw[k]:+.0f}°' for k in have))
    # 같은 테두리 점이 벽을 향하면 (손목 방향 − 벽 방향) 이 네 점 모두 같다
    # (far→left 는 +90°, far→near 는 180°, far→right 는 −90°).
    rel = {k: wrap_deg(yaw[k] - WALL_DIR_DEG[k]) for k in have}
    for k in have[1:]:
        d = wrap_deg(rel[k] - rel[ref])
        if abs(d) > YAW_TOL_DEG:
            want = wrap_deg(yaw[ref] + WALL_DIR_DEG[k] - WALL_DIR_DEG[ref])
            problems.append(f'{LABELS[k]} 손목 방향 {yaw[k]:+.0f}° — {LABELS[ref]} 기준이면 {want:+.0f}° 여야 함 '
                            f'({d:+.0f}° 어긋남, 표시한 테두리 점이 벽을 향했는지 확인)')


def compute(points):
    """points: {label: [x, y, z, rx, ry, rz]} → (중심 또는 None, 메시지 목록, 문제 목록)"""
    msgs, problems = [], []
    have = [k for k in LABELS if k in points]
    if len(have) >= 2:
        zs = [points[k][2] for k in have]
        spread = float(np.ptp(zs))
        msgs.append(f'TCP z 차이 {spread * 1000:.1f} mm (기준 {MAX_Z_SPREAD_M * 1000:.0f} mm)')
        if spread > MAX_Z_SPREAD_M:
            problems.append('네 점의 높이가 다름 — 같은 z 에서 다시 짚을 것')
        check_orientation(points, have, msgs, problems)
    cx = cy = None
    if 'far' in points and 'near' in points:
        f, n = points['far'], points['near']
        cx = 0.5 * (f[0] + n[0])
        msgs.append(f'X: far {f[0]:+.4f}, near {n[0]:+.4f} → 중심 X {cx:+.4f}, 표식 간격 {(f[0] - n[0]) * 1000:.0f} mm')
        if abs(f[1] - n[1]) > MAX_CROSS_M:
            problems.append(f'far/near 의 y 가 {abs(f[1] - n[1]) * 1000:.0f} mm 다름 — X 축을 따라 곧게 다가갔는지 확인')
    if 'left' in points and 'right' in points:
        l, r = points['left'], points['right']
        cy = 0.5 * (l[1] + r[1])
        msgs.append(f'Y: left {l[1]:+.4f}, right {r[1]:+.4f} → 중심 Y {cy:+.4f}, 표식 간격 {(l[1] - r[1]) * 1000:.0f} mm')
        if abs(l[0] - r[0]) > MAX_CROSS_M:
            problems.append(f'left/right 의 x 가 {abs(l[0] - r[0]) * 1000:.0f} mm 다름 — Y 축을 따라 곧게 다가갔는지 확인')
    if cx is not None and cy is not None:
        gap_x = points['far'][0] - points['near'][0]
        gap_y = points['left'][1] - points['right'][1]
        msgs.append(f'두 방향 표식 간격 차이 {abs(gap_x - gap_y) * 1000:.0f} mm (솥이 원이면 비슷해야 함)')
        if abs(gap_x - gap_y) > 0.03:
            problems.append('X 방향과 Y 방향 간격이 3 cm 넘게 다름 — 테두리가 제대로 닿았는지 확인')
        return (cx, cy), msgs, problems
    return None, msgs, problems


def cmd_record(label, ip):
    import time
    from check_tcp_offset import read_robot
    for attempt in range(1, 4):
        try:
            pose, offset = read_robot(ip, 1500)
            break
        except SystemExit as e:                     # 조그 직후 Primary 연결이 가끔 거절됨
            if attempt == 3:
                raise
            print(f'{e} — 2 초 뒤 다시 시도 ({attempt}/3)')
            time.sleep(2.0)
    if np.linalg.norm(offset[:3]) < 1e-4:
        raise SystemExit('펜던트 TCP 오프셋이 0 입니다. 스쿱 표식 TCP 를 활성화한 뒤 다시 하세요.')
    doc = load()
    doc.setdefault('points', {})[label] = [round(float(v), 6) for v in pose]
    doc.setdefault('times', {})[label] = dt.datetime.now().isoformat(timespec='seconds')
    doc['tcp_offset'] = [round(float(v), 6) for v in offset]
    save(doc)
    print(f'기록: {LABELS[label]}  TCP x {pose[0]:+.4f}  y {pose[1]:+.4f}  z {pose[2]:+.4f}  '
          f'rpy ({pose[3]:+.3f}, {pose[4]:+.3f}, {pose[5]:+.3f})  손목 방향 {yaw_deg(pose):+.1f}°')
    missing = [LABELS[k] for k in LABELS if k not in doc['points']]
    print('남은 방향: ' + (', '.join(missing) if missing else '없음'))


def cmd_show():
    doc = load()
    points = doc.get('points', {})
    if not points:
        print('기록 없음')
        return 1
    for k in LABELS:
        if k in points:
            p = points[k]
            print(f'  {LABELS[k]:14s} x {p[0]:+.4f}  y {p[1]:+.4f}  z {p[2]:+.4f}  방향 {yaw_deg(p):+6.1f}°  ({doc["times"][k]})')
        else:
            print(f'  {LABELS[k]:14s} (없음)')
    center, msgs, problems = compute(points)
    for m in msgs:
        print('  ' + m)
    for p in problems:
        print('  ! ' + p)
    if center:
        print(f'\n솥 중심 = ({center[0]:+.4f}, {center[1]:+.4f}) m' + ('   (위 경고 확인 필요)' if problems else ''))
    return 0


def cmd_apply():
    from measure_kettle_axis import apply_to_profile, PROFILE_YAML
    doc = load()
    center, msgs, problems = compute(doc.get('points', {}))
    if center is None:
        raise SystemExit('네 방향이 모두 기록되지 않았습니다.')
    if problems:
        raise SystemExit('경고가 있어 넣지 않았습니다:\n  ' + '\n  '.join(problems))
    zs = [doc['points'][k][2] for k in LABELS]
    note = (f"로봇 벽 짚기 (스쿱 테두리, 마주 보는 벽 평균) {len(LABELS)}방향 · 표식 z {np.mean(zs):+.3f} · "
            f"{'; '.join(msgs)} ({max(doc['times'].values())}). wall_touch_points.yaml 참고.")
    apply_to_profile(center, note)
    print(f'적용: {PROFILE_YAML.name} placement.axis_xy_in_base_m = ({center[0]:+.4f}, {center[1]:+.4f})')
    return 0


def self_test():
    ok = True

    def case(name, pts, expect_center, expect_problem):
        nonlocal ok
        center, _, problems = compute(pts)
        good_center = expect_center is None or (center is not None and np.allclose(center, expect_center, atol=1e-3))
        good_problem = (not problems) if expect_problem is None else any(expect_problem in p for p in problems)
        good = good_center and good_problem
        print(f'  [{"OK" if good else "FAIL"}] {name}: 중심 {None if center is None else np.round(center, 4).tolist()}, 경고 {problems}')
        ok &= good

    truth = np.array([0.8125, 0.0159])
    wall_r = 0.498                                  # 테두리 높이의 벽 반경
    q = np.array([0.20, 0.03])                      # 표시한 테두리 점 (도구 x, y) — 표식에서 비대칭으로 벗어남

    def rot(deg):
        a = np.radians(deg)
        return np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])

    def pose(label, yaw, tilt_ry=0.0, z=-0.20):
        """손목 방향 yaw 로 벽 label 을 향해 중심선을 따라 다가가 도구 점 q 가 원형 벽에 닿았을 때의 표식 자세."""
        d = rot(WALL_DIR_DEG[label]) @ np.array([1.0, 0.0])
        n = np.array([-d[1], d[0]])
        rim = rot(yaw) @ q
        s = np.sqrt(wall_r ** 2 - (rim @ n) ** 2) - rim @ d
        p = truth + s * d
        return [p[0], p[1], z, np.pi, tilt_ry, np.radians(yaw)]

    def same_point(yaw_far):
        # 같은 점 q 가 각 벽을 향하려면 손목 방향 = yaw_far + 벽 방향
        return {k: pose(k, yaw_far + WALL_DIR_DEG[k]) for k in LABELS}

    def fixed(rim_center_offset):
        # 고정 자세 (손목 −90°): 반경 192.5 mm 테두리 원, 원 중심이 표식에서 rim_center_offset (도구 좌표) 만큼 벗어남
        out = {}
        for k in LABELS:
            d = rot(WALL_DIR_DEG[k]) @ np.array([1.0, 0.0])
            p = truth + (wall_r - 0.1925) * d - rot(-90.0) @ rim_center_offset
            out[k] = [p[0], p[1], -0.20, np.pi, 0.0, np.radians(-90.0)]
        return out

    case('고정 자세, 테두리 원 중심 = 표식', fixed(np.zeros(2)), truth, None)
    center, _, _ = compute(fixed(np.array([0.0, 0.025])))
    err = np.linalg.norm(np.asarray(center) - truth) * 1000
    good = abs(err - 25.0) < 0.5
    print(f'  [{"OK" if good else "FAIL"}] 고정 자세, 테두리 원 중심이 표식에서 25 mm 벗어남 → 중심 오차 {err:.1f} mm (예상 25, 경고로 못 잡음)')
    ok &= good
    case('같은 테두리 점 (비대칭 점, 90° 씩 회전)', same_point(-90.0), truth, None)
    case('같은 테두리 점 (시작 방향 +30°)', same_point(30.0), truth, None)
    bad = same_point(-90.0)
    bad['left'] = pose('left', 180.0)
    case('왼쪽에서 반대로 돌림', bad, None, '손목 방향')
    bad = same_point(-90.0)
    bad['near'] = pose('near', 90.0, z=-0.190)
    case('높이가 10 mm 다른 점', bad, None, '높이')
    common_tilt = {k: pose(k, -90.0 + WALL_DIR_DEG[k], tilt_ry=np.radians(3)) for k in LABELS}
    case('네 점 모두 3° 기울어진 채 수직축으로만 돌림', common_tilt, truth, None)
    bad = same_point(-90.0)
    bad['right'] = pose('right', 180.0, tilt_ry=np.radians(5))
    case('한 점만 5° 기울인 점', bad, None, '자세')
    return 0 if ok else 1


def main():
    from runtime_config import RT
    parser = argparse.ArgumentParser(description='스쿱 테두리 벽 짚기로 솥 중심 구하기 (읽기 전용).')
    parser.add_argument('action', nargs='?', choices=[*LABELS, 'show', 'apply', 'clear'])
    parser.add_argument('--ip', default=RT.robot.ip)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        return self_test()
    if args.action in LABELS:
        cmd_record(args.action, args.ip)
        return cmd_show()
    if args.action == 'show':
        return cmd_show()
    if args.action == 'apply':
        return cmd_apply()
    if args.action == 'clear':
        RECORD.unlink(missing_ok=True)
        print('기록을 지웠습니다.')
        return 0
    parser.print_help()
    return 1


if __name__ == '__main__':
    sys.exit(main())
