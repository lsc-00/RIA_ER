# config.py
# ================================================================
# 이 파일만 수정하면 UI 전체가 수정됨
# ================================================================

import flet as ft

# ----------------------------------------------------------------
# 앱 기본 설정
# ----------------------------------------------------------------
APP_TITLE    = "RIA Lab Control Panel"  # 브라우저 탭 제목
APP_THEME    = ft.ThemeMode.LIGHT       # LIGHT / DARK
APP_BG_COLOR = ft.Colors.BLUE_GREY_50  # 배경색


# ----------------------------------------------------------------
# 수동 제어 버튼
# 순서가 곧 화면에 표시되는 순서입니다.
# icon  → https://fonts.google.com/icons 에서 이름 검색
# color → ft.Colors.색상이름_숫자 형태로 입력
# ----------------------------------------------------------------
MANUAL_BUTTONS = [
    {
        "task":  "INIT",
        "label": "1. 초기 위치",
        "icon":  ft.Icons.INPUT,
        "color": ft.Colors.INDIGO_500,
    },
    {
        "task":  "STIR",
        "label": "2. 교반 작업",
        "icon":  ft.Icons.LOOP,
        "color": ft.Colors.BLUE_500,
    },
    {
        "task":  "MODIFY",
        "label": "test. 교반 위치 수정",
        "icon":  ft.Icons.LOOP,
        "color": ft.Colors.BLUE_500,
    },
    {
        "task":  "SCOOP",
        "label": "3. 뜨기 작업",
        "icon":  ft.Icons.ARROW_UPWARD,
        "color": ft.Colors.CYAN_600,
    },
    {
        "task":  "SHAKE",
        "label": "4. 털기 작업",
        "icon":  ft.Icons.VIBRATION,
        "color": ft.Colors.TEAL_500,
    },
    {
        "task":  "DISCHARGE",
        "label": "5. 배출 / 이송",
        "icon":  ft.Icons.OUTPUT,
        "color": ft.Colors.GREEN_600,
    },
    {
        "task":  "TEACHING",
        "label": "6. 위치 기록 (Teaching)",
        "icon":  ft.Icons.EDIT_LOCATION_ALT,
        "color": ft.Colors.DEEP_PURPLE_500,
    },

]


# ----------------------------------------------------------------
# ▶자동 시퀀스 버튼 (큰 버튼)
# ----------------------------------------------------------------
AUTO_BUTTON = {
    "label":    "전체 시퀀스 자동 동작",
    "sublabel": "AUTO SEQUENCE START",
    "color":    ft.Colors.RED_600,
}


# ----------------------------------------------------------------
# 일시정지 / 재개 토글 버튼
# ----------------------------------------------------------------
PAUSE_BUTTON = {
    "pause_label":  "일시정지\n(PAUSE)",
    "resume_label": "작업 재개\n(RESUME)",
    "pause_color":  ft.Colors.ORANGE_600,
    "resume_color": ft.Colors.GREEN_600,
}


# ----------------------------------------------------------------
# 🚨 비상정지 버튼
# ----------------------------------------------------------------
STOP_BUTTON = {
    "label": "비상 정지 (STOP)",
    "color": ft.Colors.RED_700,
}


# ----------------------------------------------------------------
# 🎚️ 파라미터 슬라이더
# min / max  : 슬라이더 최솟값 / 최댓값
# divisions  : 슬라이더 눈금 수 (촘촘할수록 숫자 큼)
# unit       : 값 옆에 표시될 단위 문자열
# ----------------------------------------------------------------
PARAM_SLIDERS = [
    {
        "label":     "교반 반경  STIR_RADIUS_CM",
        "key":       "STIR_RADIUS_CM",
        "min":       5.0,
        "max":       32.5,
        "divisions": 55,
        "unit":      "cm",
    },
    {
        "label":     "교반 깊이  STIR_DEPTH_CM",
        "key":       "STIR_DEPTH_CM",
        "min":       0.1,
        "max":       15.0,
        "divisions": 149,
        "unit":      "cm",
    },
    {
        "label":     "앞뒤 보정  X_BIAS_CM",
        "key":       "X_BIAS_CM",
        "min":       -20.0,
        "max":        20.0,
        "divisions":  400,
        "unit":       "cm",
    },
    {
        "label":     "좌우 보정  Y_BIAS_CM",
        "key":       "Y_BIAS_CM",
        "min":       -20.0,
        "max":        20.0,
        "divisions":  400,
        "unit":       "cm",
    },
]


# ----------------------------------------------------------------
# 📐 레이아웃 수치 (단위: px)
# ----------------------------------------------------------------
LAYOUT = {
    "manual_btn_height":   70,   # 수동 제어 버튼 높이
    "auto_btn_height":    200,   # 자동 시퀀스 버튼 높이
    "stop_btn_height":     80,   # 비상정지 버튼 높이
    "panel_padding":       30,   # 좌우 패널 내부 여백
    "panel_border_radius": 15,   # 패널 모서리 둥글기
    "btn_border_radius":   10,   # 버튼 모서리 둥글기
    "btn_font_size":       18,   # 버튼 글자 크기
    "log_font_size":       14,   # 로그 글자 크기
}


# ----------------------------------------------------------------
# 💬 화면에 표시되는 모든 고정 문구
# ----------------------------------------------------------------
LABELS = {
    "app_title":        "RIA Lab Control Panel",
    "manual_section":   "수동 제어",
    "auto_section":     "자동 제어 & 상태",
    "param_section":    "파라미터 설정",
    "param_reset_btn":  "기본값으로 초기화",
    "boot_title":       "시스템 부팅 중...",
    "boot_subtitle":    "로봇 전원을 켜고 브레이크를 해제하고 있습니다.",
    "boot_fail_title":  "부팅 실패",
    "boot_fail_sub":    "로봇 전원을 켜는데 실패했습니다.",
    "shutdown_title":   "시스템이 안전하게 종료되었습니다.",
    "shutdown_sub":     "만약 이 창이 자동으로 닫히지 않는다면 브라우저 탭을 직접 닫아주세요.",
    "clock_format":     "현재시간 %H:%M:%S",
    "teaching_section":  "위치 기록 (Teaching)",
    "teaching_back_btn": "← 제어 화면으로 돌아가기",
}