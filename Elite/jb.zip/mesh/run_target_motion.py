#!/usr/bin/env python3
"""
스쿱 모션 실제 시험 실행기. 좌표 입력 정책(target_policy) 또는 구역 고정 모션(zone_motion)을 로봇에서 한 번 돌려 본다.
--go 가 없으면 로봇을 움직이지 않는다 (계획 · 점검 · 그림 · 로봇 상태 읽기만).
카메라 화면에서 클릭해서 쓰려면 click_target_motion.sh (같은 점검 · 실행 함수를 쓴다).

    cd ~/cs612_ws/src/vendor/dev_log/jb/mesh
    python3 run_target_motion.py --target 40 225                          계획 · 점검 · 그림 (움직이지 않음)
    python3 run_target_motion.py --target 40 225 --go                     실제 높이 실행 (블렌드로 이어서)
    python3 run_target_motion.py --target 40 225 --policy wall_face       정책을 골라서 (center | edge_sweep | wall_face)
    python3 run_target_motion.py --target 40 225 --air auto --go          같은 모양을 물에 닿지 않는 높이에서 공중 시연
    python3 run_target_motion.py --target 40 225 --go --no-smooth         블렌드 없이 (경유점마다 멈춤, 비교용)
    python3 run_target_motion.py --target 40 225 --go --step              경유점마다 Enter 로 진행 (블렌드 없음)
    python3 run_target_motion.py --zone edge_45 --go                      구역 고정 모션 초안
    python3 run_target_motion.py --target 44.9 135 --wall-clearance 15    벽 쪽 단계 여유를 바꿔서 (이 실행에서만)
    python3 run_target_motion.py --self-test                              로봇 없이 계산 점검

목표 좌표는 솥 축 기준 반경 [cm] 과 방위 [deg] (0 = +X 로봇에서 먼 쪽, 90 = +Y 로봇에서 볼 때 왼쪽).

설정 (목록 · 뜻은 PARAMETERS.md)
  zone_motion.yaml   계획 · 경로 규칙 · 속도(speed) · 블렌드(smoothing) · 정책
  robot_runtime.yaml 로봇(IP · 홈 관절 · TCP 오프셋) · 점검(checks) · 보내는 방식(execution) · 기록(recording) · 공중 시연(air_demo)
  아래 괄호 안 이름이 그 키다.

움직이기 전에 멈추는 조건 (prepare)
  - robotMode 가 RUNNING, safetyMode 가 NORMAL 이 아님
  - 펜던트 TCP 오프셋이 robot.tcp_offset_* 와 다름 (checks.tcp_offset_tolerance_*) — 패널 전원을 껐다 켜면 0 으로 돌아간 적이 있다
  - 관절각으로 계산한 TCP 와 보고 TCP 가 checks.fk_tcp_mismatch_m 넘게 다름 (TCP 설정 · 기구학)
  - 관절각이 robot.home_joints_deg 에서 checks.home_joint_tolerance_deg 넘게 벗어남 (계획은 홈에서 출발한다) → move_home_safe.py --go 먼저
  - 홈 관절 FK TCP 가 zone_motion.yaml home_tcp 와 checks.home_tcp_mismatch_m 넘게 다름 (두 설정의 짝이 안 맞음)
  - 실제 높이: 계획이 경로 규칙 미통과
  - 보낼 경로(블렌드 포함)가 경로 규칙(단계별 여유 · 벽 쪽 다가감 · 팔 닿는 거리)을 못 지킴
  - 공중 시연: 스쿱(망 · 손잡이 · 손목) 가장 낮은 점이 수면 + air_demo.water_margin_m 보다 낮아짐
    (auto 는 규칙을 지키는 가장 낮은 높이를 고른다. 높이 올릴수록 팔이 다 펴져 역기구학이 막히므로 낮을수록 좋다.
     마지막 들어 올리기는 air_demo.lift_cap_m 까지만)
  - 역기구학: 실패하거나 한 샘플에서 관절이 checks.ik_max_joint_step_deg 넘게 뜀
  - 로봇 팔 링크(위팔 · 아래팔 · 손목 충돌 메시)와 솥 여유가 checks.arm_min_clearance_m 미만 (arm_clearance.py —
    2026-09-15 22:21 아래팔이 림에 닿아 멈춘 뒤 추가. 계획기 규칙은 스쿱 · 손잡이 · 손목 캡슐까지만 본다)
  - 사용자가 'yes' 를 입력하지 않음 (한글 자판 'ㅛㄷㄴ' 도 받음. --yes 로 생략 가능, 대화형이 아닐 때만)

보내는 동작 (execute) — 스무딩 (jb/2026-09-15.md 3.6)
  경유점을 movel 로 차례로 보낸다. 한 구간에서 도구가 execution.max_rotation_per_move_deg 넘게 도는 곳은 나눠 확인한 경로와 같은 쪽으로 돌게 한다.
  - 블렌드: 중간 경유점마다 movel r (smoothing.blend_radius_m, 벽 근처 near_wall_blend_radius_m, 앞뒤 구간 × max_segment_fraction 이하).
    블렌드로 깎인 경로로 경로 규칙을 다시 확인하고, 안 되면 반경을 줄인다 (ZoneMotionPlanner.smooth). 마지막 movel 은 항상 r = 0.
  - 속도는 단계 단위 (그 단계에 벽 근처 구간이 있으면 단계 전체를 speed.near_wall_m_s 로), 가속도 speed.accel_m_s2.
  - 실행 중 RTSI 로 실제 TCP 를 기록해 멈춘 횟수 · 걸린 시간 · 보낸 경로와의 최대 편차를 계산하고 motion_runs/ 에 남긴다.
  실행 중 안전 모드가 NORMAL 이 아니게 되면 멈추고 알린다 (자동 복귀 없음). Ctrl+C 또는 정지 신호 = stopl.
  홈 복귀는 --return-home 또는 move_home_safe.py --go.
"""

import argparse
import datetime as dt
import math
import re
import subprocess
import sys
import threading
import time
from pathlib import Path

import numpy as np
import yaml

sys.dont_write_bytecode = True

HERE = Path(__file__).resolve().parent
WS = next(p for p in HERE.parents if (p / 'src' / 'RIA_kettle').is_dir())
sys.path.insert(0, str(WS / 'src' / 'RIA_kettle'))

from ria_kettle import rotation_about  # noqa: E402
from ria_kettle.kettle_model import parse_water_surface_z  # noqa: E402
from ria_kettle.target_policy import WALL_STAGES, TargetPolicyPlanner  # noqa: E402
from ria_kettle.zone_motion import HOME, Waypoint, ZoneMotionPlanner, matrix_to_rpy, rotation_log  # noqa: E402
from runtime_config import RT, RT_PATH, home_q, tcp_offset  # noqa: E402

LIFT_STAGES = ('들어올리기', '벽들어올리기')
RUN_DIR = HERE / 'motion_runs'


def confirmed(answer):
    """'yes' 확인. 한글 자판으로 친 'ㅛㄷㄴ' 과 앞에 섞인 조합 문자 · 제어 문자도 받는다."""
    text = re.sub(r'[^a-zㄱ-ㅣ]', '', str(answer).lower())
    return text.endswith('yes') or text.endswith('ㅛㄷㄴ')


# -- 계획 ----------------------------------------------------------------------

def make_plan(args, planner, tp):
    """(계획 객체, 설명, 목표 x·y 또는 None). 계획 객체는 waypoints · samples · segment_slow 를 가진다."""
    if args.zone:
        m = planner.motion(args.zone)
        return m, f'구역 고정 모션 {m.label}', None
    r, az = args.target[0] / 100.0, math.radians(args.target[1])
    target = planner.axis_xy + r * np.array([math.cos(az), math.sin(az)])
    plan = tp.plan(*target) if args.policy == 'auto' else tp.plan_policy(args.policy, *target)
    return plan, f'목표 반경 {args.target[0]:.1f} cm · 방위 {args.target[1]:.0f}° → {plan.label}', target


def plan_ok(plan):
    return bool(getattr(plan, 'ok', False))


def parse_air(text):
    """'0' → 실제 높이, 'auto' → 자동 높이, 숫자 → 그만큼 위 [m]."""
    if text is None or str(text).strip() in ('', '0', '0.0'):
        return 0.0
    if str(text).strip().lower() == 'auto':
        return 'auto'
    value = float(text)
    if value < 0.0:
        raise ValueError('--air 는 0 이상이거나 auto')
    return value


def shift_up(waypoints, dz, lift_cap=None):
    """공중 시연: 홈을 뺀 경유점을 dz 만큼 위로. 마지막 들어 올리기는 앞 경유점보다 lift_cap (기본 air_demo.lift_cap_m) 까지만 더 올린다."""
    lift_cap = float(RT.air_demo.lift_cap_m) if lift_cap is None else lift_cap
    out = []
    for i, w in enumerate(waypoints):
        if w.stage == HOME:
            out.append(w)
            continue
        p = w.position + np.array([0.0, 0.0, dz])
        if w.stage in LIFT_STAGES and i > 0 and out:
            rise = min(float(w.position[2] - waypoints[i - 1].position[2]), lift_cap)
            p[2] = min(p[2], out[-1].position[2] + max(rise, 0.0))
        out.append(Waypoint(w.stage, p, w.R))
    return out


def expand_waypoints(waypoints, max_rot_deg=None):
    """한 구간에서 도구가 max_rot_deg (기본 execution.max_rotation_per_move_deg) 넘게 도는 곳을 나눈 경유점 목록 (첫 경유점 포함).
    컨트롤러가 반대쪽으로 돌지 않게."""
    max_rot_deg = float(RT.execution.max_rotation_per_move_deg) if max_rot_deg is None else max_rot_deg
    out = [waypoints[0]]
    for a, b in zip(waypoints[:-1], waypoints[1:]):
        w = rotation_log(a.R.T @ b.R)
        angle = float(np.linalg.norm(w))
        n = max(int(math.ceil(math.degrees(angle) / max_rot_deg)), 1)
        for i in range(1, n + 1):
            t = i / n
            R = a.R @ rotation_about(w, t * angle) if angle > 1e-12 else a.R
            out.append(Waypoint(b.stage, a.position + t * (b.position - a.position), R))
    return out


def make_script(moves, accel, name='ria_target_motion'):
    """moves: [(단계, 위치, 회전, 속도, 블렌드 반경)]. 마지막 movel 은 반드시 r = 0 (정확히 서서 끝난다)."""
    lines = [f'def {name}():']
    for i, (_, p, R, v, r) in enumerate(moves):
        pose = [*map(float, p), *matrix_to_rpy(R)]
        if not all(math.isfinite(x) for x in pose):
            raise ValueError(f'유효하지 않은 자세: {pose}')
        blend = 0.0 if i == len(moves) - 1 else float(r)
        lines.append(f'  movel([{", ".join(f"{x:.6f}" for x in pose)}], a={accel:.3f}, v={v:.3f}, r={blend:.4f})')
    lines.append('end')
    return '\n'.join(lines) + '\n'


def water_margin(planner, samples):
    """스쿱(망 · 손잡이 · 손목) 가장 낮은 점 − 수면 의 최소값 [m]."""
    body = planner.body
    return min(float(np.min((body.points_base(p, R))[:, 2] - body.inflate)) for _, p, R in samples) - planner.surface_z


def rule_problem(planner, check):
    """경로 규칙 위반 설명 또는 ''."""
    if check.closing:
        _, stage, part, d, drop = check.closing[0]
        return f'{stage} 중 {part} 가 벽 쪽으로 {drop * 1000:.0f} mm 다가감 (여유 {d * 1000:.0f} mm)'
    violation = planner.clearance_violation(check)
    if violation:
        stage, value, need = violation
        return f'{stage} 중 여유 {value * 1000:.0f} mm < {need * 1000:.0f} mm'
    if check.reach_m > planner.max_reach:
        return f'팔이 닿지 않음 ({check.reach_m:.3f} m > {planner.max_reach:.2f} m)'
    return ''


def auto_air_offset(planner, plan):
    """스쿱이 물에서 air_demo.water_margin_m 넘게 떨어지고 경로 규칙을 지키는 가장 낮은 공중 시연 높이. 없으면 None."""
    a = RT.air_demo
    for dz in np.arange(float(a.search_start_m), float(a.max_offset_m) + 1e-9, float(a.search_step_m)):
        waypoints = shift_up(plan.waypoints, float(dz))
        if water_margin(planner, planner.sample(waypoints)) < float(a.water_margin_m):
            continue
        if planner.feasible(planner.check_path(waypoints, planner.coarse_body)):
            return float(round(dz, 3))
    return None


def estimate_seconds(moves, start):
    total, prev = 0.0, start
    for _, p, _, v, _ in moves:
        total += float(np.linalg.norm(p - prev)) / max(v, 1e-3) + 1.0
        prev = p
    return total


# -- 로봇 ----------------------------------------------------------------------

def load_solver():
    """(solver, loader). loader 를 함께 들고 있어야 KDL 플러그인이 내려가지 않는다. 실패하면 (None, None)."""
    try:
        from move_home_safe import make_solver
        from zone_motion_check import load_mdh
        return make_solver(load_mdh(False))
    except SystemExit as exc:
        print(f'역기구학 확인 불가: {exc}')
        return None, None


def read_robot_state():
    """읽기 전용: 모드 · 안전 모드 · TCP · 오프셋 · 관절각."""
    import elite_cs_sdk as cs
    from check_flange_fk import read_rtsi
    from check_tcp_offset import read_robot
    from move_home_safe import mode_name
    ip = RT.robot.ip
    dashboard = cs.DashboardClientInterface()
    if not dashboard.connect(ip, 29999):
        raise SystemExit('Dashboard 29999 연결 실패')
    try:
        mode, safety = mode_name(dashboard.robotMode()), mode_name(dashboard.safetyMode())
    finally:
        dashboard.disconnect()
    pose, offset = read_robot(ip, 1500)
    q = np.array(read_rtsi(cs, ip, 3)[-1][0])
    return {'mode': mode, 'safety': safety, 'tcp': list(pose), 'offset': list(offset), 'q': q}


def preflight_problems(state, solver=None):
    """solver 가 있으면 관절각 FK + 기대 TCP 오프셋으로 계산한 TCP 와 로봇이 보고한 TCP 를 비교한다 (TCP 설정 확인)."""
    problems = []
    if state['mode'] != 'RUNNING':
        problems.append(f'로봇이 RUNNING 이 아님 ({state["mode"]})')
    if state['safety'] != 'NORMAL':
        problems.append(f'안전 모드가 NORMAL 이 아님 ({state["safety"]})')
    checks, expected = RT.checks, np.asarray(tcp_offset())
    off = np.asarray(state['offset'])
    if (np.linalg.norm(off[:3] - expected[:3]) > float(checks.tcp_offset_tolerance_m)
            or np.degrees(np.abs(off[3:] - expected[3:])).max() > float(checks.tcp_offset_tolerance_deg)):
        problems.append(f'펜던트 TCP 오프셋이 다름: {np.round(off[:3] * 1000, 1).tolist()} mm, 회전 {np.round(off[3:], 4).tolist()} '
                        f'(기대 {np.round(expected[:3] * 1000, 1).tolist()} mm, 회전 {np.round(expected[3:], 4).tolist()} '
                        '— 패널 재시작 후 초기화됐는지 확인)')
    dq = np.degrees(np.abs(state['q'] - home_q()))
    if dq.max() > float(checks.home_joint_tolerance_deg):
        problems.append(f'홈 자세가 아님 (관절 차이 최대 {dq.max():.1f}°) → h (move_home_safe.py --go) 먼저')
    if solver is not None:
        from move_home_safe import tcp_from_joints
        p_fk, _ = tcp_from_joints(solver, state['q'], expected)
        mismatch = float(np.linalg.norm(p_fk - np.asarray(state['tcp'][:3])))
        state['fk_mismatch_m'] = mismatch
        if mismatch > float(checks.fk_tcp_mismatch_m):
            problems.append(f'관절각으로 계산한 TCP 와 보고 TCP 가 {mismatch * 1000:.1f} mm 다름 (TCP 설정 · 기구학 확인)')
    return problems


def prepare(planner, plan, air=0.0, speed_scale=1.0, solver=None, read_robot=True, smooth=True):
    """실행 전 점검. air: 0 = 실제 높이, 숫자 = 그만큼 위 [m], 'auto' = 물에 닿지 않는 가장 낮은 높이.
    smooth: 블렌드로 이어 보낼지 (False 면 경유점마다 멈춤).
    반환 dict: real, air, waypoints, radii, samples, moves, accel, seconds, check, problems(목록), lines(요약 문장), state."""
    from zone_motion_check import track_ik
    early = []
    if air == 'auto':
        air = auto_air_offset(planner, plan)
        if air is None:
            early.append(f'공중 시연 불가: 스쿱이 물에서 {RT.air_demo.water_margin_m * 1000:.0f} mm 떨어지게 올리면 팔 닿는 거리 한계를 넘거나 '
                         f'벽 규칙을 못 지킴 (최대 {RT.air_demo.max_offset_m * 100:.0f} cm 까지 찾음). 이 자리는 실제 높이로 속도 배율을 낮춰 확인')
            air = float(RT.air_demo.max_offset_m)
    real = air <= 0.0
    waypoints = expand_waypoints(plan.waypoints if real else shift_up(plan.waypoints, air))
    if smooth:
        radii, check, slow = planner.smooth(waypoints)
    else:
        check = planner.check_path(waypoints)
        radii, slow = [0.0] * len(waypoints), planner.stage_uniform(waypoints, check.segment_slow)
    normal, slow_v = planner.speed_m_s * speed_scale, planner.near_wall_speed_m_s * speed_scale
    accel = planner.accel_m_s2
    moves = [(w.stage, w.position, w.R, slow_v if slow[k] else normal, radii[k + 1]) for k, w in enumerate(waypoints[1:])]
    info = {'real': real, 'air': air, 'speed_scale': speed_scale, 'waypoints': waypoints, 'radii': radii,
            'samples': check.samples, 'moves': moves, 'accel': accel, 'check': check, 'config': run_config(planner),
            'seconds': estimate_seconds(moves, planner.home.position), 'problems': early, 'lines': [], 'state': None}
    problems, lines = info['problems'], info['lines']
    if real and not plan_ok(plan):
        problems.append('실제 높이 실행인데 계획이 경로 규칙을 통과하지 못함')
    why = rule_problem(planner, check)
    if why:
        problems.append(('블렌드한 ' if any(radii) else '') + f'보낼 경로가 경로 규칙을 못 지킴: {why}')
    blended = [r for r in radii if r > 0.0]
    if blended:
        lines.append(f'블렌드: 중간 경유점 {len(blended)}/{max(len(radii) - 2, 0)}개, 반경 {min(blended) * 1000:.0f}~{max(blended) * 1000:.0f} mm '
                     f'(벽 근처 ≤ {float(planner.cfg["smoothing"]["near_wall_blend_radius_m"]) * 1000:.0f} mm), 가속도 {accel:g} m/s², '
                     f'블렌드 경로 최소 여유 {check.clearance.clearance_m * 1000:.0f} mm ({check.clearance_stage})')
    else:
        lines.append(f'블렌드 없음 (경유점마다 멈춤), 가속도 {accel:g} m/s²')
    if not real:
        # 공중 시연도 솥 안에서 움직이므로 실제 실행과 같은 경로 규칙을 지켜야 한다
        margin = water_margin(planner, check.samples)
        lines.append(f'공중 시연 +{air * 100:.0f} cm: 스쿱 가장 낮은 점이 수면보다 최소 {margin * 1000:.0f} mm 위, '
                     f'팔 뻗음 {check.reach_m:.3f} m (마지막 들어 올리기는 {RT.air_demo.lift_cap_m * 100:.0f} cm 까지만)')
        if margin < float(RT.air_demo.water_margin_m):
            problems.append(f'공중 시연인데 스쿱이 수면에 가까움 ({margin * 1000:.0f} mm < {RT.air_demo.water_margin_m * 1000:.0f} mm)')
    down = next((w for w in plan.waypoints if w.stage == '내리기'), None)
    if down is not None:
        turn = [w for w in plan.waypoints if w.stage == '물속자세']
        lines.append(f'진입: 입구 {planner.opening_gamma_deg(down.R):.0f}° 로 수직 하강'
                     + (f' → 물속에서 {planner.opening_gamma_deg(turn[-1].R):.0f}° 까지 {len(turn)}단계로 세움' if turn
                        else ' (물속 회전 없음 = 쓸기 자세 그대로 진입)'))
    lines.append(f'movel {len(moves)}개, 예상 {info["seconds"]:.0f} s (속도 배율 {speed_scale:g})')
    if solver is None:
        problems.append('역기구학을 확인할 수 없음 (cs612_mdh.yaml · KDL 플러그인)')
    else:
        from move_home_safe import tcp_from_joints
        p_home, _ = tcp_from_joints(solver, home_q(), tcp_offset())
        gap = float(np.linalg.norm(p_home - planner.home.position))
        if gap > float(RT.checks.home_tcp_mismatch_m):
            problems.append(f'홈 관절 FK 로 계산한 TCP 가 zone_motion.yaml home_tcp 와 {gap * 1000:.1f} mm 다름 '
                            '(robot_runtime.yaml 의 홈 관절 · TCP 오프셋을 바꿨으면 home_tcp 도 같이)')
        qs, ik_problems = track_ik(solver, check.samples)
        if len(qs):
            steps = np.degrees(np.abs(np.diff(qs, axis=0))).max() if len(qs) > 1 else 0.0
            lines.append(f'역기구학: {len(qs)}/{len(check.samples)} 샘플, 한 샘플 최대 관절 변화 {steps:.1f}°, '
                         f'J6 {np.degrees(qs[:, 5]).min():.0f}~{np.degrees(qs[:, 5]).max():.0f}°')
        problems += ik_problems
        if len(qs):
            from arm_clearance import ArmModel
            arm = ArmModel.shared().check_path(planner.kettle, qs, [s for s, _, _ in check.samples])
            need = float(RT.checks.arm_min_clearance_m)
            info['arm'] = arm
            lines.append(f'팔 링크 ↔ 솥: 최소 {arm.value_m * 1000:+.0f} mm ({arm.stage} · {arm.link} · {arm.kind}), '
                         f'기준 {need * 1000:.0f} mm')
            if arm.value_m < need:
                problems.append(f'로봇 팔({arm.link})이 솥에 너무 가까움: {arm.stage} 중 {arm.value_m * 1000:+.0f} mm '
                                f'< {need * 1000:.0f} mm ({arm.kind}, base {arm.point})')
    if read_robot:
        try:
            state = read_robot_state()
            robot_problems = preflight_problems(state, solver)
            fk = f', FK 와 TCP 차이 {state["fk_mismatch_m"] * 1000:.1f} mm' if 'fk_mismatch_m' in state else ''
            lines.append(f'로봇: {state["mode"]} / {state["safety"]}, TCP 오프셋 '
                         f'{np.round(np.asarray(state["offset"][:3]) * 1000, 1).tolist()} mm, '
                         f'관절 {np.round(np.degrees(state["q"]), 1).tolist()}°{fk}')
            problems += robot_problems
            info['state'] = state
        except SystemExit as exc:
            problems.append(f'로봇 상태를 읽지 못함: {exc}')
    return info


def run_config(planner):
    """실행 기록에 남길 설정 (파라미터를 바꿔 가며 결과를 비교할 수 있게). 실행 한 번만 바꾼 벽 쪽 여유도 반영된다."""
    c = planner.cfg
    return {'water': planner.surface_source, 'surface_z_m': round(float(planner.surface_z), 4), 'motion': c['motion'],
            'rules': {**c['rules'], 'stage_min_clearance_m': dict(planner.stage_min_clearance)},
            'speed': c['speed'], 'smoothing': c['smoothing'],
            'runtime': {k: RT[k].plain() for k in ('execution', 'air_demo', 'recording')}}


def moves_table(moves):
    rows = []
    for i, (stage, p, R, v, r) in enumerate(moves):
        rpy = matrix_to_rpy(R)
        rows.append(f'{i + 1:2d} {stage:8s} ({p[0]:+.4f}, {p[1]:+.4f}, {p[2]:+.4f})  '
                    f'rpy ({rpy[0]:+.3f}, {rpy[1]:+.3f}, {rpy[2]:+.3f})  v {v:.3f}  r {r * 1000:4.1f} mm')
    return rows


class RtsiRecorder(threading.Thread):
    """실행 중 실제 TCP 자세 · 속도를 RTSI (읽기 전용) 로 기록한다. rows = [(시각 s, TCP 6, TCP 속도 6)]."""

    def __init__(self, frequency=None):
        super().__init__(daemon=True)
        self.frequency = float(RT.recording.rtsi_hz) if frequency is None else frequency
        self.rows, self.error = [], None
        self._halt = threading.Event()

    def run(self):
        import elite_cs_sdk as cs
        client = cs.RtsiClientInterface()
        try:
            client.connect(RT.robot.ip, 30004)
            if not client.negotiateProtocolVersion():
                raise RuntimeError('RTSI 프로토콜 협상 실패')
            recipe = client.setupOutputRecipe(['actual_TCP_pose', 'actual_TCP_speed'], self.frequency)
            if not client.start():
                raise RuntimeError('RTSI 스트림 시작 실패')
            last = None
            while not self._halt.is_set():
                recipes = [recipe]
                if client.receiveData(recipes, read_newest=True) > 0 and recipes:
                    pose = list(recipes[0].getValue('actual_TCP_pose'))
                    speed = list(recipes[0].getValue('actual_TCP_speed'))
                    if len(pose) == 6 and pose != last:
                        self.rows.append((time.monotonic(), pose, speed))
                        last = pose
                time.sleep(0.004)
            client.pause()
        except Exception as exc:
            self.error = str(exc)
        finally:
            try:
                client.disconnect()
            except Exception:
                pass

    def stop(self):
        self._halt.set()
        self.join(timeout=3.0)


def motion_metrics(rows, samples):
    """실행 기록 지표: 움직인 시간, 움직이는 동안 멈춘 횟수, 최고 속도, 보낸 경로(블렌드 샘플)와의 최대 · 평균 편차."""
    if len(rows) < 10:
        return None
    t = np.array([r[0] for r in rows])
    t -= t[0]
    P = np.array([r[1][:3] for r in rows])
    V = np.array([np.linalg.norm(r[2][:3]) for r in rows])
    moving = np.where(V > float(RT.recording.moving_speed_m_s))[0]
    if len(moving) == 0:
        return {'moved': False, 'rtsi_samples': len(rows)}
    i0, i1 = int(moving[0]), int(moving[-1])
    stop_speed, stop_min_s = float(RT.recording.stop_speed_m_s), float(RT.recording.stop_min_s)
    stops, since, counted = 0, None, False
    for i in range(i0, i1 + 1):
        if V[i] < stop_speed:
            since = t[i] if since is None else since
            if not counted and t[i] - since >= stop_min_s:
                stops, counted = stops + 1, True
        else:
            since, counted = None, False
    path = np.array([p for _, p, _ in samples])
    A, AB = path[:-1], path[1:] - path[:-1]
    L2 = np.maximum((AB ** 2).sum(axis=1), 1e-12)
    dev = []
    for p in P[i0:i1 + 1:2]:
        s = np.clip(((p - A) * AB).sum(axis=1) / L2, 0.0, 1.0)
        dev.append(float(np.linalg.norm(A + s[:, None] * AB - p, axis=1).min()))
    return {'moved': True, 'duration_s': round(float(t[i1] - t[i0]), 2), 'stops_while_moving': stops,
            'max_speed_m_s': round(float(V.max()), 3), 'max_deviation_mm': round(max(dev) * 1000, 1),
            'mean_deviation_mm': round(float(np.mean(dev)) * 1000, 1), 'rtsi_rate_hz': round(len(rows) / max(float(t[-1]), 1e-6), 1)}


def metrics_line(metrics):
    if not metrics:
        return '실행 기록: RTSI 기록이 부족해 지표 없음'
    if not metrics.get('moved'):
        return '실행 기록: 움직임이 기록되지 않음'
    return (f'실행 기록: {metrics["duration_s"]:.1f} s, 움직이는 동안 멈춤 {metrics["stops_while_moving"]}번, '
            f'최고 속도 {metrics["max_speed_m_s"]:.3f} m/s, 보낸 경로와 편차 최대 {metrics["max_deviation_mm"]:.1f} · '
            f'평균 {metrics["mean_deviation_mm"]:.1f} mm (RTSI {metrics["rtsi_rate_hz"]:.0f} Hz)')


def send_stop():
    """정지 신호 (stopl). 다른 연결에서 실행 중인 프로그램도 멈춘다."""
    import elite_cs_sdk as cs
    primary = cs.PrimaryClientInterface()
    if primary.connect(RT.robot.ip, 30001):
        try:
            primary.sendScript(f'stopl({float(RT.execution.stop_decel_m_s2)})\n')
        finally:
            primary.disconnect()


def wait_motion(dashboard, timeout_s, stop_event=None):
    from move_home_safe import mode_name
    start, saw_running = time.monotonic(), False
    while time.monotonic() - start < timeout_s:
        if stop_event is not None and stop_event.is_set():
            return '사용자 정지'
        safety = mode_name(dashboard.safetyMode())
        if safety != 'NORMAL':
            return f'안전 모드 {safety}'
        status = mode_name(dashboard.runningStatus())
        if status not in ('STOPPED', 'UNKNOWN'):
            saw_running = True
        elif status == 'STOPPED' and (saw_running or time.monotonic() - start > 3.0):
            return None
        time.sleep(0.1)
    return '시간 초과'


def execute(moves, step=False, start_tcp=None, stop_event=None, accel=None, record=None):
    """로봇에 보낸다. 반환: (결과 문구, 마지막 TCP). 결과가 '완료' 가 아니면 멈춘 것.
    accel 은 prepare 가 정한 info['accel'] (zone_motion.yaml speed.accel_m_s2) 를 넘긴다.
    step 이면 경유점마다 따로 보내므로 블렌드 없이 선다. record(dict) 를 주면 RTSI 기록을 record['rows'] 에 담는다."""
    import elite_cs_sdk as cs
    from move_home_safe import read_cartesian
    if accel is None:
        raise ValueError('execute: accel 이 없습니다 (prepare 결과 info["accel"] 을 넘길 것)')
    ex = RT.execution
    dashboard, primary = cs.DashboardClientInterface(), cs.PrimaryClientInterface()
    if not dashboard.connect(RT.robot.ip, 29999):
        raise SystemExit('Dashboard 29999 연결 실패')
    if not primary.connect(RT.robot.ip, 30001):
        dashboard.disconnect()
        raise SystemExit('Primary 30001 연결 실패')
    recorder = None
    if record is not None:
        recorder = RtsiRecorder()
        recorder.start()
        time.sleep(0.3)
    result = '완료'
    try:
        chunks = [[m] for m in moves] if step else [moves]
        prev = np.asarray(moves[0][1] if start_tcp is None else start_tcp)
        for i, chunk in enumerate(chunks):
            if step:
                stage, p = chunk[0][0], chunk[0][1]
                answer = input(f'  [{i + 1}/{len(chunks)}] {stage} → ({p[0]:+.3f}, {p[1]:+.3f}, {p[2]:+.3f}) '
                               f'v {chunk[0][3]:.3f}  Enter = 실행, q = 중단: ').strip().lower()
                if answer == 'q':
                    result = '사용자가 중단'
                    break
            timeout = estimate_seconds(chunk, prev) * float(ex.timeout_factor) + float(ex.timeout_extra_s)
            if not primary.sendScript(make_script(chunk, accel)):
                result = '프로그램 전송 실패'
                break
            try:
                problem = wait_motion(dashboard, timeout, stop_event)
            except KeyboardInterrupt:
                problem = 'Ctrl+C'
            prev = chunk[-1][1]
            if problem:
                if problem in ('시간 초과', 'Ctrl+C', '사용자 정지'):
                    primary.sendScript(f'stopl({float(ex.stop_decel_m_s2)})\n')
                result = f'중단: {problem}'
                break
            if step:
                pose, _ = read_cartesian(primary)
                print(f'      도착 오차 {np.linalg.norm(np.asarray(pose[:3]) - chunk[-1][1]) * 1000:.1f} mm')
        pose, _ = read_cartesian(primary)
        return result, list(pose)
    finally:
        if recorder is not None:
            time.sleep(0.3)
            recorder.stop()
            record['rows'] = recorder.rows
            record['error'] = recorder.error
        primary.disconnect()
        dashboard.disconnect()


def write_log(meta, plan, info, result, final_tcp, record=None):
    """motion_runs/<시각>_<이름>.yaml 로 남기고 경로를 돌려준다."""
    RUN_DIR.mkdir(exist_ok=True)
    started = meta.get('started', dt.datetime.now())
    moves = info['moves']
    err = float(np.linalg.norm(np.asarray(final_tcp[:3]) - moves[-1][1])) * 1000 if final_tcp else None
    rows = (record or {}).get('rows') or []
    t0 = rows[0][0] if rows else 0.0
    doc = {'started': started.isoformat(timespec='seconds'), **{k: v for k, v in meta.items() if k != 'started'},
           'result': result, 'air_m': info['air'], 'speed_scale': info['speed_scale'], 'accel_m_s2': info.get('accel'),
           'config': info.get('config'),
           'plan_ok': plan_ok(plan), 'plan_reason': getattr(plan, 'reason', ''),
           'params': {k: (list(v) if isinstance(v, tuple) else v) for k, v in (getattr(plan, 'params', {}) or {}).items()},
           'moves': [{'stage': s, 'pose': [*map(float, p), *matrix_to_rpy(R)], 'v': float(v), 'r': float(r)}
                     for s, p, R, v, r in moves],
           'final_tcp': None if not final_tcp else [float(v) for v in final_tcp], 'final_error_mm': err,
           'metrics': info.get('metrics'), 'rtsi_error': (record or {}).get('error'),
           'trace_t_xyz_speed': [[round(r[0] - t0, 3), *[round(v, 5) for v in r[1][:3]],
                                  round(float(np.linalg.norm(r[2][:3])), 4)] for r in rows[::max(int(RT.recording.trace_every), 1)]]}
    path = RUN_DIR / f'{started:%Y%m%d_%H%M%S}_{meta.get("name", "run")}.yaml'
    path.write_text(yaml.safe_dump(doc, allow_unicode=True, sort_keys=False), encoding='utf-8')
    return path


# -- 실행 ----------------------------------------------------------------------

def self_test():
    planner = ZoneMotionPlanner.from_yaml(water_surface_z=None)     # 도구 계산 확인은 설계 수위 100 L 기준
    print(f'  (설계 수위 100 L 로 확인. 실제 실행은 water_level.yaml: {ZoneMotionPlanner.from_yaml().surface_source})')
    tp = TargetPolicyPlanner(planner, planner.cfg)
    s = planner.cfg['smoothing']
    far, near = float(s['blend_radius_m']), float(s['near_wall_blend_radius_m'])
    assert confirmed('yes') and confirmed('ㅛㄷㄴ') and confirmed('ㅛ\x1b[yes') and not confirmed('no')
    ok = len(home_q()) == 6 and len(tcp_offset()) == 6 and float(RT.execution.max_rotation_per_move_deg) > 0.0
    print(f'  [{"OK" if ok else "FAIL"}] 실행 설정 읽기: {RT_PATH}')
    try:
        RT.execution.not_a_key
        ok = False
    except AttributeError as exc:
        print(f'  [OK] 없는 키는 이름을 알려 주는 에러: {exc}')
    for policy, r, az in (('center', 0.0, 0.0), ('edge_sweep', 0.25, 0.0), ('wall_face', 0.40, 225.0)):
        target = planner.axis_xy + r * np.array([math.cos(math.radians(az)), math.sin(math.radians(az))])
        plan = tp.plan_policy(policy, *target)
        info = prepare(planner, plan, read_robot=False)
        script = make_script(info['moves'], info['accel'])
        last_zero = script.strip().splitlines()[-2].endswith('r=0.0000)')
        radii_ok = all(v <= far + 1e-12 for v in info['radii']) and info['radii'][-1] == 0.0
        slow_blends = [info['radii'][k + 1] for k, mv in enumerate(info['moves'][:-1])
                       if mv[3] < planner.speed_m_s or info['moves'][k + 1][3] < planner.speed_m_s]
        near_ok = all(v <= near + 1e-12 for v in slow_blends)
        rules_ok = not rule_problem(planner, info['check'])
        good = plan.ok and script.count('movel(') == len(info['moves']) and last_zero and radii_ok and near_ok and rules_ok
        ok &= good
        print(f'  [{"OK" if good else "FAIL"}] {policy}: 계획 {"OK" if plan.ok else "실패"}, 마지막 r=0 {last_zero}, '
              f'벽 근처 블렌드 ≤ {near * 1000:.0f} mm {near_ok}, 블렌드 경로 규칙 {rules_ok} · ' + ' · '.join(info['lines']))
    return 0 if ok else 1


def main():
    parser = argparse.ArgumentParser(description='스쿱 모션 실제 시험 실행기 (--go 없으면 움직이지 않음).')
    what = parser.add_mutually_exclusive_group()
    what.add_argument('--target', nargs=2, type=float, metavar=('R_CM', 'AZ_DEG'), help='목표 음식: 솥 축 기준 반경 cm, 방위 deg')
    what.add_argument('--zone', help='구역 고정 모션 (center | edge_45 | edge_135 | edge_225 | edge_315)')
    parser.add_argument('--policy', default='auto', choices=['auto', 'center', 'edge_sweep', 'wall_face'])
    parser.add_argument('--air', type=parse_air, default=0.0, metavar='M|auto',
                        help='공중 시연: auto = 스쿱이 물에 닿지 않는 가장 낮은 높이, 숫자 = 그만큼 위로 [m]')
    parser.add_argument('--speed-scale', type=float, default=1.0, help='속도 배율 (0 < s ≤ 1)')
    parser.add_argument('--wall-clearance', type=float, help='벽 마주 보기 벽 쪽 세 단계 최소 여유 [mm] (이 실행에서만)')
    parser.add_argument('--water-z', type=parse_water_surface_z, default='current', metavar='Z|design',
                        help='수면 z [m] (이 실행에서만). 기본 = water_level.yaml, design = 설계 수위 100 L')
    parser.add_argument('--no-smooth', action='store_true', help='블렌드 없이 경유점마다 멈춤 (비교용)')
    parser.add_argument('--step', action='store_true', help='경유점마다 Enter 로 진행 (블렌드 없음)')
    parser.add_argument('--go', action='store_true', help='점검을 통과하면 실제로 움직인다')
    parser.add_argument('--yes', action='store_true', help="확인 입력('yes') 생략. 대화형이 아닐 때만")
    parser.add_argument('--return-home', action='store_true', help='끝나면 move_home_safe.py --go 로 홈 복귀 (완료됐을 때만)')
    parser.add_argument('--offline', action='store_true', help='로봇 상태를 읽지 않는다 (계획 · 그림만)')
    parser.add_argument('--no-figure', action='store_true')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        return self_test()
    if not args.target and not args.zone:
        parser.error('--target 또는 --zone 이 필요합니다.')
    if not 0.0 < args.speed_scale <= 1.0:
        parser.error('--speed-scale 은 0 초과 1 이하')
    if args.step and args.yes:
        parser.error('--step 은 대화형이라 --yes 와 같이 쓸 수 없습니다.')

    planner = ZoneMotionPlanner.from_yaml(water_surface_z=args.water_z)
    print(f'수면: {planner.surface_source}')
    if args.wall_clearance is not None:
        planner.stage_min_clearance.update({s: args.wall_clearance / 1000.0 for s in WALL_STAGES})
    tp = TargetPolicyPlanner(planner, planner.cfg)
    solver, _loader = load_solver()
    if solver is not None:
        from arm_clearance import make_path_check
        tp.path_check = make_path_check(planner, solver)      # 팔 링크가 솥에 닿는 후보는 계획 단계에서 거른다
    t0 = time.monotonic()
    plan, title, target = make_plan(args, planner, tp)
    print(f'{title}  ({time.monotonic() - t0:.1f} s)')
    print(f'  계획: {"OK" if plan_ok(plan) else "실패"}  {getattr(plan, "reason", "")}')
    if not plan.waypoints:
        return 1
    check = getattr(plan, 'check', None)
    if check is not None:
        print(f'  최소 여유 {check.clearance.clearance_m * 1000:.0f} mm ({check.clearance_stage}), 팔 뻗음 {check.reach_m:.3f} m, '
              f'벽 쪽 다가감 {len(check.closing)}곳')
    if getattr(plan, 'params', None):
        print('  ' + ', '.join(f'{k} {v:.3f}' if isinstance(v, float) else f'{k} {v}' for k, v in plan.params.items()))

    info = prepare(planner, plan, args.air, args.speed_scale, solver, read_robot=not args.offline,
                   smooth=not (args.no_smooth or args.step))
    print()
    for row in moves_table(info['moves']):
        print('   ' + row)
    print()
    for line in info['lines']:
        print('  ' + line)
    problems = list(info['problems'])
    if args.offline and args.go:
        problems.append('--offline 으로는 움직일 수 없음')

    if not args.no_figure:
        from zone_motion_check import SWEEP_STAGES, coverage_cells, dilate, draw_motion, setup_matplotlib
        plt, _font = setup_matplotlib()
        cells = dilate(coverage_cells(planner.mouth_waterline_xy(plan.samples, stages=SWEEP_STAGES)))
        name = f'run_zone_{args.zone}' if args.zone else f'run_target_r{args.target[0]:.0f}_az{args.target[1]:.0f}_{args.policy}'
        out = HERE / f'{name}.png'
        draw_motion(plt, planner, plan, cells, out, target_xy=target)
        print(f'  그림: {out.name} (실제 높이 기준)')

    if problems:
        print('\n중단 조건:')
        for p in problems:
            print('  - ' + p)
    if not args.go:
        print('\n--go 가 없어 움직이지 않았습니다.')
        return 0 if not problems else 1
    if problems:
        return 1

    where = f'실제보다 {info["air"] * 100:.0f} cm 위 공중' if not info['real'] else '실제 높이 (스쿱이 국물에 들어감)'
    print(f'\n실행: {title} · {where} · movel {len(info["moves"])}개 · {"경유점마다 Enter" if args.step else "연속"}')
    if info['real']:
        print(f'확인: 수면이 계획 수위 ({planner.surface_source}) · 솥이 측정 때 자리 그대로 · 비상정지 버튼이 손 닿는 곳에 있는지')
    if not args.yes and not confirmed(input('움직이려면 yes 입력: ')):
        print('취소했습니다.')
        return 1

    started = dt.datetime.now()
    record = {}
    result, final_tcp = execute(info['moves'], args.step, planner.home.position, accel=info['accel'], record=record)
    err = float(np.linalg.norm(np.asarray(final_tcp[:3]) - info['moves'][-1][1])) * 1000
    info['metrics'] = motion_metrics(record.get('rows', []), info['samples'])
    print(f'\n결과: {result}. 마지막 TCP {np.round(final_tcp, 4).tolist()} (계획 끝과 {err:.1f} mm)')
    print(metrics_line(info['metrics']) + (f' (RTSI 오류: {record["error"]})' if record.get('error') else ''))
    log = write_log({'started': started, 'name': args.zone or args.policy, 'title': title,
                     'target_polar_cm_deg': args.target, 'zone': args.zone, 'policy': args.policy,
                     'wall_clearance_mm': args.wall_clearance, 'step': args.step, 'smooth': not (args.no_smooth or args.step)},
                    plan, info, result, final_tcp, record)
    print(f'기록: {log.relative_to(HERE)}')

    if args.return_home:
        if result != '완료':
            print('완료되지 않아 자동 홈 복귀는 하지 않습니다. 상태를 확인한 뒤 python3 move_home_safe.py --go')
        else:
            print('\n홈 복귀: move_home_safe.py --go')
            subprocess.run([sys.executable, str(HERE / 'move_home_safe.py'), '--go'], check=False)
    return 0 if result == '완료' else 1


if __name__ == '__main__':
    sys.exit(main())
