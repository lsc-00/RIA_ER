# ui/modify_panel.py
# 교반 좌표 수정 페이지를 담당합니다.
# 현재 교반 좌표를 표시하고 JSON에 저장된 위치로 수정합니다.

import flet as ft
import elite_cs_sdk as cs
import struct
import math
import time
import threading
import json
import os

from robot_controller import ROBOT_IP, HOME_POS_DEG, CENTER_JOINT_DEG, POSITIONS

def build_modify_page(page: ft.Page, on_back):
    # ── [좌측] 실시간 정보 섹션 ──────────────────────────────────

    stop_evt = threading.Event()
    
    # 조인트 각도 리스트 생성
    # 현재는 예시로 SCOOP_W1_DEG 데이터를 기본값으로 표시
    def create_joint_card(name, values):
        """각 위치(W1~W4)에 대한 전용 카드 생성"""
        joint_labels = ["J1", "J2", "J3", "J4", "J5", "J6"]
        
        # 조인트 값들을 가로로 나열 (공간 절약을 위해)
        row_content = ft.Row(
            [
                ft.Text(f"{joint_labels[i]}: {values[i]:.1f}°", size=12, color=ft.Colors.BLUE_GREY_700)
                for i in range(6)
            ],
            spacing=10,
            wrap=True
        )

        return ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Icon(ft.Icons.LOCATION_ON, size=16, color=ft.Colors.PURPLE),
                    ft.Text(name, weight="bold", size=14, color=ft.Colors.PURPLE_800),
                ]),
                ft.Divider(height=1, color=ft.Colors.PURPLE_100),
                row_content
            ], spacing=5),
            padding=12,
            bgcolor="#F3F0FA",
            border_radius=8,
            border=ft.border.all(1, "#E1D5F5"),
            margin=ft.margin.only(bottom=10)
        )

    def load_json_data():
        file_path = "teaching_data.json"
        if os.path.exists(file_path):
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                print(f"JSON 로드 오류: {e}")
                return {}
        return {}

    # ── 돌아가기 ─────────────────────────────────────
    def do_back(e):
        stop_evt.set()
        try:
            primary.disconnect()
        except Exception:
            pass
        on_back()

    # ── 좌측 리스트 생성 (W1 ~ W4) ──────────────────
    # 딕셔너리에서 필요한 키만 추출하여 카드로 변환
    target_keys = ["SCOOP_W1_DEG", "SCOOP_W2_DEG", "SCOOP_W3_DEG", "SCOOP_W4_DEG"]
    left_cards = []
    
    for key in target_keys:
        if key in POSITIONS:
            left_cards.append(create_joint_card(key, POSITIONS[key]))

    left_panel = ft.Column([
        ft.Row([
            ft.Icon(ft.Icons.LIST_ALT, color=ft.Colors.BLUE_GREY),
            ft.Text("저장된 위치 (W1-W4)", size=16, weight="bold")
        ]),
        ft.VerticalDivider(width=10, color=ft.Colors.TRANSPARENT),
        ft.Column(left_cards, scroll=ft.ScrollMode.AUTO, expand=True) # 위아래 배치
    ], expand=True)
    
    # ── 저장 로그 리스트 생성 ────────────────────────
    log_items = ft.Column(scroll=ft.ScrollMode.ALWAYS, expand=True)
    
    saved_data = load_json_data()
    
    # JSON 파일 내의 데이터를 반복문으로 추가
    for name, coords in saved_data.items():
        log_items.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.STORAGE, size=16, color=ft.Colors.BLUE_GREY_400),
                    ft.Column([
                        ft.Text(name, size=13, weight="bold"),
                        ft.Text(f"{coords}", size=11, color=ft.Colors.GREY_600),
                    ], spacing=2, expand=True),
                    ft.IconButton(
                        icon=ft.Icons.DELETE_OUTLINE,
                        icon_size=18,
                        icon_color=ft.Colors.RED_400,
                        tooltip="삭제"
                    )
                ]),
                padding=10,
                border=ft.border.all(1, ft.Colors.GREY_100),
                border_radius=5,
                margin=ft.margin.only(bottom=5),
                bgcolor=ft.Colors.GREY_50
            )
        )

    # ── 우측 하단 '저장 로그' 섹션 (수정된 부분) ───────
    log_section = ft.Container(
        content=log_items, # 위에서 만든 log_items를 여기에 배치
        expand=True,
        bgcolor=ft.Colors.WHITE,
        padding=10,
        border=ft.border.all(1, ft.Colors.GREY_300),
        border_radius=5,
        height=300 # 적절한 높이 설정
    )

    # ── 우측 패널 전체 조립 ──────────────────────────
    right_panel = ft.Column([
        # (상단 위치 저장 입력창 및 버튼들 - 기존 코드 유지)
        ft.Row([ft.Icon(ft.Icons.FILE_DOWNLOAD_OUTLINED, size=20), ft.Text("위치 저장", weight="bold")]),
        ft.TextField(label="위치 이름", border_color=ft.Colors.GREY_400),
        ft.ElevatedButton("💾 현재 위치 저장 (JSON 누적)", bgcolor=ft.Colors.PURPLE, color=ft.Colors.WHITE, width=1000),
        
        ft.Divider(height=20, color=ft.Colors.TRANSPARENT),
        
        # 하단 저장 로그 영역
        ft.Row([ft.Icon(ft.Icons.LIST_ALT, size=20), ft.Text("저장 로그 (JSON 파일 데이터)", weight="bold")]),
        log_section # JSON 데이터가 표시되는 곳
    ], expand=True)

    # ── 전체 레이아웃 조립 ─────────────────────────────────────
    return ft.Column([
        # ── 헤더 바 ──────────────────────────────────
        ft.Container(
            content=ft.Row([
                ft.FilledButton(
                    content=ft.Row([
                        ft.Icon(ft.Icons.ARROW_BACK, color="white", size=20),
                        ft.Text(
                            "제어 화면으로 돌아가기",
                            color="white", size=14,
                            weight=ft.FontWeight.BOLD,
                        ),
                    ], spacing=8),
                    style=ft.ButtonStyle(
                        bgcolor=ft.Colors.BLUE_GREY_600,
                        shape=ft.RoundedRectangleBorder(radius=8),
                    ),
                    on_click=do_back,
                ),
                ft.Row([
                    ft.Icon(ft.Icons.EDIT_LOCATION_ALT, size=24, color=ft.Colors.DEEP_PURPLE_700),
                    ft.Text(
                        "위치 수정 (Modify)",
                        size=22, weight=ft.FontWeight.BOLD,
                        color=ft.Colors.DEEP_PURPLE_700,
                    ),
                ], spacing=8),
                ft.Container(width=200),  # 중앙 정렬용 스페이서
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            bgcolor="white",
            padding=ft.padding.symmetric(horizontal=20, vertical=14),
            shadow=ft.BoxShadow(
                blur_radius=10,
                color=ft.Colors.with_opacity(0.08, ft.Colors.BLACK),
            ),
        ),
        # 메인 콘텐츠 (좌측: W1-W4 리스트, 우측: 기존 로그/입력창)
        ft.Container(
            content=ft.Row([
                ft.Container(content=left_panel, expand=1, padding=10),
                ft.VerticalDivider(width=1, color=ft.Colors.GREY_300),
                ft.Container(content=right_panel, expand=1, padding=10),
            ], expand=True),
            expand=True
        )
    ], expand=True)