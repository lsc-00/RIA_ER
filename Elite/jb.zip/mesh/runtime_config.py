#!/usr/bin/env python3
"""
로봇 실행 도구 설정 읽기: src/RIA_kettle/config/robot_runtime.yaml (환경변수 RIA_KETTLE_CONFIG_DIR 로 다른 폴더 지정 가능).

    from runtime_config import RT
    RT.robot.ip, RT.home_return.lift_tcp_z_m, ...     없는 키는 어느 절의 무슨 키인지 알려 주는 에러

    python3 runtime_config.py      robot_runtime.yaml 과 zone_motion.yaml 의 현재 값을 한 번에 출력

모든 값의 뜻 · 단위 · 언제 바꾸는지는 PARAMETERS.md.
"""

import sys
from pathlib import Path

import numpy as np
import yaml

sys.dont_write_bytecode = True

HERE = Path(__file__).resolve().parent
WS = next(p for p in HERE.parents if (p / 'src' / 'RIA_kettle').is_dir())
if str(WS / 'src' / 'RIA_kettle') not in sys.path:
    sys.path.insert(0, str(WS / 'src' / 'RIA_kettle'))

from ria_kettle import find_config  # noqa: E402


class Section(dict):
    """점(.)으로 읽는 설정 절. 없는 키는 파일 · 절 이름과 함께 알려 준다."""

    def __init__(self, data, where):
        super().__init__({k: Section(v, f'{where}.{k}') if isinstance(v, dict) else v for k, v in (data or {}).items()})
        self._where = where

    def __getattr__(self, name):
        if name.startswith('_'):
            raise AttributeError(name)
        try:
            return self[name]
        except KeyError:
            raise AttributeError(f'{self._where}.{name} 이 설정에 없습니다 (robot_runtime.yaml / PARAMETERS.md 확인).') from None

    def plain(self):
        return {k: v.plain() if isinstance(v, Section) else v for k, v in self.items()}


def load(path=None):
    path = find_config('robot_runtime.yaml') if path is None else Path(path)
    return Section(yaml.safe_load(Path(path).read_text(encoding='utf-8')), 'robot_runtime'), Path(path)


RT, RT_PATH = load()


def tcp_offset():
    """펜던트 TCP 오프셋 [x, y, z, rx, ry, rz] (플랜지 기준 m, rad)."""
    return [*map(float, RT.robot.tcp_offset_position_m), *map(float, RT.robot.tcp_offset_rotation_rad)]


def home_q():
    """홈 관절각 [rad]."""
    return np.radians(np.asarray(RT.robot.home_joints_deg, dtype=float))


def main():
    print(f'# {RT_PATH}')
    print(yaml.safe_dump(RT.plain(), allow_unicode=True, sort_keys=False))
    zone = find_config('zone_motion.yaml')
    print(f'# {zone}')
    print(yaml.safe_dump(yaml.safe_load(zone.read_text(encoding='utf-8')), allow_unicode=True, sort_keys=False))
    return 0


if __name__ == '__main__':
    sys.exit(main())
