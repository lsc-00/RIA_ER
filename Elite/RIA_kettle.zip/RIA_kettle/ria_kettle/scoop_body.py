#!/usr/bin/env python3
"""
스쿱 몸체(망 · 손잡이 · 손목)를 점으로 샘플링해, 로봇 TCP 자세에서 솥 경계까지 여유를 잰다.

    from ria_kettle import KettleModel, ScoopGeometry
    from ria_kettle.scoop_body import ScoopBody, ScoopMount, rpy_to_matrix
    body = ScoopBody(ScoopGeometry.from_yaml(), ScoopMount.from_yaml())
    c = body.clearance(kettle, tcp_xyz_base, rpy_to_matrix(tcp_rpy))
    c.clearance_m, c.part, c.point_base          # + 여유 / - 충돌, 가장 가까운 부분과 그 점

도구 좌표계
  펜던트 TCP = 스쿱 표식 (플랜지 기준 x 0, y −25, z 500 mm, 회전 0) → 축 방향이 플랜지와 같다.
  홈 자세 [0, −90, −90, −90, 90, 0]° 에서 도구 +x = 로봇 −Y, +y = 로봇 −X (로봇 쪽), +z = 아래.
  로봇이 보고하는 자세 (rx, ry, rz) 는 RPY (R = Rz · Ry · Rx).

모델
  망: 구 캡 (scoop.yaml 의 테두리 지름 · 깊이). 바닥 중심 = TCP, 입구 방향 = mount.opening_axis_in_tool.
      껍질 두께만큼 부풀려 잰다.
  캡슐: 손잡이 · 손목 같은 막대 부분. 선분 + 반경.
  솥 경계 부호는 KettleModel 과 같다 (림보다 높은 곳은 빈 공간, 림보다 낮은 솥 바깥은 막힘).
  물은 장애물로 보지 않는다. 로봇 팔 링크(손목 위)는 모델에 없다.
"""

import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import yaml

sys.dont_write_bytecode = True

try:                                   # ROS 패키지로 설치된 경우
    from .kettle_model import find_config
    from .scoop_path import ScoopGeometry
except ImportError:                    # 소스 폴더에서 스크립트로 실행하는 경우
    from kettle_model import find_config
    from scoop_path import ScoopGeometry


def rpy_to_matrix(rpy):
    """Elite 보고 자세 (rx, ry, rz) [rad] → 회전행렬. R = Rz · Ry · Rx."""
    a, b, c = (float(v) for v in rpy)
    ca, sa, cb, sb, cc, sc = np.cos(a), np.sin(a), np.cos(b), np.sin(b), np.cos(c), np.sin(c)
    Rx = np.array([[1.0, 0.0, 0.0], [0.0, ca, -sa], [0.0, sa, ca]])
    Ry = np.array([[cb, 0.0, sb], [0.0, 1.0, 0.0], [-sb, 0.0, cb]])
    Rz = np.array([[cc, -sc, 0.0], [sc, cc, 0.0], [0.0, 0.0, 1.0]])
    return Rz @ Ry @ Rx


def rotation_about(axis, angle):
    """단위축 axis 둘레로 angle [rad] 회전 (로드리게스)."""
    k = np.asarray(axis, dtype=float)
    k = k / np.linalg.norm(k)
    K = np.array([[0.0, -k[2], k[1]], [k[2], 0.0, -k[0]], [-k[1], k[0], 0.0]])
    return np.eye(3) + np.sin(angle) * K + (1.0 - np.cos(angle)) * (K @ K)


@dataclass(frozen=True)
class Capsule:
    name: str
    start_m: tuple
    end_m: tuple
    radius_m: float


@dataclass(frozen=True)
class ScoopMount:
    """스쿱이 도구 좌표계에 어떻게 붙어 있는지."""
    opening_axis_in_tool: tuple
    shell_thickness_m: float = 0.003
    capsules: tuple = ()

    @classmethod
    def from_yaml(cls, path=None):
        path = find_config('scoop.yaml') if path is None else path
        doc = yaml.safe_load(Path(path).read_text(encoding='utf-8'))
        mount = doc.get('mount')
        if not mount:
            raise ValueError(f'{path} 에 mount (스쿱 장착 자세) 가 없습니다.')
        axis = np.asarray(mount['opening_axis_in_tool'], dtype=float)
        if axis.shape != (3,) or np.linalg.norm(axis) < 1e-9:
            raise ValueError('mount.opening_axis_in_tool 은 길이가 0 이 아닌 3개 값이어야 합니다.')
        capsules = tuple(Capsule(str(c['name']), tuple(float(v) for v in c['start_m']),
                                 tuple(float(v) for v in c['end_m']), float(c['radius_m']))
                         for c in mount.get('capsules', []))
        return cls(tuple(float(v) for v in axis / np.linalg.norm(axis)),
                   float(mount.get('shell_thickness_m', 0.003)), capsules)


@dataclass(frozen=True)
class Clearance:
    clearance_m: float
    part: str
    point_base: np.ndarray


class ScoopBody:
    """도구 좌표계의 스쿱 표면 점들. step_m 간격으로 샘플링한다."""

    CAP = '망'

    def __init__(self, scoop: ScoopGeometry, mount: ScoopMount, step_m=0.01):
        self.scoop, self.mount = scoop, mount
        cap_points = self.cap_points_tool(scoop, mount.opening_axis_in_tool, step_m)
        points = [cap_points]
        inflate = [np.full(len(cap_points), mount.shell_thickness_m)]
        parts = [np.full(len(cap_points), self.CAP, dtype=object)]
        for capsule in mount.capsules:
            a, b = np.asarray(capsule.start_m), np.asarray(capsule.end_m)
            n = max(int(np.ceil(np.linalg.norm(b - a) / step_m)), 1)
            seg = a + np.linspace(0.0, 1.0, n + 1)[:, None] * (b - a)
            points.append(seg)
            inflate.append(np.full(len(seg), capsule.radius_m))
            parts.append(np.full(len(seg), capsule.name, dtype=object))
        self.points_tool = np.vstack(points)
        self.inflate = np.concatenate(inflate)
        self.parts = np.concatenate(parts)

    @staticmethod
    def cap_points_tool(scoop, opening_axis, step_m):
        """망(구 캡) 표면 점. 바닥 중심 = 원점, opening_axis 쪽이 입구."""
        d = np.asarray(opening_axis, dtype=float)
        d = d / np.linalg.norm(d)
        u = np.cross(d, [1.0, 0.0, 0.0])
        if np.linalg.norm(u) < 0.1:
            u = np.cross(d, [0.0, 1.0, 0.0])
        u /= np.linalg.norm(u)
        w = np.cross(d, u)
        radius = scoop.sphere_radius_m
        cap = np.radians(scoop.cap_half_angle_deg)
        center = radius * d
        points = [np.zeros((1, 3))]
        for phi in np.linspace(0.0, cap, max(int(np.ceil(radius * cap / step_m)), 1) + 1)[1:]:
            n = max(int(np.ceil(2 * np.pi * radius * np.sin(phi) / step_m)), 6)
            psi = np.linspace(0.0, 2 * np.pi, n, endpoint=False)
            ring = (np.cos(psi)[:, None] * u + np.sin(psi)[:, None] * w) * np.sin(phi) - np.cos(phi) * d
            points.append(center + radius * ring)
        return np.vstack(points)

    def rim_top_tool(self):
        """망 테두리에서 도구 −z(위) 쪽으로 가장 높은 점."""
        cap = self.cap_points_tool(self.scoop, self.mount.opening_axis_in_tool, 0.005)
        return cap[np.argmin(cap[:, 2])]

    def points_base(self, position, R):
        return np.asarray(position, dtype=float) + self.points_tool @ np.asarray(R, dtype=float).T

    def clearances(self, kettle, position, R):
        """모든 표면 점의 여유 [m] 배열과 그 점들의 base 좌표."""
        p = self.points_base(position, R)
        return np.asarray(kettle.signed_distance_xyz(p, frame='base')) - self.inflate, p

    def clearance(self, kettle, position, R):
        """TCP 가 base 좌표 position, 회전 R 일 때 스쿱과 솥 경계 사이 최소 여유."""
        sd, p = self.clearances(kettle, position, R)
        i = int(np.argmin(sd))
        return Clearance(float(sd[i]), str(self.parts[i]), p[i])

    def worst_clearance(self, kettle, samples):
        """samples: [(단계 이름, position, R), ...] → (가장 작은 여유, 그 단계 이름)."""
        worst, label = None, None
        for name, position, R in samples:
            c = self.clearance(kettle, position, R)
            if worst is None or c.clearance_m < worst.clearance_m:
                worst, label = c, name
        return worst, label
