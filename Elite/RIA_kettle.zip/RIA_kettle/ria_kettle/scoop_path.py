#!/usr/bin/env python3
"""
스쿱형 뜰채로 솥 벽을 따라 떠내는 자세 · 경로 계산.

    python3 scoop_path.py        # 도구 치수 + 100 L 수면 부근 경로 예시 + 자체 점검

    from kettle_model import KettleModel
    from scoop_path import ScoopGeometry, WallScoopPlanner
    planner = WallScoopPlanner(KettleModel.from_yaml(), ScoopGeometry.from_yaml(), clearance_m=0.010)
    pose = planner.pose_at(0.22)                 # 벽 높이 0.22 m 에 망을 댄 자세
    path = planner.waterline_path()              # 수면 아래 80 mm → 수면 위 30 mm, 벽을 따라 떠올리기
    tcp_xyz, rotation = pose.to_kettle_xyz(azimuth_rad)   # 음식 방위의 단면에 놓은 3D 자세

도구 모델
  망을 구의 일부(구 캡)로 본다. scoop.yaml 의 테두리 지름과 깊이로 구 반경과 캡 범위를 구한다.
  TCP 는 망 바닥 중심이다 (평면 보정과 같은 기준점). 도구 축은 망 바닥에서 입구 쪽을 향한다.
  손잡이는 망 테두리에서 솥 중심 쪽으로 뻗는다고 본다.

벽 따라가기
  벽이 원호라서, 원호 중심(피벗)을 기준으로 도구를 통째로 돌리면 망의 같은 점이 벽과 같은 간격을
  유지한 채 벽을 따라간다. 이때 TCP 도 피벗을 중심으로 원을 그리고, 뜰채 기울기는 회전한 각도만큼 바뀐다.
  망 반경(구)이 벽 원호 반경보다 작으면 망은 벽에 한 점으로만 닿는다.

기울기 부호
  tilt_deg > 0 : 도구 축 위쪽이 솥 중심 쪽으로 기움 (망 뒷면이 벽을 향한다)
  tilt_deg < 0 : 도구 축 위쪽이 벽 쪽으로 기움 (망 입구가 벽을 향한다)

좌표
  솥 좌표계 (kettle_model.py 참고). 음식이 있는 방위의 단면 (r, h) 에서 계산하고
  to_kettle_xyz(방위) 로 3D 로 옮긴다. 구 중심이 단면 위에 있으므로 단면에서 잰 여유가 3D 여유와 같다.
"""

import sys
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import yaml

sys.dont_write_bytecode = True

try:                                   # ROS 패키지로 설치된 경우
    from .kettle_model import KettleModel, direction, find_config  # noqa: E402
except ImportError:                    # dev_log/jb/mesh 의 바로가기로 스크립트 실행하는 경우
    from kettle_model import KettleModel, direction, find_config  # noqa: E402


@dataclass(frozen=True)
class ScoopGeometry:
    """스쿱형 뜰채. 망은 구의 일부(구 캡)."""
    rim_diameter_m: float
    depth_m: float
    handle_length_m: float = 0.30
    handle_diameter_m: float = 0.025

    @classmethod
    def from_yaml(cls, path=None):
        path = find_config('scoop.yaml') if path is None else path
        doc = yaml.safe_load(Path(path).read_text(encoding='utf-8'))['scoop']
        keys = ('rim_diameter_m', 'depth_m', 'handle_length_m', 'handle_diameter_m')
        return cls(**{k: float(doc[k]) for k in keys if k in doc})

    @property
    def rim_radius_m(self):
        return self.rim_diameter_m / 2

    @property
    def sphere_radius_m(self):
        """테두리 반경 a, 깊이 d 인 구 캡의 구 반경 = (a² + d²) / 2d."""
        a, d = self.rim_radius_m, self.depth_m
        return (a * a + d * d) / (2 * d)

    @property
    def cap_half_angle_deg(self):
        """구 중심에서 잰, 망 바닥에서 테두리까지의 각도."""
        radius = self.sphere_radius_m
        return float(np.degrees(np.arccos((radius - self.depth_m) / radius)))


@dataclass(frozen=True)
class ScoopPose:
    """단면 (r, h) 위의 뜰채 자세."""
    contact_h_m: float                 # 망이 가장 가까이 가는 벽 위 점
    contact_r_m: float
    wall_piece: str                    # 그 점이 있는 벽 원호
    pivot_rh_m: tuple                  # 벽 원호 중심 = 회전 중심
    wall_tilt_deg: float               # 그 점의 벽 기울기 (0 = 수직)
    tilt_deg: float                    # 뜰채 축 기울기 (+ 솥 중심 쪽)
    sphere_center_rh_m: tuple          # 망 구의 중심
    tcp_rh_m: tuple                    # 망 바닥 중심
    rim_wall_side_rh_m: tuple          # 단면 위 망 테두리 (벽 쪽)
    rim_center_side_rh_m: tuple        # 단면 위 망 테두리 (솥 중심 쪽, 손잡이 붙는 곳)
    clearance_m: float                 # 경계까지 실제 최소 여유 (수치로 다시 잰 값)

    @property
    def axis_rh(self):
        t = np.radians(self.tilt_deg)
        return np.array([-np.sin(t), np.cos(t)])

    @property
    def handle_rh(self):
        """도구 축에 수직, 솥 중심 쪽 (손잡이 방향)."""
        t = np.radians(self.tilt_deg)
        return np.array([-np.cos(t), -np.sin(t)])

    @property
    def pivot_distance_m(self):
        return float(np.hypot(self.tcp_rh_m[0] - self.pivot_rh_m[0], self.tcp_rh_m[1] - self.pivot_rh_m[1]))

    def to_kettle_xyz(self, azimuth_rad):
        """방위 azimuth 단면의 자세를 솥 좌표계 3D 로. (TCP 위치, 회전행렬 열 = [손잡이 x, y, 도구 축 z])"""
        e_r = np.array([np.cos(azimuth_rad), np.sin(azimuth_rad), 0.0])
        e_z = np.array([0.0, 0.0, 1.0])

        def lift(v):
            return v[0] * e_r + v[1] * e_z

        x_axis, z_axis = lift(self.handle_rh), lift(self.axis_rh)
        y_axis = np.cross(z_axis, x_axis)
        return lift(np.asarray(self.tcp_rh_m)), np.column_stack([x_axis, y_axis, z_axis])


class WallScoopPlanner:
    """망의 정해진 점이 벽에서 clearance 만큼 떨어져 벽을 따라가도록 자세를 만든다.

    rim_margin_deg: 망 테두리에서 이 각도만큼 바닥 쪽 점을 벽에 댄다. 테두리가 벽에 먼저 닿지 않게 하는 여유.
    """

    def __init__(self, kettle, scoop, clearance_m=0.010, rim_margin_deg=5.0):
        self.kettle = kettle
        self.scoop = scoop
        self.clearance_m = float(clearance_m)
        self.rim_margin_deg = float(rim_margin_deg)
        self.contact_angle_deg = scoop.cap_half_angle_deg - self.rim_margin_deg
        if not 0.0 <= self.contact_angle_deg <= scoop.cap_half_angle_deg:
            raise ValueError(f'rim_margin_deg 는 0 ~ {scoop.cap_half_angle_deg:.1f}° 여야 합니다.')
        limit = scoop.sphere_radius_m + self.clearance_m
        for arc in kettle.walls:
            if arc.radius <= limit:
                raise ValueError(f'{arc.name} 반경 {arc.radius:.3f} m 가 망 구 반경 + 여유({limit:.3f} m)보다 작아 '
                                 '한 점 접촉이 되지 않습니다.')

    def pose_at(self, contact_h):
        kettle, scoop = self.kettle, self.scoop
        arc, alpha = kettle.wall_arc_at(contact_h)
        radius = scoop.sphere_radius_m
        sphere = arc.center + (arc.radius - radius - self.clearance_m) * direction(alpha)
        tilt = alpha - np.radians(self.contact_angle_deg)
        axis = np.array([-np.sin(tilt), np.cos(tilt)])
        handle = np.array([-np.cos(tilt), -np.sin(tilt)])
        cap = np.radians(scoop.cap_half_angle_deg)
        rim_base = sphere - radius * np.cos(cap) * axis
        contact = arc.point(alpha)
        return ScoopPose(
            contact_h_m=float(contact[1]), contact_r_m=float(contact[0]), wall_piece=arc.name,
            pivot_rh_m=(float(arc.center[0]), float(arc.center[1])),
            wall_tilt_deg=float(90.0 - np.degrees(alpha)), tilt_deg=float(np.degrees(tilt)),
            sphere_center_rh_m=(float(sphere[0]), float(sphere[1])),
            tcp_rh_m=tuple(float(v) for v in sphere - radius * axis),
            rim_wall_side_rh_m=tuple(float(v) for v in rim_base - radius * np.sin(cap) * handle),
            rim_center_side_rh_m=tuple(float(v) for v in rim_base + radius * np.sin(cap) * handle),
            clearance_m=float(kettle.sphere_clearance(sphere[0], sphere[1], radius)))

    def path(self, h_start, h_end, step_m=0.005):
        """벽 위 접촉 높이 h_start → h_end. 벽 호 길이 step_m 간격, 원호 이음점은 반드시 포함한다."""
        kettle = self.kettle
        lo, hi = sorted((float(h_start), float(h_end)))
        knots = [lo] + [a.end[1] for a in kettle.walls[:-1] if lo < a.end[1] < hi] + [hi]
        heights = []
        for a, b in zip(knots[:-1], knots[1:]):
            arc, _ = kettle.wall_arc_at(0.5 * (a + b))
            alpha_a = np.arccos(np.clip((arc.center[1] - a) / arc.radius, -1.0, 1.0))
            alpha_b = np.arccos(np.clip((arc.center[1] - b) / arc.radius, -1.0, 1.0))
            n = max(int(np.ceil((alpha_b - alpha_a) * arc.radius / step_m)), 1)
            hs = arc.center[1] - arc.radius * np.cos(np.linspace(alpha_a, alpha_b, n + 1))
            hs[0], hs[-1] = a, b
            heights.extend(hs if not heights else hs[1:])
        if h_start > h_end:
            heights = heights[::-1]
        return [self.pose_at(h) for h in heights]

    def waterline_path(self, below_m=0.08, above_m=0.03, step_m=0.005):
        """운용 수면 아래 below_m 에서 수면 위 above_m 까지 벽을 따라 떠올리는 경로."""
        level = self.kettle.level_h
        return self.path(level - below_m, min(level + above_m, self.kettle.wall_top[1]), step_m)


def _self_test(kettle, scoop, planner):
    results = []

    def report(name, ok, detail):
        results.append(bool(ok))
        print(f'  [{"OK" if ok else "FAIL"}] {name}: {detail}')

    a, d, radius = scoop.rim_radius_m, scoop.depth_m, scoop.sphere_radius_m
    report('망 테두리 점이 구 위에 있다', abs(np.hypot(a, d - radius) - radius) < 1e-12,
           f'구 반경 {radius * 1000:.2f} mm')

    path = planner.path(0.02, kettle.wall_top[1] - 0.005, 0.004)     # 두 벽 원호를 모두 지나는 경로
    clearance = np.array([p.clearance_m for p in path])
    report('모든 자세에서 망 여유 = 설정값', np.abs(clearance - planner.clearance_m).max() < 1e-6,
           f'자세 {len(path)}개, 최대 차이 {np.abs(clearance - planner.clearance_m).max() * 1000:.5f} mm')

    rims = np.array([p.rim_wall_side_rh_m for p in path] + [p.rim_center_side_rh_m for p in path])
    rim_d = kettle.signed_distance(rims[:, 0], rims[:, 1])
    report('망 테두리는 설정 여유보다 멀다', rim_d.min() >= planner.clearance_m - 1e-9, f'최소 {rim_d.min() * 1000:.2f} mm')

    for arc in kettle.walls:
        seg = [p for p in path if p.wall_piece == arc.name]
        if len(seg) < 2:
            continue
        dist = np.array([p.pivot_distance_m for p in seg])
        offset = np.array([p.tilt_deg - (90.0 - p.wall_tilt_deg) for p in seg])
        report(f'{arc.name}: TCP 가 피벗 중심 원 위를 돈다', np.ptp(dist) < 1e-9 and np.ptp(offset) < 1e-9,
               f'반경 {dist.mean() * 1000:.2f} mm, 기울기 − 벽 각도 = {offset.mean():.3f}° 로 일정')

    tcp = np.array([p.tcp_rh_m for p in path])
    tilt = np.array([p.tilt_deg for p in path])
    step = np.hypot(*np.diff(tcp, axis=0).T)
    report('원호 이음점을 지나도 TCP · 기울기가 끊기지 않는다', step.max() < 0.0045 and np.abs(np.diff(tilt)).max() < 1.0,
           f'TCP 최대 간격 {step.max() * 1000:.2f} mm, 기울기 최대 변화 {np.abs(np.diff(tilt)).max():.2f}°')

    pose = planner.pose_at(kettle.level_h)
    position, rotation = pose.to_kettle_xyz(np.radians(30.0))
    ortho = np.abs(rotation.T @ rotation - np.eye(3)).max()
    report('3D 자세 회전행렬이 직교 · 오른손 좌표', ortho < 1e-12 and abs(np.linalg.det(rotation) - 1) < 1e-12,
           f'직교 오차 {ortho:.1e}')
    return all(results)


def main():
    kettle = KettleModel.from_yaml()
    scoop = ScoopGeometry.from_yaml()
    planner = WallScoopPlanner(kettle, scoop)

    print('스쿱형 뜰채')
    print(f'  테두리 지름 {scoop.rim_diameter_m * 1000:.0f} mm, 깊이 {scoop.depth_m * 1000:.0f} mm → '
          f'구 반경 {scoop.sphere_radius_m * 1000:.1f} mm, 구면 범위 망 바닥에서 {scoop.cap_half_angle_deg:.1f}°')
    print(f'  벽에 대는 점: 망 바닥에서 {planner.contact_angle_deg:.1f}° (테두리까지 {planner.rim_margin_deg:.0f}°), '
          f'여유 {planner.clearance_m * 1000:.0f} mm')

    level = kettle.level_h
    upright = 90.0 - kettle.wall_tilt_deg(level)
    print(f'\n국물 {kettle.soup_volume_L:.0f} L 수면 (h {level * 1000:.1f} mm) 의 벽에 망을 수평으로 대면 닿는 점: '
          f'망 바닥에서 {upright:.1f}° → 구면 범위 {scoop.cap_half_angle_deg:.1f}° '
          f'{"안 (구면이 닿음)" if upright <= scoop.cap_half_angle_deg else "밖 (테두리가 먼저 닿음)"}')

    path = planner.waterline_path()
    print(f'\n수면 아래 80 mm → 수면 위 30 mm, 벽을 따라 떠올리기 ({len(path)} 자세)')
    print('   접촉 h   벽          벽기울기  뜰채기울기   TCP (r, h) mm       테두리 h 벽쪽/중심쪽   여유')
    for pose in path[::5] + ([path[-1]] if (len(path) - 1) % 5 else []):
        print(f'  {pose.contact_h_m * 1000:6.1f}   {pose.wall_piece:10s}  {pose.wall_tilt_deg:5.1f}°   {pose.tilt_deg:+6.1f}°'
              f'   ({pose.tcp_rh_m[0] * 1000:5.1f}, {pose.tcp_rh_m[1] * 1000:5.1f})'
              f'     {pose.rim_wall_side_rh_m[1] * 1000:5.1f} / {pose.rim_center_side_rh_m[1] * 1000:5.1f}'
              f'     {pose.clearance_m * 1000:.1f} mm')
    first, last = path[0], path[-1]
    tcp_len = float(np.sum(np.hypot(*np.diff(np.array([p.tcp_rh_m for p in path]), axis=0).T)))
    print(f'  → 피벗 (r {first.pivot_rh_m[0] * 1000:.1f}, h {first.pivot_rh_m[1] * 1000:.1f}) mm 기준 '
          f'{last.tilt_deg - first.tilt_deg:.2f}° 회전, TCP 는 반경 {first.pivot_distance_m * 1000:.1f} mm 원을 따라 '
          f'{tcp_len * 1000:.1f} mm 이동')

    print('\n자체 점검')
    return 0 if _self_test(kettle, scoop, planner) else 1


if __name__ == '__main__':
    sys.exit(main())
