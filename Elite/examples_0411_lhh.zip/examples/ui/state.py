# ui/state.py
# 버튼 활성화 상태, 토글 참조, 파라미터 등
# UI 전체에서 공유하는 상태를 한 곳에서 관리합니다.

import flet as ft


class AppState:
    def __init__(self, params: dict):
        # 슬라이더에서 실시간으로 수정되는 파라미터
        self.default_params: dict = dict(params)
        self.current_params: dict = dict(params)

        # 태스크 실행 중 비활성화할 버튼 목록
        self.action_buttons: list[ft.FilledButton] = []

        # 일시정지 토글 버튼 참조
        self.toggle_refs: dict = {
            "is_paused": False,
            "btn":       None,
            "icon":      None,
            "text":      None,
        }

    def register_action_button(self, btn: ft.FilledButton):
        """태스크 실행 중 비활성화될 버튼을 등록합니다."""
        self.action_buttons.append(btn)

    def set_buttons_disabled(self, disabled: bool, page: ft.Page):
        """등록된 모든 액션 버튼을 일괄 활성/비활성합니다."""
        for btn in self.action_buttons:
            btn.disabled = disabled
        try:
            page.update()
        except Exception:
            pass

    def reset_pause_toggle(self, page: ft.Page):
        """태스크 종료 시 일시정지 버튼을 기본 상태로 되돌립니다."""
        refs = self.toggle_refs
        if not refs.get("is_paused", False):
            return
        refs["is_paused"] = False
        refs["icon"].name = ft.Icons.PAUSE_CIRCLE_FILLED
        refs["text"].value = "일시정지\n(PAUSE)"
        refs["btn"].style.bgcolor = ft.Colors.ORANGE_600
        try:
            page.update()
        except Exception:
            pass

    def reset_params(self):
        """모든 파라미터를 기본값으로 되돌립니다."""
        for k, v in self.default_params.items():
            self.current_params[k] = v