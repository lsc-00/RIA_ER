# ui/auto_panel.py
# 우측 자동제어 패널 (비상정지, 자동시퀀스, 일시정지, 로그)을 담당합니다.

import flet as ft
from config import AUTO_BUTTON, PAUSE_BUTTON, STOP_BUTTON, LAYOUT, LABELS
from ui.state import AppState


def build_auto_panel(
    state: AppState,
    page: ft.Page,
    log_list: ft.ListView,
    on_run_task,
    on_instant_action,
) -> ft.Container:

    # ── 비상정지 버튼 ─────────────────────────────────
    btn_stop = ft.FilledButton(
        content=ft.Row([
            ft.Icon(ft.Icons.WARNING_AMBER_ROUNDED, size=40, color="white"),
            ft.Text(STOP_BUTTON["label"], size=24, weight="bold", color="white"),
        ], alignment=ft.MainAxisAlignment.CENTER),
        style=ft.ButtonStyle(
            shape=ft.RoundedRectangleBorder(radius=LAYOUT["btn_border_radius"]),
            bgcolor=STOP_BUTTON["color"],
        ),
        width=float("inf"),
        height=LAYOUT["stop_btn_height"],
        on_click=lambda e: on_instant_action("STOP"),
    )

    # ── 전체 시퀀스 버튼 ──────────────────────────────
    btn_auto = ft.FilledButton(
        content=ft.Column([
            ft.Icon(ft.Icons.PLAY_CIRCLE_FILLED, size=60, color="white"),
            ft.Text(AUTO_BUTTON["label"], size=26, weight="bold", color="white"),
            ft.Text(AUTO_BUTTON["sublabel"], size=14, color="white"),
        ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
        style=ft.ButtonStyle(
            shape=ft.RoundedRectangleBorder(radius=20),
            bgcolor=AUTO_BUTTON["color"],
        ),
        expand=4,
        height=LAYOUT["auto_btn_height"],
        on_click=lambda e: on_run_task("ALL"),
    )
    state.register_action_button(btn_auto)

    # ── 일시정지 / 재개 토글 버튼 ────────────────────
    toggle_icon = ft.Icon(ft.Icons.PAUSE_CIRCLE_FILLED, size=40, color="white")
    toggle_text = ft.Text(
        PAUSE_BUTTON["pause_label"],
        size=16, weight="bold",
        color="white", text_align=ft.TextAlign.CENTER,
    )
    toggle_btn = ft.FilledButton(
        content=ft.Column([
            toggle_icon,
            toggle_text,
        ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
        style=ft.ButtonStyle(
            shape=ft.RoundedRectangleBorder(radius=20),
            bgcolor=PAUSE_BUTTON["pause_color"],
        ),
        expand=1,
        height=LAYOUT["auto_btn_height"],
    )

    state.toggle_refs["btn"]  = toggle_btn
    state.toggle_refs["icon"] = toggle_icon
    state.toggle_refs["text"] = toggle_text

    def toggle_pause_resume(e):
        refs = state.toggle_refs
        if refs["is_paused"]:
            on_instant_action("RESUME")
            refs["is_paused"]       = False
            refs["icon"].name       = ft.Icons.PAUSE_CIRCLE_FILLED
            refs["text"].value      = PAUSE_BUTTON["pause_label"]
            refs["btn"].style.bgcolor = PAUSE_BUTTON["pause_color"]
        else:
            on_instant_action("PAUSE")
            refs["is_paused"]       = True
            refs["icon"].name       = ft.Icons.PLAY_CIRCLE_FILLED
            refs["text"].value      = PAUSE_BUTTON["resume_label"]
            refs["btn"].style.bgcolor = PAUSE_BUTTON["resume_color"]
        page.update()

    toggle_btn.on_click = toggle_pause_resume

    return ft.Container(
        content=ft.Column([
            ft.Text(LABELS["auto_section"], size=18, weight="bold"),

            # 비상정지
            ft.Container(
                content=btn_stop,
                padding=ft.padding.only(bottom=10),
            ),

            # 자동시퀀스 + 일시정지 토글
            ft.Container(
                content=ft.Row([btn_auto, toggle_btn], spacing=15),
                padding=ft.padding.only(bottom=20),
            ),

            # 로그
            ft.Container(
                content=log_list,
                bgcolor="white",
                border_radius=10,
                border=ft.border.all(1, ft.Colors.GREY_300),
                expand=True,
                padding=10,
            ),
        ], spacing=15, expand=True),
        expand=1,
        padding=LAYOUT["panel_padding"],
        border_radius=LAYOUT["panel_border_radius"],
    )