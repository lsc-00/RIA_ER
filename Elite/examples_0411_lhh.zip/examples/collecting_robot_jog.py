import flet as ft
import elite_cs_sdk as cs
import time
import threading
import struct
import json
import os
import math

# [설정] 로봇 IP
ROBOT_IP = "192.168.0.100"

# [설정] 주요 위치 (Degree 단위)
HOME_POS_DEG     = [0.0, -90.0, -90.0, -90.0, 90.0, 0.0]
CENTER_JOINT_DEG = [25.1, -83.00, -139.31, -47.68, 90.01, -69.29]


class CartesianInfoPackage(cs.PrimaryPackage):
    def __init__(self):
        super().__init__(4)
        self.pose = None

    def parser(self, data: bytes):
        try:
            self.pose = list(struct.unpack_from('>iBdddddddddddd', data)[2:8])
        except:
            self.pose = None


class JointInfoPackage(cs.PrimaryPackage):
    def __init__(self):
        super().__init__(1)
        self.joint_pos = None

    def parser(self, data: bytes):
        try:
            self.joint_pos = list(struct.unpack_from('>iBdddddd', data)[2:8])
        except:
            self.joint_pos = None


class RobotTeacher:
    def __init__(self):
        self.primary   = cs.PrimaryClientInterface()
        self.dashboard = cs.DashboardClientInterface()
        self.j_pkg     = JointInfoPackage()
        self.p_pkg     = CartesianInfoPackage()

    def move_to_pose(self, joints_deg):
        """지정된 각도로 로봇 이동 (Degree -> Radian 변환)"""
        def deg_to_rad(deg): return deg * (math.pi / 180.0)
        joints_rad_str = "[" + ", ".join([f"{deg_to_rad(j):.5f}" for j in joints_deg]) + "]"

        if not self.primary.connect(ROBOT_IP, 30001):
            return False, "❌ Primary 연결 실패"

        self.primary.sendScript(f"movej({joints_rad_str}, a=0.5, v=0.3)")
        return True, "🚀 이동 중..."

    def boot_and_home(self, status_callback):
        """로봇 부팅 후 홈 위치로 이동"""
        if not self.dashboard.connect(ROBOT_IP, 29999):
            return False, "❌ 대시보드 연결 실패"

        status_callback("⚡ 전원 켜는 중...")
        self.dashboard.powerOn()
        time.sleep(7)

        status_callback("🔓 브레이크 해제 중...")
        self.dashboard.brakeRelease()
        time.sleep(5)
        self.dashboard.disconnect()

        status_callback("🚀 홈 위치로 이동 중...")
        success, msg = self.move_to_pose(HOME_POS_DEG)
        if success:
            time.sleep(6)
            return True, "✅ 홈 위치 도착 및 연결 성공"
        return False, msg

    def get_robot_data(self):
        joints, pose = None, None
        if self.primary.getPackage(self.j_pkg, 1000):
            joints = self.j_pkg.joint_pos
        if self.primary.getPackage(self.p_pkg, 1000):
            pose = self.p_pkg.pose
        return joints, pose


def main(page: ft.Page):
    page.title      = "Elite Robot Position Recorder"
    page.theme_mode = ft.ThemeMode.DARK

    teacher      = RobotTeacher()
    save_counter = [1]
    JSON_FILE    = "teaching_data.json"

    # ── 상태 및 표시용 UI 요소 ────────────────────────
    status_text = ft.Text("상태: 초기화 중...", color="yellow")

    joint_labels = [
        "J1 Base", "J2 Shoulder", "J3 Elbow",
        "J4 Wrist 1", "J5 Wrist 2", "J6 Wrist 3",
    ]
    # ✅ weight="w500" → ft.FontWeight.W_500
    joint_texts = [
        ft.Text(f"{label}: 0.00°", size=14, weight=ft.FontWeight.W_500)
        for label in joint_labels
    ]
    joint_display_col = ft.Column(controls=joint_texts, spacing=2, tight=True)
    pose_display      = ft.Text("Pose (m/rad): [연결 대기]", size=14)

    # ✅ auto_scroll 제거 → scroll_to로 수동 처리
    log_view = ft.ListView(expand=True, spacing=5)

    def scroll_log_to_bottom():
        try:
            log_view.scroll_to(offset=-1, duration=200)
        except Exception:
            pass

    # ── 버튼 클릭 핸들러 ─────────────────────────────
    def save_position(e):
        j, p = teacher.get_robot_data()
        if j and p:
            base_name = memo_input.value.strip()
            if not base_name:
                memo = f"pos_{save_counter[0]}"
                save_counter[0] += 1
            else:
                memo = base_name

            j_deg     = [round(x * 57.2958, 2) for x in j]
            p_rounded = [round(x, 4) for x in p]

            # 텍스트 저장
            line = (
                f"[{time.strftime('%H:%M:%S')}] {memo}\n"
                f" - Joint(deg): {j_deg}\n"
                f" - Pose(m): {p_rounded}\n\n"
            )
            with open("saved_positions.txt", "a", encoding="utf-8") as f:
                f.write(line)

            # JSON 저장
            data = {}
            if os.path.exists(JSON_FILE):
                try:
                    with open(JSON_FILE, "r", encoding="utf-8") as f:
                        data = json.load(f)
                except:
                    data = {}

            if memo not in data:
                data[memo] = {"joints": [], "poses": []}
            data[memo]["joints"].append(j_deg)
            data[memo]["poses"].append(p_rounded)

            with open(JSON_FILE, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4, ensure_ascii=False)

            count = len(data[memo]["joints"])
            log_view.controls.insert(
                0,
                ft.Text(f"💾 [{memo}] #{count} 저장됨", color="green"),
            )
            scroll_log_to_bottom()
            page.update()
        else:
            status_text.value = "❌ 데이터 읽기 실패"
            page.update()

    def go_home(e):
        success, msg = teacher.move_to_pose(HOME_POS_DEG)
        status_text.value = f"홈으로: {msg}"
        page.update()

    def go_center(e):
        success, msg = teacher.move_to_pose(CENTER_JOINT_DEG)
        status_text.value = f"초기위치로: {msg}"
        page.update()

    def clear_sequence(e):
        base_name = memo_input.value.strip()
        if not base_name:
            return
        if os.path.exists(JSON_FILE):
            try:
                with open(JSON_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if base_name in data:
                    del data[base_name]
                    with open(JSON_FILE, "w", encoding="utf-8") as f:
                        json.dump(data, f, indent=4)
                    log_view.controls.insert(
                        0,
                        ft.Text(f"🗑️ [{base_name}] 데이터 초기화됨", color="orange"),
                    )
                    page.update()
            except:
                pass

    # ── 입력창 ───────────────────────────────────────
    memo_input = ft.TextField(
        label="위치 이름 (예: stir, scoop)",
        width=400,
        on_submit=save_position,
    )

    # ── 백그라운드 루프 ───────────────────────────────
    def update_loop():
        def status_cb(m):
            status_text.value = m
            page.update()

        success, msg = teacher.boot_and_home(status_cb)
        status_text.value = msg
        status_text.color = "green" if success else "red"
        page.update()

        if success:
            while True:
                j, p = teacher.get_robot_data()
                if j:
                    for i, val in enumerate(j):
                        deg_val = round(val * 57.2958, 2)
                        joint_texts[i].value = f"{joint_labels[i]}: {deg_val:>7.2f}°"
                if p:
                    p_rounded = [round(x, 4) for x in p]
                    pose_display.value = f"Pose (m/rad):\n{p_rounded}"
                try:
                    page.update()
                except:
                    break
                time.sleep(0.15)

    # ── UI 조립 ──────────────────────────────────────
    page.add(
        ft.Column([
            ft.Text("Elite Robot Teaching Tool", size=22, weight=ft.FontWeight.BOLD),
            status_text,

            ft.Row([
                ft.Container(
                    content=joint_display_col,
                    padding=15,
                    bgcolor=ft.Colors.BLACK26,
                    border_radius=10,
                    width=220,
                ),
                ft.Container(
                    content=pose_display,
                    padding=15,
                    bgcolor=ft.Colors.BLACK26,
                    border_radius=10,
                    expand=True,
                ),
            ], alignment="center", vertical_alignment="start"),

            ft.Row([
                memo_input,
                ft.IconButton(
                    ft.Icons.DELETE_SWEEP,
                    on_click=clear_sequence,
                    tooltip="현재 이름의 데이터 초기화",
                ),
            ], alignment="center"),

            ft.Row([
                ft.ElevatedButton(
                    "홈 위치로 이동",
                    icon=ft.Icons.HOME,
                    on_click=go_home,
                    bgcolor=ft.Colors.BLUE_900,
                ),
                ft.ElevatedButton(
                    "초기 위치로 이동",
                    icon=ft.Icons.START,
                    on_click=go_center,
                    bgcolor=ft.Colors.INDIGO_900,
                ),
            ], alignment="center"),

            ft.ElevatedButton(
                "현재 위치 저장 (JSON 누적)",
                icon=ft.Icons.SAVE,
                on_click=save_position,
                width=400,
            ),

            ft.Container(
                content=log_view,
                height=200,
                border=ft.border.all(1, "grey"),
                padding=5,
            ),
        ], horizontal_alignment="center")
    )

    threading.Thread(target=update_loop, daemon=True).start()


if __name__ == "__main__":
    # ✅ ft.app → ft.run (0.80.0 이후 권장)
    # ✅ WEB_BROWSER 모드로 OpenGL 에러 우회
    ft.run(
        main,
        view=ft.AppView.WEB_BROWSER,
        port=8551,   # 메인 패널(8550)과 포트 충돌 방지
    )