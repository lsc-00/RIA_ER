#!/usr/bin/env python3
"""
구역별 스쿱 모션 (가운데 1 + 가장자리 4) 경로를 만들고, 경로 전체에서 스쿱과 솥 경계 사이 여유를 확인한다.

    from ria_kettle.zone_motion import ZoneMotionPlanner
    planner = ZoneMotionPlanner.from_yaml()
    planner.zone_of_xy(x, y)              # 'center', 'edge_45', ... 또는 None (수면 밖)
    m = planner.motion('edge_45')         # ZoneMotion: waypoints, samples, clearance, params
    planner.script_poses(m)               # movel 로 보낼 [x, y, z, rx, ry, rz] 목록 (홈 제외)

구역 (방위 0° = 로봇 base +X 먼 쪽, 90° = +Y 왼쪽)
  center   : 솥 축에서 zones.center_radius_m 이내
  edge_<deg>: 그 바깥 수면. 중심 방위 45° · 135° · 225° · 315°, 폭 90° (경계는 ±X · ±Y 축)

모션 순서 (movel 경유점)
  홈 → 접근 (시작점 위, 스쿱 가장 낮은 점이 수면보다 위. 시작점이 솥 안이라 림까지 올리지 않는다) → 내리기
  (motion.entry_mode vertical: 접근 · 내리기는 입구 방위만 돌린 장착 기울기 자세로 수직 하강 → 물속자세: 표식을 중심으로
   입구 각도를 쓸기 각도로. tilted: 접근부터 쓸기 자세) → 쓸기 (입구가 진행 방향)
  → 세우기 (망 구의 중심을 축으로 입구를 위로 돌림: 망 표면이 제자리에서 굴러 물 · 음식을 덜 밀어냄) → 들어 올리기
  → 들어 올리기는 스쿱 가장 낮은 점이 림 꼭대기보다 위까지 (솥 밖으로 나갈 수 있는 높이)
  시작 · 끝 거리와 호 반경은 여유 기준(min_clearance_m)과 팔 닿는 거리(reach.max_distance_m)를 함께 지키는 가장 큰 값.
  팔 닿는 거리는 어깨 ↔ 손목 점 거리로 빠르게 거른 것이고, 정확한 확인은 src/vendor/dev_log/jb/mesh/zone_motion_check.py 의 역기구학.
  가운데 : 먼 쪽에서 로봇 쪽으로 솥 축을 지나는 직선
  가장자리: 벽을 따라 도는 호. 구역의 먼 쪽 끝에서 로봇 쪽 끝으로 (손목 회전이 홈 기준 ±90° 안).
            호 반경은 여유 기준을 지키는 가장 큰 값

경로 규칙 (솥 모델의 부호 있는 거리로 스쿱 표면 점마다 판정, jb/2026-09-15.md 3.1)
  1. 여유: 모든 샘플 · 모든 점에서 min_clearance_m 이상.
  2. 벽 근처(여유 < near_wall_m) 점은 벽 쪽으로 다가가면 안 된다. 그 점이 벽 근처에 들어온 뒤의 최대 여유보다
     closing_tolerance_m 넘게 줄면 위반. 솥은 아래로 좁아져서 벽 근처에서 내려가거나 바깥으로 가면 여유가 준다
     (수면 높이 1 mm 당: 내려감 −0.49, 바깥 −0.87 mm / 바닥 근처 내려감 −0.92 mm). 위로 · 원호 중심 쪽 · 원호 중심 둘레
     회전은 여유가 그대로이거나 는다. closing_allowed_stages 단계(가장자리 B 의 수평 접근)만 예외.
  3. 벽 근처 점이 있는 경유점 구간은 near_wall_speed_m_s 로 느리게 (ZoneMotion.segment_slow).
  4. 팔 닿는 거리: 어깨 ↔ 손목 점 ≤ reach.max_distance_m.

스쿱 자세 (ψ, γ)
  ψ = 입구가 향하는 수평 방위, γ = 입구 방향이 수평보다 위로 든 각도. 도구 x 축은 늘 수평.
  홈 자세 = (180°, 장착 기울기 21°). 로봇 보고 자세는 RPY.
"""

import math
import sys
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import yaml

sys.dont_write_bytecode = True

try:                                   # ROS 패키지로 설치된 경우
    from .kettle_model import KettleModel, find_config
    from .scoop_body import Clearance, ScoopBody, ScoopMount, rotation_about, rpy_to_matrix
    from .scoop_path import ScoopGeometry
except ImportError:                    # 소스 폴더에서 스크립트로 실행하는 경우
    from kettle_model import KettleModel, find_config
    from scoop_body import Clearance, ScoopBody, ScoopMount, rotation_about, rpy_to_matrix
    from scoop_path import ScoopGeometry

CENTER = 'center'
HOME = '홈'
EDGE_LABELS = {45: '먼 쪽 왼쪽', 135: '로봇 쪽 왼쪽', 225: '로봇 쪽 오른쪽', 315: '먼 쪽 오른쪽'}


def rot_x(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[1.0, 0.0, 0.0], [0.0, c, -s], [0.0, s, c]])


def rot_z(a):
    c, s = math.cos(a), math.sin(a)
    return np.array([[c, -s, 0.0], [s, c, 0.0], [0.0, 0.0, 1.0]])


def matrix_to_rpy(R):
    """회전행렬 → Elite RPY (rx, ry, rz). R = Rz · Ry · Rx."""
    R = np.asarray(R, dtype=float)
    ry = math.asin(max(-1.0, min(1.0, -R[2, 0])))
    return [math.atan2(R[2, 1], R[2, 2]), ry, math.atan2(R[1, 0], R[0, 0])]


def rotation_log(R):
    """회전행렬 → 회전벡터 (축 × 각도)."""
    R = np.asarray(R, dtype=float)
    angle = math.acos(max(-1.0, min(1.0, (np.trace(R) - 1.0) / 2.0)))
    if angle < 1e-9:
        return np.zeros(3)
    if math.pi - angle < 1e-6:
        M = (R + np.eye(3)) / 2.0
        axis = M[:, int(np.argmax(np.diag(M)))]
        return axis / np.linalg.norm(axis) * angle
    v = np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]])
    return v / (2.0 * math.sin(angle)) * angle


def wrap_deg(d):
    return (d + 180.0) % 360.0 - 180.0


@dataclass
class Waypoint:
    stage: str
    position: np.ndarray
    R: np.ndarray


@dataclass
class ZoneMotion:
    zone: str
    label: str
    waypoints: list
    samples: list                      # [(stage, position, R)] movel 보간
    clearance: object                  # scoop_body.Clearance (가장 가까운 곳)
    clearance_stage: str
    min_clearance_m: float
    params: dict = field(default_factory=dict)
    reach_m: float = 0.0               # 경로 중 어깨 ↔ 손목 점 최대 거리
    max_reach_m: float = math.inf
    closing: list = field(default_factory=list)       # 벽 근처에서 벽 쪽으로 다가간 곳 [(샘플 번호, 단계, 부분, 여유, 줄어든 양)]
    segment_slow: list = field(default_factory=list)  # 경유점 구간마다 벽 근처라 느리게 갈지

    @property
    def ok(self):
        return (self.clearance.clearance_m >= self.min_clearance_m and self.reach_m <= self.max_reach_m
                and not self.closing)


@dataclass
class PathCheck:
    """경유점 경로 한 개의 확인 결과."""
    samples: list
    clearance: Clearance
    clearance_stage: str
    reach_m: float
    closing: list
    segment_slow: list
    stage_min: dict = field(default_factory=dict)    # 단계별 최소 여유 [m]
    segments: list = field(default_factory=list)     # 샘플마다 경유점 구간 번호 (첫 샘플 −1)
    blend: list = field(default_factory=list)        # 샘플마다 블렌드 곡선 위인지


class ZoneMotionPlanner:
    def __init__(self, kettle: KettleModel, scoop: ScoopGeometry, mount: ScoopMount, config: dict):
        self.kettle, self.scoop, self.mount, self.cfg = kettle, scoop, mount, config
        axis = kettle.placement.get('axis_xy_in_base_m')
        if axis is None:
            raise RuntimeError('kettle_profile.yaml 의 placement.axis_xy_in_base_m (솥 중심) 이 없습니다.')
        self.axis_xy = np.asarray(axis, dtype=float)
        bottom = float(kettle.placement['bottom_z_in_base_m'])
        # 수면은 솥 모델이 들고 있다 (KettleModel.from_yaml 이 water_level.yaml 을 반영). 계획기는 따라가기만 한다.
        self.surface_source = kettle.water_source
        self.surface_z = bottom + kettle.level_h
        self.rim_top_z = bottom + float(kettle.rim_top[1])
        d = np.asarray(mount.opening_axis_in_tool, dtype=float)
        if abs(d[0]) > 1e-6:
            raise ValueError('zone_motion 은 입구 방향이 도구 y-z 평면 안에 있다고 가정합니다 (opening_axis_in_tool x = 0).')
        self.mount_gamma = math.atan2(-d[2], d[1])
        self.opening_tool = d
        rules, precision, speed = config['rules'], config['precision'], config['speed']
        self.body = ScoopBody(scoop, mount, step_m=float(precision['body_step_m']))
        self.coarse_body = ScoopBody(scoop, mount, step_m=float(precision['coarse_body_step_m']))
        home = config['home_tcp']
        self.home = Waypoint(HOME, np.asarray(home['position_m'], dtype=float), rpy_to_matrix(home['rpy_rad']))
        self.min_clearance = float(rules['min_clearance_m'])
        self.stage_min_clearance = {str(k): float(v) for k, v in (rules['stage_min_clearance_m'] or {}).items()}
        self.near_wall = float(rules['near_wall_m'])
        self.closing_tol = float(rules['closing_tolerance_m'])
        self.closing_allowed = set(rules['closing_allowed_stages'] or [])
        self.speed_m_s, self.near_wall_speed_m_s = float(speed['normal_m_s']), float(speed['near_wall_m_s'])
        self.accel_m_s2 = float(speed['accel_m_s2'])
        reach = config['reach']
        self.shoulder = np.asarray(reach['shoulder_m'], dtype=float)
        self.wrist_point_tool = np.asarray(reach['wrist_point_in_tool_m'], dtype=float)
        self.max_reach = float(reach['max_distance_m'])

    @classmethod
    def from_yaml(cls, profile=None, scoop=None, zones=None, water_surface_z='current'):
        """water_surface_z: 'current' = water_level.yaml 의 지금 수면, None = 설계 수위 100 L, 숫자 = 그 z (이번 실행 · 시험용)."""
        config = yaml.safe_load(Path(find_config('zone_motion.yaml') if zones is None else zones).read_text(encoding='utf-8'))
        return cls(KettleModel.from_yaml(profile, water_surface_z=water_surface_z), ScoopGeometry.from_yaml(scoop),
                   ScoopMount.from_yaml(scoop), config)

    # -- 구역 -----------------------------------------------------------------

    @property
    def zone_names(self):
        return [CENTER] + [f'edge_{int(c)}' for c in self.cfg['zones']['edge_centers_deg']]

    def zone_label(self, zone):
        if zone == CENTER:
            return '가운데'
        c = int(zone.split('_')[1])
        return f'가장자리 {EDGE_LABELS.get(c, f"{c}°")}'

    def zone_of_xy(self, x, y):
        z = self.cfg['zones']
        dx, dy = float(x) - self.axis_xy[0], float(y) - self.axis_xy[1]
        r = math.hypot(dx, dy)
        if r > self.kettle.surface_radius - float(z['surface_margin_m']):
            return None
        if r <= float(z['center_radius_m']):
            return CENTER
        phi = math.degrees(math.atan2(dy, dx))
        best = min(z['edge_centers_deg'], key=lambda c: abs(wrap_deg(phi - c)))
        return f'edge_{int(best)}'

    # -- 자세 -----------------------------------------------------------------

    def scoop_rotation(self, psi_deg, gamma_deg):
        """입구 수평 방위 ψ, 들어 올린 각 γ 인 도구 회전행렬."""
        return rot_z(math.radians(psi_deg) - math.pi) @ rpy_to_matrix([math.pi, 0.0, -math.pi / 2]) \
            @ rot_x(self.mount_gamma - math.radians(gamma_deg))

    def _low(self, R, body=None):
        """회전 R 일 때 표식 기준 스쿱 가장 낮은 점의 높이 (음수)."""
        body = self.body if body is None else body
        return float(np.min((body.points_tool @ R.T)[:, 2] - body.inflate))

    def safe_z(self, R, body=None):
        """스쿱 가장 낮은 점이 림 꼭대기 + lift_clearance_m 에 오는 표식 높이 (솥 밖으로 나갈 수 있는 높이)."""
        return self.rim_top_z + float(self.cfg['motion']['lift_clearance_m']) - self._low(R, body)

    def approach_z(self, R, body=None):
        """스쿱 가장 낮은 점이 수면 + approach_above_surface_m 에 오는 표식 높이 (솥 안에서 내리기 전)."""
        return self.surface_z + float(self.cfg['motion']['approach_above_surface_m']) - self._low(R, body)

    def reach_of(self, position, R):
        """어깨(J2 축 높이) ↔ 손목 점(J4 축) 거리. 팔이 닿는지 빠르게 거르는 값."""
        return float(np.linalg.norm(np.asarray(position) + R @ self.wrist_point_tool - self.shoulder))

    def _xy(self, r, phi_deg):
        a = math.radians(phi_deg)
        return self.axis_xy + r * np.array([math.cos(a), math.sin(a)])

    # -- 경유점 ----------------------------------------------------------------

    def opening_gamma_deg(self, R):
        """회전 R 일 때 입구 방향이 수평보다 위로 든 각도 [deg] (홈 자세 = 장착 기울기 21°)."""
        d = np.asarray(R, dtype=float) @ self.opening_tool
        return math.degrees(math.atan2(d[2], math.hypot(d[0], d[1])))

    def entry_rotation(self, xy, psi_deg, z_low, R_work):
        """vertical 진입의 하강 자세. 입구 각을 장착 기울기부터 motion.entry_gamma_step_deg 씩 올려, (xy, z_low) 에서 스쿱이
        벽 근처(rules.near_wall_m + closing_tolerance_m) 밖이고 R_work 까지 물속 회전하는 동안 최소 여유를 지키는 가장 작은 각.
        (가능한 만큼 수직, 사용자 결정 2026-09-15). 없으면 R_work. 항상 거친 몸체로 판단해 후보 탐색과 최종 계획이 같은 각을 쓴다."""
        m, body = self.cfg['motion'], self.coarse_body
        p_low = np.r_[xy, z_low]
        g_work = self.opening_gamma_deg(R_work)
        step, tilt_step = float(m['entry_gamma_step_deg']), float(m['tilt_step_deg'])
        need_low, need_turn = self.near_wall + self.closing_tol, self.min_clearance_for('물속자세')
        g = math.degrees(self.mount_gamma)
        while g < g_work - 1e-6:
            R_in = self.scoop_rotation(psi_deg, g)
            if body.clearance(self.kettle, p_low, R_in).clearance_m >= need_low:
                w = rotation_log(R_in.T @ R_work)
                angle = float(np.linalg.norm(w))
                n = max(int(math.ceil(math.degrees(angle) / tilt_step)), 1)
                if all(body.clearance(self.kettle, p_low, R_in @ rotation_about(w, t * angle)).clearance_m >= need_turn
                       for t in np.linspace(0.0, 1.0, n + 1)[1:]):
                    return R_in
            g += step
        return R_work

    def entry_waypoints(self, xy, psi_deg, z_low, R_work, body=None, mode=None):
        """홈 → 접근 → 내리기 (→ 물속자세). 끝 자세가 R_work, 끝 위치가 (xy, z_low). mode (기본 motion.entry_mode):
        vertical = entry_rotation 자세로 수직 하강한 뒤 표식을 중심으로 R_work 까지 돌림, tilted = 처음부터 R_work."""
        m = self.cfg['motion']
        mode = str(m['entry_mode'] if mode is None else mode)
        if mode not in ('vertical', 'tilted'):
            raise ValueError(f"entry_mode 는 vertical 또는 tilted: {mode}")
        R_in = R_work if mode == 'tilted' else self.entry_rotation(xy, psi_deg, z_low, R_work)
        p_low = np.r_[xy, z_low]
        wps = [self.home,
               Waypoint('접근', np.r_[xy, max(self.approach_z(R_in, body), z_low)], R_in),
               Waypoint('내리기', p_low, R_in)]
        w = rotation_log(R_in.T @ R_work)
        angle = float(np.linalg.norm(w))
        if angle > 1e-9:
            n = max(int(math.ceil(math.degrees(angle) / float(m['tilt_step_deg']))), 1)
            for t in np.linspace(0.0, 1.0, n + 1)[1:]:
                wps.append(Waypoint('물속자세', p_low, R_in @ rotation_about(w, t * angle)))
        return wps

    def _enter_sweep_exit(self, sweep, psi_end, body):
        """sweep: [(xy, ψ)] → 접근 · 내리기 · 쓸기 · 세우기 · 들어 올리기 경유점."""
        m = self.cfg['motion']
        g_s, g_l = float(m['sweep_gamma_deg']), float(m['lift_gamma_deg'])
        z_sweep = self.surface_z - float(m['marker_depth_m'])
        (xy0, psi0) = sweep[0]
        R0 = self.scoop_rotation(psi0, g_s)
        wps = self.entry_waypoints(xy0, psi0, z_sweep, R0, body)
        for xy, psi in sweep[1:]:
            wps.append(Waypoint('쓸기', np.r_[xy, z_sweep], self.scoop_rotation(psi, g_s)))
        # 세우기: 망 구 중심을 고정하고 γ 를 키운다
        end = wps[-1]
        lever = self.scoop.sphere_radius_m * self.opening_tool
        pivot = end.position + end.R @ lever
        n = max(int(math.ceil(abs(g_l - g_s) / float(m['tilt_step_deg']))), 1)
        keep_depth = bool(m['tilt_keep_depth'])
        R = end.R
        for g in np.linspace(g_s, g_l, n + 1)[1:]:
            R = self.scoop_rotation(psi_end, g)
            p = pivot - R @ lever
            if keep_depth and p[2] < z_sweep:           # 망 바닥이 쓸기 깊이보다 내려가지 않게 같이 올린다
                p = p + np.array([0.0, 0.0, z_sweep - p[2]])
            wps.append(Waypoint('세우기', p, R))
        top = wps[-1].position
        wps.append(Waypoint('들어올리기', np.r_[top[:2], max(self.safe_z(R, body), top[2])], R))
        return wps

    def center_waypoints(self, start_m, end_m, body=None):
        psi = float(self.cfg['center']['heading_deg'])
        return self._enter_sweep_exit([(self._xy(start_m, psi + 180.0), psi), (self._xy(end_m, psi), psi)], psi, body)

    def edge_waypoints(self, zone, radius_m, body=None):
        c = float(zone.split('_')[1])
        s = 1.0 if 0.0 < c % 360.0 < 180.0 else -1.0          # 로봇 쪽(180°)으로 도는 방향
        step = float(self.cfg['motion']['sweep_step_deg'])
        phis = np.linspace(c - 45.0 * s, c + 45.0 * s, max(int(math.ceil(90.0 / step)), 1) + 1)
        sweep = [(self._xy(radius_m, p), p + 90.0 * s) for p in phis]
        return self._enter_sweep_exit(sweep, sweep[-1][1], body)

    # -- 샘플 · 여유 ------------------------------------------------------------

    def sample(self, waypoints, radii=None):
        """movel 로 경유점을 차례로 지날 때의 TCP 자세. 위치는 직선, 회전은 최단 회전으로 고르게.
        radii 가 있으면 경유점 i 에서 반경 radii[i] 로 블렌드한 경로 (sample_segments 참고)."""
        return self.sample_segments(waypoints, radii)[0]

    def sample_segments(self, waypoints, radii=None, with_blend=False):
        """sample() 과 같고, 샘플마다 속한 경유점 구간 번호(첫 샘플은 −1)도 돌려준다.
        with_blend 이면 샘플마다 블렌드 곡선 위인지(True)도 세 번째로 돌려준다.

        블렌드 (movel r): 경유점 W 앞뒤로 r 떨어진 두 점을 W 를 조절점으로 하는 2차 베지어 곡선으로 잇고,
        자세는 두 점의 자세 사이를 고르게 돌린다. 곡선은 두 선분에서 r 이상 벗어나지 않고, 90° 모서리에서는 W 에서 약 0.35 r 안쪽을 지난다.
        컨트롤러 블렌드의 근사다 — 실제 편차는 실행 기록(run_target_motion 의 RTSI 기록)으로 확인한다.
        첫 · 마지막 경유점의 반경은 항상 0 (정확히 서고 끝난다).
        """
        precision = self.cfg['precision']
        step_m, step_a = float(precision['sample_step_m']), math.radians(float(precision['sample_step_deg']))
        n = len(waypoints)
        r = [0.0] * n if radii is None else [float(v) for v in radii]
        r[0] = r[-1] = 0.0
        P = [np.asarray(w.position, dtype=float) for w in waypoints]
        L = [float(np.linalg.norm(P[k + 1] - P[k])) for k in range(n - 1)]
        W = [rotation_log(waypoints[k].R.T @ waypoints[k + 1].R) for k in range(n - 1)]

        def on_segment(k, s):
            t = min(max(s / L[k], 0.0), 1.0) if L[k] > 1e-9 else 1.0
            angle = float(np.linalg.norm(W[k]))
            R = waypoints[k].R @ rotation_about(W[k], t * angle) if angle > 1e-12 else waypoints[k].R
            return P[k] + t * (P[k + 1] - P[k]), R

        out, segments, blend = [(waypoints[0].stage, P[0], waypoints[0].R)], [-1], [False]
        for k in range(n - 1):
            stage = waypoints[k + 1].stage
            s0, s1 = min(r[k], L[k]), max(L[k] - r[k + 1], min(r[k], L[k]))
            angle = float(np.linalg.norm(W[k]))
            frac = (s1 - s0) / L[k] if L[k] > 1e-9 else 1.0
            count = max(int(math.ceil((s1 - s0) / step_m)), int(math.ceil(angle * frac / step_a)), 1)
            for i in range(1, count + 1):
                if L[k] > 1e-9:
                    p, R = on_segment(k, s0 + (s1 - s0) * i / count)
                else:                                       # 제자리 회전 구간
                    t = i / count
                    p, R = P[k], (waypoints[k].R @ rotation_about(W[k], t * angle) if angle > 1e-12 else waypoints[k].R)
                out.append((stage, p, R))
                segments.append(k)
                blend.append(False)
            if k + 1 < n - 1 and r[k + 1] > 0.0:            # 경유점 k+1 에서 블렌드
                p_in, R_in = on_segment(k, L[k] - r[k + 1])
                p_out, R_out = on_segment(k + 1, r[k + 1])
                wb = rotation_log(R_in.T @ R_out)
                ab = float(np.linalg.norm(wb))
                count = max(int(math.ceil(4.0 * r[k + 1] / step_m)), int(math.ceil(ab / step_a)), 4)
                for i in range(1, count + 1):
                    t = i / count
                    p = (1 - t) ** 2 * p_in + 2 * (1 - t) * t * P[k + 1] + t ** 2 * p_out
                    R = R_in @ rotation_about(wb, t * ab) if ab > 1e-12 else R_in
                    out.append((stage if t < 0.5 else waypoints[k + 2].stage, p, R))
                    segments.append(k if t < 0.5 else k + 1)
                    blend.append(True)
        return (out, segments, blend) if with_blend else (out, segments)

    def check_path(self, waypoints, body=None, radii=None):
        """경로 규칙 1~4 를 확인한다 (모듈 설명 참고). radii 가 있으면 블렌드한 경로로."""
        body = self.body if body is None else body
        samples, segments, blend = self.sample_segments(waypoints, radii, with_blend=True)
        worst, worst_stage, running = None, None, None
        closing, stage_min = [], {}
        slow = [False] * max(len(waypoints) - 1, 0)
        for i, ((stage, p, R), seg) in enumerate(zip(samples, segments)):
            d, pts = body.clearances(self.kettle, p, R)
            k = int(np.argmin(d))
            stage_min[stage] = min(stage_min.get(stage, math.inf), float(d[k]))
            if worst is None or d[k] < worst.clearance_m:
                worst, worst_stage = Clearance(float(d[k]), str(body.parts[k]), pts[k]), stage
            near = d < self.near_wall
            if seg >= 0 and near.any():
                slow[seg] = True
            if running is None or stage in self.closing_allowed:
                running = np.where(near, d, np.nan)          # 기준을 지금으로 다시 잡는다
                continue
            # 벽 근처에 있는 동안의 최대 여유. 벽 근처를 벗어나면 잊는다.
            # 블렌드 곡선은 모서리를 안쪽으로 깎아 여유가 잠깐 부푸는데, 그 값을 기준으로 삼으면 원래 여유로 돌아오는 것까지
            # '다가감' 으로 센다 → 블렌드 샘플은 기준을 올리지 않는다 (다가가는지는 그대로 검사).
            grown = running if blend[i] else np.maximum(running, d)
            running = np.where(near, np.where(np.isnan(running), d, grown), np.nan)
            drop = running - d
            if np.any(drop > self.closing_tol):
                j = int(np.nanargmax(drop))
                closing.append((i, stage, str(body.parts[j]), float(d[j]), float(drop[j])))
        reach = max(self.reach_of(p, R) for _, p, R in samples)
        return PathCheck(samples, worst, worst_stage, reach, closing, slow, stage_min, segments, blend)

    def min_clearance_for(self, stage):
        """단계별 최소 여유 (rules.stage_min_clearance_m 에 없으면 rules.min_clearance_m)."""
        return self.stage_min_clearance.get(stage, self.min_clearance)

    def clearance_violation(self, check):
        """여유 기준을 못 지킨 첫 단계 (단계, 최소 여유, 기준) 또는 None."""
        for stage, value in check.stage_min.items():
            if value < self.min_clearance_for(stage):
                return stage, value, self.min_clearance_for(stage)
        return None

    def feasible(self, check):
        return (self.clearance_violation(check) is None and check.reach_m <= self.max_reach
                and not check.closing)

    # -- 스무딩 (블렌드) ------------------------------------------------------------

    def stage_uniform(self, waypoints, flags):
        """구간 표시(느린 구간)를 단계 단위로: 한 단계에 하나라도 있으면 그 단계 전체. 구간 k 의 단계 = waypoints[k+1].stage."""
        stages = [w.stage for w in waypoints[1:]]
        marked = {s for s, f in zip(stages, flags) if f}
        return [s in marked for s in stages]

    def blend_radii(self, waypoints, slow):
        """경유점마다 블렌드 반경 (smoothing 절). 첫 · 마지막은 0. 앞뒤 구간 중 짧은 것 × max_segment_fraction 을 넘지 않고
        (블렌드끼리 겹치지 않게), 벽 근처(느린) 구간에 붙은 경유점은 near_wall_blend_radius_m, 나머지는 blend_radius_m 까지.
        min_radius_m 미만은 0."""
        s = self.cfg['smoothing']
        far, near = float(s['blend_radius_m']), float(s['near_wall_blend_radius_m'])
        fraction, min_radius = float(s['max_segment_fraction']), float(s['min_radius_m'])
        n = len(waypoints)
        radii = [0.0] * n
        for i in range(1, n - 1):
            limit = fraction * min(float(np.linalg.norm(waypoints[i].position - waypoints[i - 1].position)),
                                   float(np.linalg.norm(waypoints[i + 1].position - waypoints[i].position)))
            value = min(near if (slow[i - 1] or slow[i]) else far, limit)
            radii[i] = float(value) if value >= min_radius else 0.0
        return radii

    def smooth(self, waypoints, body=None):
        """블렌드 반경을 정하고, 블렌드한 경로로 경로 규칙을 다시 확인한다.
        벽 쪽 다가감에 걸리면 걸린 구간 양 끝 경유점의 반경만, 여유 · 팔 닿는 거리에 걸리면 전체를 smoothing.shrink_factor 배로 줄인다.
        max_rounds 안에 안 되면 반경 0 (블렌드 없음). 반환: (반경 목록, 블렌드한 경로의 PathCheck, 단계 단위 느린 구간 표시)."""
        s = self.cfg['smoothing']
        factor, min_radius, max_rounds = float(s['shrink_factor']), float(s['min_radius_m']), int(s['max_rounds'])

        def shrink(v):
            return v * factor if v * factor >= min_radius else 0.0

        base = self.check_path(waypoints, body)
        slow = self.stage_uniform(waypoints, base.segment_slow)
        radii = self.blend_radii(waypoints, slow)
        for _ in range(max_rounds):
            check = self.check_path(waypoints, body, radii)
            wider = self.stage_uniform(waypoints, [a or b for a, b in zip(slow, check.segment_slow)])
            if wider != slow:                  # 블렌드로 벽 근처 구간이 늘었으면 그 기준으로 반경을 다시 정한다
                slow = wider
                radii = [min(a, b) for a, b in zip(radii, self.blend_radii(waypoints, slow))]
                continue
            if self.feasible(check) or not any(radii):
                return radii, check, slow
            if check.closing:
                for i, *_ in check.closing[:3]:
                    k = check.segments[i]
                    for j in (k, k + 1):
                        if 0 < j < len(radii) - 1:
                            radii[j] = shrink(radii[j])
            else:
                radii = [shrink(v) for v in radii]
        radii = [0.0] * len(waypoints)
        return radii, self.check_path(waypoints, body, radii), slow

    def _largest_feasible(self, build, lo, hi, tol=None):
        """build(v) → 경유점. 경로 규칙을 모두 지키는 가장 큰 v (lo 도 안 되면 lo). tol 기본 = precision.search_tol_m."""
        tol = float(self.cfg['precision']['search_tol_m']) if tol is None else tol
        def ok(v, body):
            return self.feasible(self.check_path(build(v, body), body))
        coarse = self.coarse_body
        if ok(hi, coarse):
            v = hi
        elif not ok(lo, coarse):
            return lo
        else:
            while hi - lo > tol:
                mid = 0.5 * (lo + hi)
                lo, hi = (mid, hi) if ok(mid, coarse) else (lo, mid)
            v = lo
        while v > lo and not ok(v, self.body):          # 촘촘한 몸체로 다시 확인
            v = max(lo, v - tol)
        return v

    # -- 모션 -----------------------------------------------------------------

    def motion(self, zone):
        c = self.cfg
        if zone == CENTER:
            cc = c['center']
            start_max, end_max = float(cc['start_max_m']), float(cc['end_max_m'])
            start = self._largest_feasible(lambda v, b: self.center_waypoints(v, 0.0, b), 0.0, start_max)
            end = self._largest_feasible(lambda v, b: self.center_waypoints(start, v, b), 0.0, end_max)
            start = self._largest_feasible(lambda v, b: self.center_waypoints(v, end, b), 0.0, start_max)
            waypoints = self.center_waypoints(start, end)
            params = {'start_m': start, 'end_m': end, 'sweep_length_m': start + end}
        elif zone in self.zone_names:
            e = c['edge']
            radius = self._largest_feasible(lambda v, b: self.edge_waypoints(zone, v, b),
                                            float(e['arc_radius_min_m']), float(e['arc_radius_max_m']))
            waypoints = self.edge_waypoints(zone, radius)
            params = {'arc_radius_m': radius}
        else:
            raise ValueError(f'알 수 없는 구역: {zone}')
        check = self.check_path(waypoints)
        m = c['motion']
        params.update(sweep_gamma_deg=float(m['sweep_gamma_deg']), lift_gamma_deg=float(m['lift_gamma_deg']),
                      marker_depth_m=float(m['marker_depth_m']))
        return ZoneMotion(zone, self.zone_label(zone), waypoints, check.samples, check.clearance, check.clearance_stage,
                          self.min_clearance, params, reach_m=check.reach_m, max_reach_m=self.max_reach,
                          closing=check.closing, segment_slow=check.segment_slow)

    def motions(self):
        return {zone: self.motion(zone) for zone in self.zone_names}

    def script_poses(self, motion):
        """로봇에 보낼 movel 목표 [x, y, z, rx, ry, rz] (홈 경유점 제외)."""
        return [[*map(float, w.position), *matrix_to_rpy(w.R)] for w in motion.waypoints if w.stage != HOME]

    def mouth_waterline_xy(self, samples, stages=('쓸기',), band_m=0.006, step_m=0.01):
        """쓸기 동안 망 입구 면이 수면을 지나는 점들 (x, y). 음식이 입구로 들어올 수 있는 자리의 근사."""
        d = self.opening_tool                            # 도구 y-z 평면 안 → 도구 x 축은 입구 면 위에 있다
        u = np.array([1.0, 0.0, 0.0])
        w = np.cross(d, u)
        a = self.scoop.rim_radius_m
        g = np.arange(-a, a + 1e-9, step_m)
        gu, gw = np.meshgrid(g, g)
        inside = gu ** 2 + gw ** 2 <= a * a
        disk = self.scoop.depth_m * d + gu[inside][:, None] * u + gw[inside][:, None] * w
        pts = []
        for stage, p, R in samples:
            if stage in stages:
                q = p + disk @ R.T
                pts.append(q[np.abs(q[:, 2] - self.surface_z) <= band_m, :2])
        return np.vstack(pts) if pts else np.zeros((0, 2))


def main():
    planner = ZoneMotionPlanner.from_yaml()
    print(f'솥 축 {np.round(planner.axis_xy, 4).tolist()}, 수면 z {planner.surface_z:+.4f}, 림 꼭대기 z {planner.rim_top_z:+.4f}')
    for zone, m in planner.motions().items():
        c = m.clearance
        print(f'{m.label:16s} {"OK" if m.ok else "실패"}  경로 최소 여유 {c.clearance_m * 1000:+.0f} mm '
              f'({m.clearance_stage} · {c.part}), 팔 뻗음 {m.reach_m:.3f} m  ' + ', '.join(f'{k} {v:.3f}' for k, v in m.params.items())
              + f'  경유점 {len(m.waypoints)}, 벽 근처 느린 구간 {sum(m.segment_slow)}, 벽 쪽 다가감 {len(m.closing)}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
