import math

import numpy as np
import pytest

from ria_kettle import rpy_to_matrix
from ria_kettle.zone_motion import CENTER, Waypoint, ZoneMotionPlanner, matrix_to_rpy, wrap_deg


@pytest.fixture(scope='module')
def planner():
    return ZoneMotionPlanner.from_yaml(water_surface_z=None)   # 알고리즘 시험은 설계 수위 100 L 기준 (실측 수면은 설정마다 달라짐)


@pytest.fixture(scope='module')
def motions(planner):
    return planner.motions()


def test_home_rotation_matches_robot_home(planner):
    R = planner.scoop_rotation(180.0, math.degrees(planner.mount_gamma))
    assert np.allclose(R, rpy_to_matrix([math.pi, 0.0, -math.pi / 2]), atol=1e-9)


def test_scoop_rotation_points_opening_and_keeps_tool_x_level(planner):
    for psi, gamma in [(0.0, 50.0), (90.0, 30.0), (225.0, 75.0)]:
        R = planner.scoop_rotation(psi, gamma)
        p, g = math.radians(psi), math.radians(gamma)
        assert np.allclose(R @ planner.opening_tool, [math.cos(g) * math.cos(p), math.cos(g) * math.sin(p), math.sin(g)])
        assert abs((R @ [1.0, 0.0, 0.0])[2]) < 1e-9


def test_matrix_to_rpy_roundtrip():
    R = rpy_to_matrix([3.0, -0.4, 1.2])
    assert np.allclose(rpy_to_matrix(matrix_to_rpy(R)), R)


def test_zone_of_xy(planner):
    ax, ay = planner.axis_xy

    def at(r, deg):
        a = math.radians(deg)
        return planner.zone_of_xy(ax + r * math.cos(a), ay + r * math.sin(a))

    assert at(0.0, 0.0) == CENTER
    assert at(0.29, 100.0) == CENTER
    assert at(0.40, 45.0) == 'edge_45'
    assert at(0.40, 100.0) == 'edge_135'
    assert at(0.40, 200.0) == 'edge_225'
    assert at(0.40, -30.0) == 'edge_315'
    assert at(0.49, 45.0) is None


def test_all_zone_motions_keep_clearance_and_reach(motions):
    for zone, m in motions.items():
        assert m.clearance.clearance_m >= m.min_clearance_m, (zone, m.clearance.clearance_m, m.clearance_stage)
        assert m.reach_m <= m.max_reach_m, (zone, m.reach_m)
        assert not m.closing, (zone, m.closing[:3])


def test_approach_stays_above_the_surface_and_lift_clears_the_rim(planner, motions):
    for zone, m in motions.items():
        approach = next(w for w in m.waypoints if w.stage == '접근')
        assert approach.position[2] == pytest.approx(planner.approach_z(approach.R))
        assert planner.approach_z(approach.R) < planner.safe_z(approach.R)


def test_wrist_stays_within_90_deg_of_home_heading(planner, motions):
    for zone, m in motions.items():
        for w in m.waypoints:
            d = w.R @ planner.opening_tool
            assert abs(wrap_deg(math.degrees(math.atan2(d[1], d[0])) - 180.0)) <= 90.0 + 1e-6, zone


def test_every_sweep_moves_toward_the_robot(motions):
    for zone, m in motions.items():
        start = next(w for w in m.waypoints if w.stage == '내리기').position
        end = [w for w in m.waypoints if w.stage == '쓸기'][-1].position
        assert end[0] < start[0], zone


def test_motion_ends_lifted_above_the_rim(planner, motions):
    for zone, m in motions.items():
        last = m.waypoints[-1]
        assert last.stage == '들어올리기'
        assert last.position[2] >= planner.safe_z(last.R) - 1e-9, zone


def test_script_poses_skip_home(planner, motions):
    m = motions[CENTER]
    poses = planner.script_poses(m)
    assert len(poses) == len(m.waypoints) - 1
    assert all(len(p) == 6 and all(math.isfinite(v) for v in p) for p in poses)


WALL_FAR = [1.264766, -0.003498, -0.109784, 3.090239, 0.015202, -1.561197]   # 벽 짚기 B 먼 쪽 (망 뒷면이 벽에 닿은 TCP)


def _near_wall_pose():
    return np.array(WALL_FAR[:3]) - [0.045, 0.0, 0.0], rpy_to_matrix(WALL_FAR[3:])   # 벽에서 조금 떨어진 자리


def test_closing_rule_flags_descending_near_the_wall(planner):
    p, R = _near_wall_pose()
    start = planner.body.clearance(planner.kettle, p, R).clearance_m
    assert 0.0 < start < planner.near_wall
    assert planner.check_path([Waypoint('시작', p, R), Waypoint('내리기', p - [0.0, 0.0, 0.06], R)]).closing
    assert not planner.check_path([Waypoint('시작', p, R), Waypoint('들어올리기', p + [0.0, 0.0, 0.06], R)]).closing
    assert not planner.check_path([Waypoint('시작', p, R), Waypoint('당기기', p - [0.06, 0.0, 0.0], R)]).closing


def test_closing_rule_allows_the_wall_approach_stage_and_marks_it_slow(planner):
    p, R = _near_wall_pose()
    approach = planner.check_path([Waypoint('시작', p, R), Waypoint('벽접근', p + [0.02, 0.0, 0.0], R)])
    assert not approach.closing
    assert approach.segment_slow == [True]
    pushing = planner.check_path([Waypoint('시작', p, R), Waypoint('쓸기', p + [0.02, 0.0, 0.0], R)])
    assert pushing.closing


def test_blended_sampling_rounds_the_corner_within_the_radius(planner):
    R = rpy_to_matrix([math.pi, 0.0, -math.pi / 2])
    ax, ay = planner.axis_xy
    z = planner.rim_top_z + 0.4
    a, b, c = np.array([ax - 0.2, ay, z]), np.array([ax, ay, z]), np.array([ax, ay + 0.2, z])
    wps = [Waypoint('시작', a, R), Waypoint('쓸기', b, R), Waypoint('쓸기', c, R)]
    r = 0.03
    pts = np.array([p for _, p, _ in planner.sample(wps, [0.0, r, 0.0])])
    assert np.allclose(pts[0], a) and np.allclose(pts[-1], c)
    corner = np.linalg.norm(pts - b, axis=1).min()
    assert 0.3 * r < corner < 0.4 * r                  # 90° 모서리: 2차 베지어 가운데가 모서리에서 약 0.35 r
    assert max(min(abs(p[1] - ay), abs(p[0] - ax)) for p in pts) <= r + 1e-9   # 두 선분에서 r 넘게 벗어나지 않음
    assert any(np.allclose(p, b) for _, p, _ in planner.sample(wps))          # 블렌드 없으면 모서리를 지난다


def test_vertical_entry_descends_with_least_tilt_then_turns_in_water(planner, motions):
    m = motions['center']
    approach = next(w for w in m.waypoints if w.stage == '접근')
    down = next(w for w in m.waypoints if w.stage == '내리기')
    turn = [w for w in m.waypoints if w.stage == '물속자세']
    sweep = next(w for w in m.waypoints if w.stage == '쓸기')
    assert np.allclose(approach.position[:2], down.position[:2]) and np.allclose(approach.R, down.R)   # 수직 하강
    g_in, g_sweep = planner.opening_gamma_deg(down.R), planner.opening_gamma_deg(sweep.R)
    assert math.degrees(planner.mount_gamma) - 1e-6 <= g_in < g_sweep
    assert turn and all(np.allclose(w.position, down.position) for w in turn)                          # 표식 제자리에서 세움
    assert planner.opening_gamma_deg(turn[-1].R) == pytest.approx(g_sweep)
    assert m.clearance.clearance_m >= m.min_clearance_m


def test_entry_tilt_grows_when_water_is_shallow(planner):
    bottom = planner.kettle.placement['bottom_z_in_base_m']
    shallow = ZoneMotionPlanner.from_yaml(water_surface_z=bottom + float(planner.kettle.level_for_volume(52.0)))
    angles = []
    for p in (planner, shallow):
        R_work = p.scoop_rotation(180.0, float(p.cfg['motion']['sweep_gamma_deg']))
        R_in = p.entry_rotation(p.axis_xy, 180.0, p.surface_z - float(p.cfg['motion']['marker_depth_m']), R_work)
        angles.append(p.opening_gamma_deg(R_in))
    assert angles[0] < angles[1]
    stages = [w.stage for w in planner.entry_waypoints(planner.axis_xy, 180.0, planner.surface_z - 0.025,
                                                       planner.scoop_rotation(180.0, 50.0), mode='tilted')]
    assert stages == ['홈', '접근', '내리기']


def test_smooth_blends_intermediate_points_and_keeps_rules(planner, motions):
    m = motions['edge_45']
    radii, check, slow = planner.smooth(m.waypoints)
    assert radii[0] == 0.0 and radii[-1] == 0.0
    assert any(v > 0.0 for v in radii)
    far = float(planner.cfg['smoothing']['blend_radius_m'])
    near = float(planner.cfg['smoothing']['near_wall_blend_radius_m'])
    for i in range(1, len(radii) - 1):
        assert radii[i] <= (near if (slow[i - 1] or slow[i]) else far) + 1e-12
    assert planner.feasible(check)
