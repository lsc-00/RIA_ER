import math
import struct
import time
import elite_cs_sdk as cs

# ==============================================================================
# 고정 상수 (파라미터 아닌 것들)
# ==============================================================================
ROBOT_IP = "192.168.0.100"

HOME_POS_DEG        = [0.0, -90.0, -90.0, -90.0, 90.0, 0.0]
CENTER_XYZ          = [0.80, -0.0, 0.3]
START_XYZ           = [0.50, -0.0, 0.3]
CENTER_JOINT_DEG    = [25.1, -83.00, -139.31, -47.68, 90.01, -69.29]

CIRCLE_VEL = 3.0;  CIRCLE_ACC = 2.5
SCOOP_VEL  = 0.8;  SCOOP_ACC  = 1.0;  SCOOP_BLEND     = 0.05
SHAKE_VEL  = 13.0; SHAKE_ACC  = 15.0; SHAKE_BLEND     = 0.01
DISCHARGE_VEL = 1.0; DISCHARGE_ACC = 0.8; DISCHARGE_BLEND = 0.05

SCOOP_W1_DEG        = [20.71, -83.00, -139.31, -47.68,  90.01,  -69.29]
SCOOP_W2_DEG        = [33.35, -101.85, -154.86, -12.85,  46.13,  -96.14]
SCOOP_W3_DEG        = [24.54,  -92.51, -139.28,  -2.02,  14.10, -129.45]
SCOOP_W4_DEG        = [51.50,  -93.16, -142.88, -25.98,  14.07,  -95.83]
SCOOP_SHAKE_DEG     = [51.50,  -93.16, -142.88, -25.98,  -3.77,  -95.83]
DISCHARGE_START_DEG = [51.50,  -93.16, -142.88, -25.98,  14.07,  -95.83]
W5_MOVE  = [-10.47, -108.61, -145.39, -8.02, 14.07, -95.83]
W6_POUR  = [-10.47, -108.61, -145.39, -8.02, 14.07,  25.01]
W7_FINAL = [0.0, -90.0, -90.0, -90.0, 90.0, 0.0]

# ==============================================================================
# 유틸 함수
# ==============================================================================
def deg_to_rad(deg): return deg * (math.pi / 180.0)
def joints_to_str(j): return "[" + ", ".join([f"{deg_to_rad(d):.5f}" for d in j]) + "]"
def to_str(p):        return "[" + ", ".join([f"{x:.5f}" for x in p]) + "]"

# ==============================================================================
# 로봇 제어 클래스
# ==============================================================================
class CartesianInfoPackage(cs.PrimaryPackage):
    def __init__(self): super().__init__(4); self.pose = None
    def parser(self, data: bytes):
        try: self.pose = list(struct.unpack_from('>iBdddddddddddd', data)[2:8])
        except: self.pose = None

class RobotController:
    def __init__(self, log_callback):
        self.log = log_callback
        self.primary   = cs.PrimaryClientInterface()
        self.dashboard = cs.DashboardClientInterface()
        self.pose_pkg  = CartesianInfoPackage()

    def connect_primary(self):
        try: return self.primary.connect(ROBOT_IP, 30001)
        except: return False

    def disconnect_primary(self):
        try: self.primary.disconnect()
        except: pass

    def get_pose(self):
        if self.primary.getPackage(self.pose_pkg, 1000) and self.pose_pkg.pose:
            return self.pose_pkg.pose
        return None

    def dashboard_power_on(self):
        if not self.dashboard.connect(ROBOT_IP, 29999):
            self.log("❌ 대시보드 연결 실패"); return False
        self.log("⚡ 로봇 전원 켜는 중...")
        self.dashboard.powerOn()
        time.sleep(7)
        self.log("🔓 브레이크 해제 중...")
        self.dashboard.brakeRelease()
        time.sleep(5)
        self.dashboard.disconnect()
        self.log("✅ 로봇 부팅 완료")
        return True

    def dashboard_power_off(self):
        if not self.dashboard.connect(ROBOT_IP, 29999): return False
        self.log("📴 로봇 전원 끄는 중...")
        self.dashboard.powerOff()
        time.sleep(2)
        self.dashboard.disconnect()
        return True

    def emergency_stop(self):
        self.log("🚨 [EMERGENCY STOP] 비상 정지!")
        self.primary.sendScript("stopj(10.0)")

    def run_home_pose(self):
        self.log("🚀 홈 위치로 이동 중...")
        self.primary.sendScript(f"movej({joints_to_str(HOME_POS_DEG)}, a=0.5, v=0.3)")
        time.sleep(6); self.log("✅ 홈 위치 도착 완료")

    def run_init_pose(self):
        self.log("🚀 [초기 위치] 이동 중...")
        self.primary.sendScript(f"movej({joints_to_str(CENTER_JOINT_DEG)}, a=0.8, v=0.5)")
        time.sleep(5); self.log("✅ 초기 위치 이동 완료")

    # ✅ params 딕셔너리를 인자로 받아서 사용
    def run_stirring(self, params: dict):
        r  = params["STIR_RADIUS_CM"] / 100.0
        z  = params["STIR_DEPTH_CM"]  / 100.0
        bx = params["X_BIAS_CM"]      / 100.0
        by = params["Y_BIAS_CM"]      / 100.0

        self.log(f"🔄 [교반] 반경:{params['STIR_RADIUS_CM']}cm "
                 f"깊이:{params['STIR_DEPTH_CM']}cm "
                 f"X보정:{params['X_BIAS_CM']}cm "
                 f"Y보정:{params['Y_BIAS_CM']}cm")
        self.primary.sendScript(f"movej({joints_to_str(CENTER_JOINT_DEG)}, a=0.8, v=0.5)")
        time.sleep(4)
        pose = self.get_pose()
        if not pose: self.log("❌ 자세 읽기 실패"); return
        fix_rot = pose[3:]
        p_c, p_s = CENTER_XYZ + fix_rot, START_XYZ + fix_rot
        ang = math.atan2(p_s[1]-p_c[1], p_s[0]-p_c[0])
        pts = [[(p_c[0] + r*math.cos(ang - 2*math.pi*i/36)) + bx,
                (p_c[1] + r*math.sin(ang - 2*math.pi*i/36)) + by,
                z] + fix_rot for i in range(73)]
        br = max(0.001, min((2*math.pi*r)/36*0.5, 0.05))
        cmds = ["def run_stir():"]
        cmds.append(f"  movel({to_str(pts[0])}, a=1.0, v=0.8)")
        cmds += [f"  movep({to_str(pt)}, a={CIRCLE_ACC}, v={CIRCLE_VEL}, r={br})" for pt in pts[1:]]
        cmds.append(f"  movep({to_str(pts[-1])}, a={CIRCLE_ACC}, v={CIRCLE_VEL}, r=0.0)")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        time.sleep(5); self.log("✅ 교반 완료")

    def run_scooping(self):
        self.log("🥄 [뜨기] 작업 실행")
        cmds = ["def run_scoop():"]
        cmds.append(f"  movej({joints_to_str(SCOOP_W1_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL})")
        cmds.append(f"  movej({joints_to_str(SCOOP_W2_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r=0.0)")
        cmds.append("  sleep(2.0)")
        cmds.append(f"  movej({joints_to_str(SCOOP_W3_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r={SCOOP_BLEND})")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        time.sleep(8)

    def run_shaking(self):
        self.log("👋 [털기] 작업 실행")
        cmds = ["def run_shake():"]
        cmds.append(f"  movej({joints_to_str(SCOOP_W4_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r=0.0)")
        for _ in range(4):
            cmds.append(f"  movej({joints_to_str(SCOOP_SHAKE_DEG)}, a={SHAKE_ACC}, v={SHAKE_VEL}, r={SHAKE_BLEND})")
            cmds.append(f"  movej({joints_to_str(SCOOP_W4_DEG)},    a={SHAKE_ACC}, v={SHAKE_VEL}, r={SHAKE_BLEND})")
        cmds.append(f"  movej({joints_to_str(SCOOP_W4_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r=0.0)")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        time.sleep(4)

    def run_discharge(self):
        self.log("🚚 [배출] 작업 실행")
        cmds = ["def run_discharge():"]
        cmds.append(f"  movej({joints_to_str(DISCHARGE_START_DEG)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append(f"  movej({joints_to_str(W5_MOVE)},             a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r={DISCHARGE_BLEND})")
        cmds.append(f"  movej({joints_to_str(W6_POUR)},             a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append("  sleep(2.0)")
        cmds.append(f"  movej({joints_to_str(W5_MOVE)},             a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r={DISCHARGE_BLEND})")
        cmds.append(f"  movej({joints_to_str(DISCHARGE_START_DEG)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append(f"  movej({joints_to_str(W7_FINAL)},            a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        time.sleep(12); self.log("✅ 배출 작업 완료")

    def run_integrated_test(self, params: dict):
        r  = params["STIR_RADIUS_CM"] / 100.0
        z  = params["STIR_DEPTH_CM"]  / 100.0
        bx = params["X_BIAS_CM"]      / 100.0
        by = params["Y_BIAS_CM"]      / 100.0

        self.log("▶ [전체 시퀀스] 실행")
        self.primary.sendScript(f"movej({joints_to_str(CENTER_JOINT_DEG)}, a=0.8, v=0.5)")
        time.sleep(4)
        pose = self.get_pose()
        if not pose: return
        fix_rot = pose[3:]
        p_c, p_s = CENTER_XYZ + fix_rot, START_XYZ + fix_rot
        ang = math.atan2(p_s[1]-p_c[1], p_s[0]-p_c[0])
        pts = [[(p_c[0] + r*math.cos(ang - 2*math.pi*i/36)) + bx,
                (p_c[1] + r*math.sin(ang - 2*math.pi*i/36)) + by,
                z] + fix_rot for i in range(73)]
        br = max(0.001, min((2*math.pi*r)/36*0.5, 0.05))
        cmds = ["def run_fry_process():"]
        cmds.append(f"  movel({to_str(pts[0])}, a=1.0, v=0.8)")
        cmds += [f"  movep({to_str(pt)}, a={CIRCLE_ACC}, v={CIRCLE_VEL}, r={br})" for pt in pts[1:]]
        cmds.append(f"  movep({to_str(pts[-1])}, a={CIRCLE_ACC}, v={CIRCLE_VEL}, r=0.0)")
        cmds.append(f"  movej({joints_to_str(SCOOP_W1_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL})")
        cmds.append(f"  movej({joints_to_str(SCOOP_W2_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r=0.0)")
        cmds.append("  sleep(2.0)")
        cmds.append(f"  movej({joints_to_str(SCOOP_W3_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r={SCOOP_BLEND})")
        cmds.append(f"  movej({joints_to_str(SCOOP_W4_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r=0.0)")
        for _ in range(4):
            cmds.append(f"  movej({joints_to_str(SCOOP_SHAKE_DEG)}, a={SHAKE_ACC}, v={SHAKE_VEL}, r={SHAKE_BLEND})")
            cmds.append(f"  movej({joints_to_str(SCOOP_W4_DEG)},    a={SHAKE_ACC}, v={SHAKE_VEL}, r={SHAKE_BLEND})")
        cmds.append(f"  movej({joints_to_str(SCOOP_W4_DEG)},            a={SCOOP_ACC},     v={SCOOP_VEL},     r=0.0)")
        cmds.append(f"  movej({joints_to_str(DISCHARGE_START_DEG)},     a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append(f"  movej({joints_to_str(W5_MOVE)},                 a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r={DISCHARGE_BLEND})")
        cmds.append(f"  movej({joints_to_str(W6_POUR)},                 a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append("  sleep(2.0)")
        cmds.append(f"  movej({joints_to_str(W5_MOVE)},                 a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r={DISCHARGE_BLEND})")
        cmds.append(f"  movej({joints_to_str(DISCHARGE_START_DEG)},     a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append(f"  movej({joints_to_str(W7_FINAL)},                a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        self.log("🏁 전체 시퀀스 명령 전송 완료")
        time.sleep(30)