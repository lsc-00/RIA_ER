#!/usr/bin/env bash
#
# 카메라 화면에서 음식 자리를 클릭 → 스쿱 모션 계획을 영상에 겹쳐 보기 · 공중 시연 · 실제 실행.
#
#     cd ~/cs612_ws/src/vendor/dev_log/jb/mesh
#     ./click_target_motion.sh                 창을 연다
#     ./click_target_motion.sh --air 0.40      공중 시연 높이를 40 cm 로
#     ./click_target_motion.sh --self-test     카메라 · 로봇 없이 계산 점검
#
# 하는 일
#   1. ROS 2 Jazzy · 워크스페이스 · ~/.bash_env 환경을 잡는다
#   2. 카메라 영상이 안 나오고 있으면 RealSense 를 보정 때와 같은 설정(640x480x30)으로 띄운다
#   3. click_target_motion.py 를 실행한다 (조작법은 그 파일 맨 위 설명). 로봇을 움직이는 키는 터미널에서 yes 확인
#   4. 끝나면 이 스크립트가 띄운 카메라만 정리한다. 원래 떠 있던 카메라는 건드리지 않는다.

set -o pipefail

HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
WS="$HERE"                                  # 워크스페이스: src/RIA_kettle 이 있는 상위 폴더 (이 폴더 위치와 무관)
while [ "$WS" != "/" ] && [ ! -d "$WS/src/RIA_kettle" ]; do WS="$(dirname -- "$WS")"; done
COLOR_TOPIC="/camera/camera/color/image_raw"
CAMERA_LOG="/tmp/click_target_motion_camera.log"

step() { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
ok()   { printf '\033[1;32m  OK\033[0m %s\n' "$*"; }
die()  { printf '\n\033[1;31m중단: %s\033[0m\n' "$*" >&2; exit 1; }

needs_camera=1
for arg in "$@"; do
    case "$arg" in
        --self-test|--image|-h|--help) needs_camera=0 ;;
    esac
done

set +u
[ -f /opt/ros/jazzy/setup.bash ] || die "ROS 2 Jazzy 가 없습니다."
# shellcheck disable=SC1091
source /opt/ros/jazzy/setup.bash
[ -f "$WS/install/setup.bash" ] || die "$WS 가 빌드되지 않았습니다. $WS/setup.sh 를 먼저 실행하세요."
# shellcheck disable=SC1091
source "$WS/install/setup.bash"
# shellcheck disable=SC1091
[ -f "$HOME/.bash_env" ] && source "$HOME/.bash_env"
export PYTHONDONTWRITEBYTECODE=1

if [ "$needs_camera" -eq 0 ]; then
    exec python3 "$HERE/click_target_motion.py" "$@"
fi

CAMERA_PID=""
cleanup() {
    [ -n "$CAMERA_PID" ] || return 0
    kill -0 "$CAMERA_PID" 2>/dev/null || return 0
    step "이 스크립트가 띄운 카메라 정리"
    local children
    children=$(pgrep -P "$CAMERA_PID" 2>/dev/null || true)
    kill -INT "$CAMERA_PID" 2>/dev/null
    for _ in $(seq 1 20); do
        kill -0 "$CAMERA_PID" 2>/dev/null || break
        sleep 0.5
    done
    for pid in $CAMERA_PID $children; do
        kill -0 "$pid" 2>/dev/null && kill -9 "$pid" 2>/dev/null
    done
    ok "정리 완료"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

has_publisher() {
    # ros2 출력을 grep -q 로 바로 넘기면 pipefail 아래에서 ros2 가 SIGPIPE 로 끝나 실패로 보일 수 있다.
    local info
    info=$(timeout 5 ros2 topic info "$COLOR_TOPIC" 2>/dev/null) || true
    grep -Eq '^Publisher count: [1-9][0-9]*$' <<< "$info"
}

step "카메라"
if has_publisher; then
    ok "이미 영상이 나오고 있습니다. 그대로 씁니다."
else
    lsusb 2>/dev/null | grep -q '8086:0b3a' || die "D435i 를 찾을 수 없습니다 (USB ID 8086:0b3a)."
    ros2 launch realsense2_camera rs_launch.py \
        align_depth.enable:=true \
        pointcloud.enable:=false \
        rgb_camera.color_profile:=640x480x30 \
        depth_module.depth_profile:=640x480x30 \
        > "$CAMERA_LOG" 2>&1 &
    CAMERA_PID=$!
    printf '  카메라 띄우는 중'
    for _ in $(seq 1 30); do
        has_publisher && break
        if ! kill -0 "$CAMERA_PID" 2>/dev/null; then
            printf '\n'; tail -20 "$CAMERA_LOG"
            die "카메라가 종료됐습니다. $CAMERA_LOG 를 확인하세요."
        fi
        printf '.'; sleep 1
    done
    printf '\n'
    has_publisher || die "카메라 영상 토픽이 나오지 않습니다: $COLOR_TOPIC ($CAMERA_LOG)"
    ok "카메라 기동 (로그 $CAMERA_LOG)"
fi

step "스쿱 모션 클릭 도구"
cat <<'EOF'
  수면 위 음식 자리를 클릭하면 계획이 영상에 겹쳐 나옵니다.
  a = 공중 시연, g = 실제 실행, h = 홈 복귀 (모두 이 터미널에서 yes 입력 후 움직임), SPACE = 정지, q = 끝.
  로봇은 홈 자세에서 시작해야 합니다. 비상정지 버튼은 손 닿는 곳에.
EOF
python3 "$HERE/click_target_motion.py" "$@"
