# ui/header.py
# 상단 헤더 바 (타이틀 + 시계 + 재시작/종료 버튼)를 담당합니다.

import datetime
import threading
import time
import flet as ft
from config import LABELS


def build_header(
    page: ft.Page,
    on_restart,
    on_shutdown,
) -> ft.Container:

    clock_text = ft.Text("", size=16)

    def update_clock():
        while True:
            clock_text.value = datetime.datetime.now().strftime(LABELS["clock_format"])
            try:
                page.update()
            except Exception:
                break
            time.sleep(1)

    threading.Thread(target=update_clock, daemon=True).start()

    return ft.Container(
        content=ft.Row([
            ft.Text(LABELS["app_title"], size=24, weight="bold"),
            ft.Container(expand=True),
            clock_text,
            ft.IconButton(
                ft.Icons.REFRESH,
                icon_color="blue",
                tooltip="다시시작",
                on_click=lambda e: on_restart(),
            ),
            ft.IconButton(
                ft.Icons.CLOSE,
                icon_color="red",
                tooltip="종료",
                on_click=lambda e: on_shutdown(),
            ),
        ]),
        padding=20,
        bgcolor="white",
    )