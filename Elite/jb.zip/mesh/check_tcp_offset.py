#!/usr/bin/env python3
"""
로봇에서 현재 TCP 자세와 펜던트 TCP 오프셋을 읽기만 해서, 보정 z(+0.300)와 CAD 높이(-0.151)의
약 450 mm 차이가 어디서 오는지 확인한다. 로봇에 어떤 명령도 보내지 않는다 (Primary 30001 수신만).

    python3 check_tcp_offset.py                 robot_runtime.yaml robot.ip 로봇에서 읽기
    python3 check_tcp_offset.py --ip 10.0.0.2
    python3 check_tcp_offset.py --self-test     로봇 없이 계산 검증

권장 사용
  보정 때처럼 스쿱 가운데 검은 표식을 물 표면에 맞춘 상태에서 실행한다.
  - 보고된 TCP z 가 +0.300 근처이고 TCP 오프셋이 0 이면: 보정 z 는 플랜지 높이다.
  - 보고된 TCP z 가 -0.151 근처면: TCP 가 표식에 맞게 설정됐고 CAD 배치와도 맞는다.

배경
  CartesianInfo(type 4) 패킷 = TCP [x,y,z,rx,ry,rz] 6개 + TCP 오프셋 [x,y,z,rx,ry,rz] 6개.
  (Elite_Robots_CS_SDK/doc/UserGuide/en/How-to-Parser-30001.en.md)
  기존 코드는 앞 6개만 쓴다. 회전 표현(RPY / 회전벡터)은 문서마다 달라 두 규약으로 모두 계산한다.
"""

import argparse
import struct
import sys

import numpy as np

# 아래 두 값은 설정이 아니라 2026-09-14 조사 당시 비교 기준 (TCP 미설정 · 플랜지 기준 보정). 지금 수면은 zone_motion.yaml water.
EXPECTED_SURFACE_Z_CAD = 0.30854 + 0.22370 - 0.6835   # 솥 바닥 + 100 L 수위 - 기둥 윗판 (STL, base 가 윗판에 직접 부착)
CALIBRATION_SURFACE_Z = 0.300103


def rotvec_to_matrix(v):
    v = np.asarray(v, dtype=float)
    th = np.linalg.norm(v)
    if th < 1e-12:
        return np.eye(3)
    k = v / th
    K = np.array([[0, -k[2], k[1]], [k[2], 0, -k[0]], [-k[1], k[0], 0]])
    return np.eye(3) + np.sin(th) * K + (1 - np.cos(th)) * K @ K


def rpy_to_matrix(v):
    a, b, c = v                                   # 고정축 X → Y → Z,  R = Rz · Ry · Rx
    ca, sa, cb, sb, cc, sc = np.cos(a), np.sin(a), np.cos(b), np.sin(b), np.cos(c), np.sin(c)
    Rx = np.array([[1, 0, 0], [0, ca, -sa], [0, sa, ca]])
    Ry = np.array([[cb, 0, sb], [0, 1, 0], [-sb, 0, cb]])
    Rz = np.array([[cc, -sc, 0], [sc, cc, 0], [0, 0, 1]])
    return Rz @ Ry @ Rx


CONVENTIONS = {'RPY': rpy_to_matrix, '회전벡터': rotvec_to_matrix}


def flange_from_tcp(tcp_pose, tcp_offset, to_matrix):
    """TCP 자세와 TCP 오프셋(플랜지 기준)으로 플랜지 위치 · 방향을 구한다."""
    R_tcp = to_matrix(tcp_pose[3:])
    R_off = to_matrix(tcp_offset[3:])
    R_flange = R_tcp @ R_off.T
    p_flange = np.asarray(tcp_pose[:3]) - R_flange @ np.asarray(tcp_offset[:3])
    return p_flange, R_flange


def parse_cartesian_info(data):
    values = struct.unpack_from('>iB12d', data)
    return list(values[2:8]), list(values[8:14])


def report(tcp_pose, tcp_offset):
    print(f'TCP 자세     x {tcp_pose[0]:+.4f}  y {tcp_pose[1]:+.4f}  z {tcp_pose[2]:+.4f} m   '
          f'rx {tcp_pose[3]:+.4f}  ry {tcp_pose[4]:+.4f}  rz {tcp_pose[5]:+.4f} rad')
    print(f'TCP 오프셋   x {tcp_offset[0]*1000:+.1f}  y {tcp_offset[1]*1000:+.1f}  z {tcp_offset[2]*1000:+.1f} mm   '
          f'rx {tcp_offset[3]:+.4f}  ry {tcp_offset[4]:+.4f}  rz {tcp_offset[5]:+.4f} rad')
    length = np.linalg.norm(tcp_offset[:3])
    print(f'  → 오프셋 길이 {length*1000:.1f} mm' + ('  (설정 안 됨: TCP = 플랜지)' if length < 1e-4 else ''))

    for name, fn in CONVENTIONS.items():
        p, R = flange_from_tcp(tcp_pose, tcp_offset, fn)
        tool_z = fn(tcp_pose[3:])[:, 2]
        tilt = np.degrees(np.arccos(np.clip(-tool_z[2], -1, 1)))
        print(f'\n[{name} 로 해석]  TCP 축이 연직 아래에서 {tilt:.1f}°, 플랜지 z {p[2]:+.4f} m '
              f'(TCP 보다 {(p[2]-tcp_pose[2])*1000:+.0f} mm)')
    print(f'\n비교: 보정 조리면 z {CALIBRATION_SURFACE_Z:+.3f} / CAD 로 본 수면 z {EXPECTED_SURFACE_Z_CAD:+.3f} '
          f'(base 가 기둥 윗판에 직접 부착, 100 L)')
    z = tcp_pose[2]
    print(f'  현재 TCP z 는 보정값과 {(z-CALIBRATION_SURFACE_Z)*1000:+.0f} mm, CAD 수면과 {(z-EXPECTED_SURFACE_Z_CAD)*1000:+.0f} mm 차이'
          '  (표식이 물 표면에 있을 때만 의미 있음)')


def read_robot(ip, timeout_ms):
    import elite_cs_sdk as cs

    class CartesianInfo(cs.PrimaryPackage):
        def __init__(self):
            super().__init__(4)
            self.values = None

        def parser(self, data):
            try:
                self.values = parse_cartesian_info(data)
            except struct.error:
                self.values = None

    client = cs.PrimaryClientInterface()
    if not client.connect(ip, 30001):
        raise SystemExit(f'Primary 30001 연결 실패: {ip}')
    try:
        pkg = CartesianInfo()
        for _ in range(5):
            if client.getPackage(pkg, timeout_ms) and pkg.values:
                return pkg.values
        raise SystemExit('CartesianInfo 패킷을 받지 못했습니다.')
    finally:
        client.disconnect()


def self_test():
    from scipy.spatial.transform import Rotation
    express = {'RPY': lambda R: Rotation.from_matrix(R).as_euler('xyz'),       # 고정축 X→Y→Z = Rz·Ry·Rx
               '회전벡터': lambda R: Rotation.from_matrix(R).as_rotvec()}
    ok = True
    rng = np.random.default_rng(1)
    for name, fn in CONVENTIONS.items():
        flange_p = rng.normal(size=3) * 0.3
        R_f = fn(rng.normal(size=3) * 0.8)
        offset = np.r_[rng.normal(size=3) * 0.2, rng.normal(size=3) * 0.3]
        R_t = R_f @ fn(offset[3:])
        tcp_pose = np.r_[flange_p + R_f @ offset[:3], express[name](R_t)]
        good_repr = np.allclose(fn(tcp_pose[3:]), R_t)
        p_hat, R_hat = flange_from_tcp(tcp_pose, offset, fn)
        good = good_repr and np.allclose(p_hat, flange_p) and np.allclose(R_hat, R_f)
        print(f'  [{"OK" if good else "FAIL"}] {name}: 알고 있는 플랜지 → TCP 자세 → flange_from_tcp 로 되찾기'
              f' (위치 오차 {np.linalg.norm(p_hat - flange_p):.1e} m)')
        ok &= good
    data = struct.pack('>iB12d', 125, 4, *range(1, 13))
    pose, off = parse_cartesian_info(data)
    good = pose == [1, 2, 3, 4, 5, 6] and off == [7, 8, 9, 10, 11, 12]
    print(f'  [{"OK" if good else "FAIL"}] CartesianInfo 12개 값 분리 (자세 6 + 오프셋 6)')
    ok &= good
    R = rpy_to_matrix([-3.131151, 0.011894, -1.502222])
    good = np.degrees(np.arccos(-R[2, 2])) < 2.0
    print(f'  [{"OK" if good else "FAIL"}] 보정 자세를 RPY 로 풀면 도구 축이 거의 연직 아래 ({np.degrees(np.arccos(-R[2, 2])):.2f}°)')
    return ok


def main():
    from runtime_config import RT, tcp_offset
    parser = argparse.ArgumentParser(description='TCP 자세와 TCP 오프셋을 읽기만 한다.')
    parser.add_argument('--ip', default=RT.robot.ip)
    parser.add_argument('--timeout-ms', type=int, default=1500)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        print('자체 점검')
        return 0 if self_test() else 1
    pose, offset = read_robot(args.ip, args.timeout_ms)
    report(pose, offset)
    expected = np.asarray(tcp_offset())
    gap = np.abs(np.asarray(offset) - expected)
    same = (np.linalg.norm(gap[:3]) <= float(RT.checks.tcp_offset_tolerance_m)
            and np.degrees(gap[3:]).max() <= float(RT.checks.tcp_offset_tolerance_deg))
    print(f'\n설정(robot_runtime.yaml)의 TCP 오프셋 {np.round(expected[:3] * 1000, 1).tolist()} mm, 회전 {expected[3:].tolist()} 와 '
          + ('같음' if same else f'다름 (위치 차이 {np.linalg.norm(gap[:3]) * 1000:.1f} mm) → 펜던트에 다시 입력하기 전에는 로봇을 움직이지 않는다'))
    return 0 if same else 2


if __name__ == '__main__':
    sys.exit(main())
