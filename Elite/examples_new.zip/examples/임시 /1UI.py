import flet as ft
import datetime
import threading
import time
import os
from robot_controller import RobotController

def build_ui(page: ft.Page, params: dict):
    # ── 페이지 기본 설정 ──────────────────────────────
    page.title = "RIA Lab Control Panel"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.bgcolor = ft.Colors.BLUE_GREY_50
    page.padding = 0

    # ── params를 UI에서 실시간으로 수정 가능한 dict로 복사
    current_params = dict(params)

    # ── 로그 리스트 ───────────────────────────────────
    log_list = ft.ListView(expand=True, spacing=5, padding=10, auto_scroll=True)

    def log_handler(msg):
        ts = datetime.datetime.now().strftime("[%H:%M:%S]")
        log_list.controls.append(ft.Text(f"{ts} {msg}", size=14, color=ft.Colors.BLACK87))
        try: page.update()
        except: pass

    robot = RobotController(log_handler)

    # ── 화면 전환 헬퍼 ────────────────────────────────
    def set_page(control):
        page.controls.clear()
        page.controls.append(control)
        page.update()

    # ── 종료 ──────────────────────────────────────────
    def direct_shutdown():
        def _shutdown():
            robot.dashboard_power_off()
            os._exit(0)
        threading.Thread(target=_shutdown, daemon=True).start()

    # ── 로봇 태스크 실행 ──────────────────────────────
    def run_task(task_type):
        def _task():
            if task_type == "BOOTING":
                if robot.dashboard_power_on():
                    show_control()
                    run_task("HOME")
                else:
                    log_handler("❌ 부팅 실패")
                return
            if not robot.connect_primary():
                log_handler("❌ 로봇 연결 실패"); return
            try:
                if   task_type == "INIT":      robot.run_init_pose()
                elif task_type == "STIR":      robot.run_stirring(current_params)
                elif task_type == "SCOOP":     robot.run_scooping()
                elif task_type == "SHAKE":     robot.run_shaking()
                elif task_type == "DISCHARGE": robot.run_discharge()
                elif task_type == "ALL":       robot.run_integrated_test(current_params)
                elif task_type == "HOME":      robot.run_home_pose()
                elif task_type == "STOP":      robot.emergency_stop()
            except Exception as ex:
                log_handler(f"⚠️ 에러: {ex}")
            finally:
                robot.disconnect_primary()
        threading.Thread(target=_task, daemon=True).start()

    # ── 버튼 클릭 핸들러 ──────────────────────────────
    def on_btn_click(e):
        txt = e.control.content.controls[1].value \
              if isinstance(e.control.content, ft.Row) else "ALL"
        task_map = {
            "초기": "INIT", "교반": "STIR", "뜨기": "SCOOP",
            "털기": "SHAKE", "배출": "DISCHARGE", "비상": "STOP"
        }
        task = next((v for k, v in task_map.items() if k in txt), "ALL")
        run_task(task)

    def btn(text, icon, color):
        return ft.FilledButton(
            content=ft.Row([
                ft.Icon(icon, size=24, color="white"),
                ft.Text(text, size=18, weight="bold", color="white")
            ], spacing=20),
            style=ft.ButtonStyle(
                shape=ft.RoundedRectangleBorder(radius=10),
                bgcolor=color, padding=20
            ),
            width=float("inf"), height=70,
            on_click=on_btn_click
        )

    # ── 파라미터 슬라이더 위젯 생성 헬퍼 ─────────────
    def param_slider(label, key, min_val, max_val, divisions, unit="cm"):
        value_text = ft.Text(f"{current_params[key]:.1f} {unit}", size=14, width=70)
        input_field = ft.TextField(
            value=f"{current_params[key]:.1f}",
            width=80, height=40, text_size=14,
            content_padding=ft.padding.symmetric(horizontal=8, vertical=4),
            border_radius=8,
        )
        slider = ft.Slider(
            value=current_params[key],
            min=min_val, max=max_val,
            divisions=divisions,
            expand=True,
        )

        def on_slider_change(e):
            v = round(e.control.value, 1)
            current_params[key] = v
            value_text.value = f"{v:.1f} {unit}"
            input_field.value = f"{v:.1f}"
            page.update()

        def on_input_submit(e):
            try:
                v = float(input_field.value)
                v = max(min_val, min(max_val, round(v, 1)))
                current_params[key] = v
                slider.value = v
                value_text.value = f"{v:.1f} {unit}"
                input_field.value = f"{v:.1f}"
            except ValueError:
                input_field.value = f"{current_params[key]:.1f}"
            page.update()

        slider.on_change = on_slider_change
        input_field.on_submit = on_input_submit
        input_field.on_blur   = on_input_submit

        return ft.Container(
            content=ft.Column([
                ft.Text(label, size=14, weight="bold", color=ft.Colors.BLUE_GREY_700),
                ft.Row([slider, input_field, value_text], vertical_alignment=ft.CrossAxisAlignment.CENTER),
            ], spacing=4),
            bgcolor=ft.Colors.BLUE_GREY_50,
            border_radius=8,
            padding=ft.padding.symmetric(horizontal=12, vertical=8),
        )

    # ── 파라미터 패널 ─────────────────────────────────
    def build_param_panel():
        return ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Icon(ft.Icons.TUNE, color=ft.Colors.BLUE_700),
                    ft.Text("파라미터 설정", size=16, weight="bold", color=ft.Colors.BLUE_700),
                ]),
                ft.Divider(height=1),
                param_slider("교반 반경  STIR_RADIUS_CM", "STIR_RADIUS_CM", 5.0, 32.5, 55),
                param_slider("교반 깊이  STIR_DEPTH_CM",  "STIR_DEPTH_CM",  0.1,  5.0, 49),
                param_slider("앞뒤 보정  X_BIAS_CM",      "X_BIAS_CM",     -10.0, 10.0, 200),
                param_slider("좌우 보정  Y_BIAS_CM",      "Y_BIAS_CM",     -10.0, 10.0, 200),
                ft.Divider(height=1),
                ft.FilledButton(
                    content=ft.Row([
                        ft.Icon(ft.Icons.RESTART_ALT, color="white"),
                        ft.Text("기본값으로 초기화", color="white", size=13),
                    ], spacing=8),
                    style=ft.ButtonStyle(bgcolor=ft.Colors.BLUE_GREY_400),
                    on_click=lambda e: reset_params(),
                )
            ], spacing=10),
            bgcolor="white",
            border_radius=15,
            padding=20,
            margin=ft.margin.only(top=10),
        )

    def reset_params():
        for k, v in params.items():
            current_params[k] = v
        show_control()  # 화면 새로고침

    # ── 컨트롤 패널 구성 ──────────────────────────────
    def build_control_panel():
        left_col = ft.Column([
            ft.Text("수동 제어", size=18, weight="bold"),
            btn("1. 초기 위치",   ft.Icons.INPUT,        ft.Colors.INDIGO_500),
            btn("2. 교반 작업",   ft.Icons.LOOP,         ft.Colors.BLUE_500),
            btn("3. 뜨기 작업",   ft.Icons.ARROW_UPWARD, ft.Colors.CYAN_600),
            btn("4. 털기 작업",   ft.Icons.VIBRATION,    ft.Colors.TEAL_500),
            btn("5. 배출 / 이송", ft.Icons.OUTPUT,       ft.Colors.GREEN_600),
            build_param_panel(),  # ✅ 파라미터 패널 삽입
        ], spacing=15, scroll=ft.ScrollMode.AUTO)

        right_col = ft.Column([
            ft.Text("자동 제어 & 상태", size=18, weight="bold"),
            ft.Container(
                content=ft.FilledButton(
                    content=ft.Row([
                        ft.Icon(ft.Icons.WARNING_AMBER_ROUNDED, size=40, color="white"),
                        ft.Text("비상 정지 (STOP)", size=24, weight="bold", color="white")
                    ], alignment=ft.MainAxisAlignment.CENTER),
                    style=ft.ButtonStyle(
                        shape=ft.RoundedRectangleBorder(radius=10),
                        bgcolor=ft.Colors.RED_700
                    ),
                    width=float("inf"), height=80,
                    on_click=on_btn_click
                ), padding=ft.padding.only(bottom=10)
            ),
            ft.Container(
                content=ft.FilledButton(
                    content=ft.Column([
                        ft.Icon(ft.Icons.PLAY_CIRCLE_FILLED, size=60, color="white"),
                        ft.Text("전체 시퀀스 자동 동작", size=26, weight="bold", color="white"),
                        ft.Text("AUTO SEQUENCE START", size=14, color="white"),
                    ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                    style=ft.ButtonStyle(
                        shape=ft.RoundedRectangleBorder(radius=20),
                        bgcolor=ft.Colors.RED_600
                    ),
                    width=float("inf"), height=200,
                    on_click=on_btn_click
                ), padding=ft.padding.only(bottom=20)
            ),
            ft.Container(
                content=log_list,
                bgcolor="white", border_radius=10,
                border=ft.border.all(1, ft.Colors.GREY_300),
                expand=True, padding=10
            )
        ], spacing=15, expand=True)

        return ft.Row([
            ft.Container(left_col, expand=1, padding=30, bgcolor="white", border_radius=15, margin=10),
            ft.Container(right_col, expand=1, padding=30, border_radius=15)
        ], expand=True)

    # ── 화면 정의 ─────────────────────────────────────
    def show_home(e=None):
        set_page(
            ft.Container(
                content=ft.Column([
                    ft.Text("RIA Lab", size=60, weight="bold", color=ft.Colors.BLUE_GREY_900),
                    ft.Text("협동 로봇 자동 조리 시스템", size=30, weight="w900", color=ft.Colors.BLUE_GREY_700),
                    ft.Container(height=50),
                    ft.FilledButton(
                        "시작하기",
                        style=ft.ButtonStyle(bgcolor=ft.Colors.BLUE_600, color="white", padding=30),
                        on_click=lambda e: threading.Thread(target=show_booting_screen, daemon=True).start()
                    ),
                    ft.Container(height=20),
                    ft.FilledButton(
                        "종료하기",
                        style=ft.ButtonStyle(bgcolor=ft.Colors.RED_400, color="white", padding=30),
                        on_click=lambda e: direct_shutdown()
                    ),
                ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                alignment=ft.Alignment(0, 0),
                expand=True,
                bgcolor=ft.Colors.BLUE_GREY_50
            )
        )

    def show_booting_screen():
        set_page(
            ft.Container(
                content=ft.Column([
                    ft.ProgressRing(width=80, height=80, stroke_width=8, color=ft.Colors.BLUE),
                    ft.Text("시스템 부팅 중...", size=24, weight="bold", color=ft.Colors.BLUE_GREY_700),
                    ft.Text("로봇 전원을 켜고 브레이크를 해제하고 있습니다.", size=16, color=ft.Colors.GREY),
                ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                alignment=ft.Alignment(0, 0),
                expand=True
            )
        )
        run_task("BOOTING")

    def show_control(e=None):
        header = ft.Container(
            content=ft.Row([
                ft.Text("RIA Lab Control Panel", size=24, weight="bold"),
                ft.Container(expand=True),
                clock_text,
                ft.IconButton(ft.Icons.HOME, on_click=show_home),
                ft.IconButton(ft.Icons.CLOSE, icon_color="red", on_click=lambda e: direct_shutdown()),
            ]),
            padding=20, bgcolor="white"
        )
        set_page(
            ft.Column([
                header,
                ft.Container(build_control_panel(), expand=True, bgcolor=ft.Colors.BLUE_GREY_50)
            ], expand=True)
        )

    # ── 시계 ──────────────────────────────────────────
    clock_text = ft.Text("", size=16)

    def update_clock():
        while True:
            clock_text.value = datetime.datetime.now().strftime("현재시간 %H:%M:%S")
            try: page.update()
            except: break
            time.sleep(1)

    threading.Thread(target=update_clock, daemon=True).start()
    show_home()

# 파라미터 패널은 컨트롤 화면 왼쪽 하단에 이렇게 표시됩니다:
# ```
# ┌─────────────────────────────────┐
# │ 🎛 파라미터 설정                 │
# │─────────────────────────────────│
# │ 교반 반경  [====●========] 31.0 │
# │ 교반 깊이  [●═══════════]  1.0  │
# │ 앞뒤 보정  [═════●══════]  0.0  │
# │ 좌우 보정  [══════●═════]  5.0  │
# │─────────────────────────────────│
# │  [↺ 기본값으로 초기화]           │
# └─────────────────────────────────┘