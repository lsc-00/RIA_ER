# ui/teaching_panel.py
# 로봇 티칭(위치 기록) 페이지를 담당합니다.
# 실시간 조인트/포즈 값을 표시하고 JSON으로 저장합니다.

import flet as ft
import elite_cs_sdk as cs
import struct
import math
import time
import threading
import json
import os

from robot_controller import ROBOT_IP, HOME_POS_DEG, CENTER_JOINT_DEG


# ── SDK 패키지 (조인트 / 카테시안) ──────────────────
class _JointPkg(cs.PrimaryPackage):
    def __init__(self):
        super().__init__(1)
        self.joint_pos = None

    def parser(self, data: bytes):
        try:
            self.joint_pos = list(struct.unpack_from('>iBdddddd', data)[2:8])
        except:
            self.joint_pos = None


class _CartesianPkg(cs.PrimaryPackage):
    def __init__(self):
        super().__init__(4)
        self.pose = None

    def parser(self, data: bytes):
        try:
            self.pose = list(struct.unpack_from('>iBdddddddddddd', data)[2:8])
        except:
            self.pose = None


# ── 유틸 ─────────────────────────────────────────────
def _deg_to_rad(deg):
    return deg * (math.pi / 180.0)


def _joints_rad_str(joints_deg):
    return "[" + ", ".join([f"{_deg_to_rad(j):.5f}" for j in joints_deg]) + "]"


# ==================================================================
# 티칭 페이지 빌더
# ==================================================================
def build_teaching_page(
    page: ft.Page,
    on_back,
) -> ft.Column:
    """티칭 페이지를 빌드하여 반환합니다.
    on_back: 메인 제어 화면으로 복귀할 때 호출되는 콜백.
    """
    primary  = cs.PrimaryClientInterface()
    j_pkg    = _JointPkg()
    p_pkg    = _CartesianPkg()
    stop_evt = threading.Event()

    save_counter = [1]
    JSON_FILE    = "teaching_data.json"

    # ── 상태 텍스트 ──────────────────────────────────
    status_text = ft.Text(
        "🔌 로봇에 연결 중...",
        size=15, weight=ft.FontWeight.W_500,
        color=ft.Colors.ORANGE_700,
    )

    # ── 조인트 표시 ──────────────────────────────────
    joint_labels = [
        "J1 Base", "J2 Shoulder", "J3 Elbow",
        "J4 Wrist 1", "J5 Wrist 2", "J6 Wrist 3",
    ]
    joint_texts = [
        ft.Text(
            f"{lbl}: ---°", size=15,
            weight=ft.FontWeight.W_500,
            color=ft.Colors.BLUE_GREY_800,
            font_family="Consolas, monospace",
        )
        for lbl in joint_labels
    ]

    # ── 포즈 표시 ────────────────────────────────────
    pose_labels = ["X (m)", "Y (m)", "Z (m)", "Rx (rad)", "Ry (rad)", "Rz (rad)"]
    pose_texts = [
        ft.Text(
            f"{lbl}: ---", size=15,
            weight=ft.FontWeight.W_500,
            color=ft.Colors.BLUE_GREY_800,
            font_family="Consolas, monospace",
        )
        for lbl in pose_labels
    ]

    # ── 저장 로그 ────────────────────────────────────
    log_view = ft.ListView(expand=True, spacing=4)

    # ── 위치 이름 입력 ───────────────────────────────
    memo_input = ft.TextField(
        label="위치 이름 (예: stir_start, scoop_w1)",
        expand=True,
        height=48,
        text_size=14,
        border_radius=8,
    )

    # ── 데이터 읽기 ──────────────────────────────────
    def _get_data():
        joints, pose = None, None
        try:
            if primary.getPackage(j_pkg, 1000):
                joints = j_pkg.joint_pos
            if primary.getPackage(p_pkg, 1000):
                pose = p_pkg.pose
        except Exception:
            pass
        return joints, pose

    # ── 저장 ─────────────────────────────────────────
    def save_position(e):
        j, p = _get_data()
        if not (j and p):
            status_text.value = "❌ 데이터 읽기 실패"
            status_text.color = ft.Colors.RED_700
            page.update()
            return

        base_name = memo_input.value.strip()
        if not base_name:
            memo = f"pos_{save_counter[0]}"
            save_counter[0] += 1
        else:
            memo = base_name

        j_deg     = [round(x * 57.2958, 2) for x in j]
        p_rounded = [round(x, 4) for x in p]

        # 텍스트 파일 저장
        line = (
            f"[{time.strftime('%H:%M:%S')}] {memo}\n"
            f" - Joint(deg): {j_deg}\n"
            f" - Pose(m):    {p_rounded}\n\n"
        )
        with open("saved_positions.txt", "a", encoding="utf-8") as f:
            f.write(line)

        # JSON 저장
        data = {}
        if os.path.exists(JSON_FILE):
            try:
                with open(JSON_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
            except Exception:
                data = {}

        if memo not in data:
            data[memo] = {"joints": [], "poses": []}
        data[memo]["joints"].append(j_deg)
        data[memo]["poses"].append(p_rounded)

        with open(JSON_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=4, ensure_ascii=False)

        count = len(data[memo]["joints"])
        log_view.controls.insert(
            0,
            ft.Container(
                content=ft.Text(
                    f"💾 [{time.strftime('%H:%M:%S')}] {memo} #{count} 저장됨  |  Joint: {j_deg}",
                    size=12, color=ft.Colors.GREEN_800,
                ),
                bgcolor=ft.Colors.GREEN_50,
                border_radius=6,
                padding=ft.padding.symmetric(horizontal=8, vertical=4),
            ),
        )
        page.update()

    # ── 이동 버튼 ────────────────────────────────────
    def go_home(e):
        try:
            primary.sendScript(f"movej({_joints_rad_str(HOME_POS_DEG)}, a=0.5, v=0.3)")
            status_text.value = "🚀 홈 위치로 이동 중..."
            status_text.color = ft.Colors.BLUE_700
        except Exception as ex:
            status_text.value = f"❌ 이동 실패: {ex}"
            status_text.color = ft.Colors.RED_700
        page.update()

    def go_center(e):
        try:
            primary.sendScript(f"movej({_joints_rad_str(CENTER_JOINT_DEG)}, a=0.5, v=0.3)")
            status_text.value = "🚀 초기 위치로 이동 중..."
            status_text.color = ft.Colors.BLUE_700
        except Exception as ex:
            status_text.value = f"❌ 이동 실패: {ex}"
            status_text.color = ft.Colors.RED_700
        page.update()

    # ── 데이터 초기화 ────────────────────────────────
    def clear_sequence(e):
        base_name = memo_input.value.strip()
        if not base_name:
            return
        if os.path.exists(JSON_FILE):
            try:
                with open(JSON_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if base_name in data:
                    del data[base_name]
                    with open(JSON_FILE, "w", encoding="utf-8") as f:
                        json.dump(data, f, indent=4, ensure_ascii=False)
                    log_view.controls.insert(
                        0,
                        ft.Text(
                            f"🗑️ [{base_name}] 데이터 초기화됨",
                            size=12, color=ft.Colors.ORANGE_700,
                        ),
                    )
                    page.update()
            except Exception:
                pass

    # ── 돌아가기 ─────────────────────────────────────
    def do_back(e):
        stop_evt.set()
        try:
            primary.disconnect()
        except Exception:
            pass
        on_back()

    # ── 저장된 데이터 보기 (다이얼로그) ──────────────
    def show_saved_data(e):
        """teaching_data.json을 읽어 다이얼로그로 표시합니다."""
        if not os.path.exists(JSON_FILE):
            dlg = ft.AlertDialog(
                title=ft.Text("📂 저장된 데이터"),
                content=ft.Text("아직 저장된 데이터가 없습니다.", size=15),
                actions=[ft.TextButton("닫기", on_click=lambda e: _close_dlg(dlg))],
            )
            page.overlay.append(dlg)
            dlg.open = True
            page.update()
            return

        try:
            with open(JSON_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            data = {}

        if not data:
            dlg = ft.AlertDialog(
                title=ft.Text("📂 저장된 데이터"),
                content=ft.Text("저장된 데이터가 비어 있습니다.", size=15),
                actions=[ft.TextButton("닫기", on_click=lambda e: _close_dlg(dlg))],
            )
            page.overlay.append(dlg)
            dlg.open = True
            page.update()
            return

        # 데이터를 카드 형태의 리스트로 변환
        cards = []
        for name, entries in data.items():
            joint_list = entries.get("joints", [])
            pose_list  = entries.get("poses", [])
            count      = len(joint_list)

            # 각 포인트를 행으로 생성
            point_rows = []
            for idx in range(count):
                j_vals = joint_list[idx] if idx < len(joint_list) else []
                p_vals = pose_list[idx]  if idx < len(pose_list)  else []

                j_str = ", ".join([f"{v:.2f}" for v in j_vals]) if j_vals else "-"
                p_str = ", ".join([f"{v:.4f}" for v in p_vals]) if p_vals else "-"

                point_rows.append(
                    ft.Container(
                        content=ft.Column([
                            ft.Text(
                                f"  #{idx+1}",
                                size=12, weight=ft.FontWeight.BOLD,
                                color=ft.Colors.BLUE_GREY_700,
                            ),
                            ft.Text(
                                f"  Joint(deg): [{j_str}]",
                                size=11, color=ft.Colors.BLUE_GREY_600,
                                font_family="Consolas, monospace",
                            ),
                            ft.Text(
                                f"  Pose(m/rad): [{p_str}]",
                                size=11, color=ft.Colors.BLUE_GREY_600,
                                font_family="Consolas, monospace",
                            ),
                        ], spacing=2),
                        bgcolor=ft.Colors.GREY_50,
                        border_radius=6,
                        padding=ft.padding.symmetric(horizontal=10, vertical=6),
                    )
                )

            card = ft.Container(
                content=ft.Column([
                    ft.Row([
                        ft.Icon(ft.Icons.LOCATION_ON, size=18, color=ft.Colors.DEEP_PURPLE_500),
                        ft.Text(
                            f"{name}",
                            size=15, weight=ft.FontWeight.BOLD,
                            color=ft.Colors.DEEP_PURPLE_700,
                        ),
                        ft.Container(
                            content=ft.Text(
                                f"{count}개 저장됨",
                                size=11, color=ft.Colors.WHITE,
                            ),
                            bgcolor=ft.Colors.DEEP_PURPLE_300,
                            border_radius=10,
                            padding=ft.padding.symmetric(horizontal=8, vertical=2),
                        ),
                    ], spacing=8),
                    ft.Divider(height=1, color=ft.Colors.DEEP_PURPLE_100),
                    *point_rows,
                ], spacing=6),
                bgcolor="white",
                border=ft.border.all(1, ft.Colors.DEEP_PURPLE_100),
                border_radius=10,
                padding=12,
            )
            cards.append(card)

        dlg_content = ft.Container(
            content=ft.ListView(
                controls=cards,
                spacing=12,
            ),
            width=700,
            height=500,
        )

        dlg = ft.AlertDialog(
            title=ft.Row([
                ft.Icon(ft.Icons.FOLDER_OPEN, size=24, color=ft.Colors.DEEP_PURPLE_600),
                ft.Text("저장된 위치 데이터", size=18, weight=ft.FontWeight.BOLD),
                ft.Container(expand=True),
                ft.Text(
                    f"총 {len(data)}개 위치",
                    size=13, color=ft.Colors.BLUE_GREY_500,
                ),
            ], spacing=8),
            content=dlg_content,
            actions=[
                ft.TextButton("닫기", on_click=lambda e: _close_dlg(dlg)),
            ],
        )
        page.overlay.append(dlg)
        dlg.open = True
        page.update()

    def _close_dlg(dlg):
        dlg.open = False
        page.update()

    # ── 입력 필드 엔터 → 저장 ────────────────────────
    memo_input.on_submit = save_position

    # ── 백그라운드 폴링 스레드 ───────────────────────
    def _polling_loop():
        if not primary.connect(ROBOT_IP, 30001):
            status_text.value = "❌ 로봇 Primary 연결 실패"
            status_text.color = ft.Colors.RED_700
            try:
                page.update()
            except Exception:
                pass
            return

        status_text.value = "✅ 연결 성공 — 실시간 데이터 수신 중"
        status_text.color = ft.Colors.GREEN_700
        try:
            page.update()
        except Exception:
            pass

        while not stop_evt.is_set():
            j, p = _get_data()
            if j:
                for i, val in enumerate(j):
                    deg_val = round(val * 57.2958, 2)
                    joint_texts[i].value = f"{joint_labels[i]}: {deg_val:>8.2f}°"
            if p:
                for i, val in enumerate(p):
                    pose_texts[i].value = f"{pose_labels[i]}: {val:>10.4f}"
            try:
                page.update()
            except Exception:
                break
            time.sleep(0.15)

    threading.Thread(target=_polling_loop, daemon=True).start()

    # ==============================================================
    # 페이지 레이아웃 조립
    # ==============================================================
    return ft.Column([
        # ── 헤더 바 ──────────────────────────────────
        ft.Container(
            content=ft.Row([
                ft.FilledButton(
                    content=ft.Row([
                        ft.Icon(ft.Icons.ARROW_BACK, color="white", size=20),
                        ft.Text(
                            "제어 화면으로 돌아가기",
                            color="white", size=14,
                            weight=ft.FontWeight.BOLD,
                        ),
                    ], spacing=8),
                    style=ft.ButtonStyle(
                        bgcolor=ft.Colors.BLUE_GREY_600,
                        shape=ft.RoundedRectangleBorder(radius=8),
                    ),
                    on_click=do_back,
                ),
                ft.Row([
                    ft.Icon(ft.Icons.EDIT_LOCATION_ALT, size=24, color=ft.Colors.DEEP_PURPLE_700),
                    ft.Text(
                        "위치 기록 (Teaching)",
                        size=22, weight=ft.FontWeight.BOLD,
                        color=ft.Colors.DEEP_PURPLE_700,
                    ),
                ], spacing=8),
                ft.Container(width=200),  # 중앙 정렬용 스페이서
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            bgcolor="white",
            padding=ft.padding.symmetric(horizontal=20, vertical=14),
            shadow=ft.BoxShadow(
                blur_radius=10,
                color=ft.Colors.with_opacity(0.08, ft.Colors.BLACK),
            ),
        ),

        # ── 메인 컨텐츠 영역 ─────────────────────────
        ft.Container(
            content=ft.Row([

                # ====== 좌측 패널: 실시간 데이터 + 이동 버튼 ======
                ft.Container(
                    content=ft.Column([
                        # 상태
                        ft.Container(
                            content=ft.Column([
                                ft.Row([
                                    ft.Icon(ft.Icons.INFO_OUTLINE, size=18, color=ft.Colors.BLUE_GREY_600),
                                    ft.Text("연결 상태", size=16, weight=ft.FontWeight.BOLD,
                                            color=ft.Colors.BLUE_GREY_700),
                                ], spacing=6),
                                status_text,
                            ], spacing=6),
                            bgcolor=ft.Colors.BLUE_GREY_50,
                            border_radius=10,
                            padding=12,
                        ),

                        # 조인트 각도
                        ft.Container(
                            content=ft.Column([
                                ft.Row([
                                    ft.Icon(ft.Icons.PRECISION_MANUFACTURING,
                                            size=18, color=ft.Colors.INDIGO_600),
                                    ft.Text("조인트 각도 (deg)", size=16,
                                            weight=ft.FontWeight.BOLD,
                                            color=ft.Colors.INDIGO_700),
                                ], spacing=6),
                                ft.Divider(height=1, color=ft.Colors.INDIGO_100),
                                *joint_texts,
                            ], spacing=6),
                            bgcolor=ft.Colors.INDIGO_50,
                            border_radius=10,
                            padding=14,
                        ),

                        # 카테시안 포즈
                        ft.Container(
                            content=ft.Column([
                                ft.Row([
                                    ft.Icon(ft.Icons.OPEN_WITH, size=18,
                                            color=ft.Colors.TEAL_600),
                                    ft.Text("카테시안 포즈", size=16,
                                            weight=ft.FontWeight.BOLD,
                                            color=ft.Colors.TEAL_700),
                                ], spacing=6),
                                ft.Divider(height=1, color=ft.Colors.TEAL_100),
                                *pose_texts,
                            ], spacing=6),
                            bgcolor=ft.Colors.TEAL_50,
                            border_radius=10,
                            padding=14,
                        ),

                        # 빠른 이동 버튼
                        ft.Container(
                            content=ft.Column([
                                ft.Row([
                                    ft.Icon(ft.Icons.NEAR_ME, size=18,
                                            color=ft.Colors.BLUE_700),
                                    ft.Text("빠른 이동", size=16,
                                            weight=ft.FontWeight.BOLD,
                                            color=ft.Colors.BLUE_700),
                                ], spacing=6),
                                ft.Row([
                                    ft.FilledButton(
                                        content=ft.Row([
                                            ft.Icon(ft.Icons.HOME, color="white", size=18),
                                            ft.Text("홈 위치", color="white", size=13,
                                                     weight=ft.FontWeight.BOLD),
                                        ], spacing=6),
                                        style=ft.ButtonStyle(
                                            bgcolor=ft.Colors.BLUE_700,
                                            shape=ft.RoundedRectangleBorder(radius=8),
                                        ),
                                        expand=True,
                                        height=45,
                                        on_click=go_home,
                                    ),
                                    ft.FilledButton(
                                        content=ft.Row([
                                            ft.Icon(ft.Icons.MY_LOCATION, color="white", size=18),
                                            ft.Text("초기 위치", color="white", size=13,
                                                     weight=ft.FontWeight.BOLD),
                                        ], spacing=6),
                                        style=ft.ButtonStyle(
                                            bgcolor=ft.Colors.INDIGO_600,
                                            shape=ft.RoundedRectangleBorder(radius=8),
                                        ),
                                        expand=True,
                                        height=45,
                                        on_click=go_center,
                                    ),
                                ], spacing=10),
                            ], spacing=10),
                            bgcolor=ft.Colors.BLUE_50,
                            border_radius=10,
                            padding=14,
                        ),
                    ], spacing=12, scroll=ft.ScrollMode.AUTO),
                    bgcolor="white",
                    border_radius=15,
                    padding=20,
                    expand=1,
                ),

                # ====== 우측 패널: 저장 + 로그 ======
                ft.Container(
                    content=ft.Column([
                        # 저장 헤더
                        ft.Row([
                            ft.Icon(ft.Icons.SAVE_ALT, size=20,
                                    color=ft.Colors.DEEP_PURPLE_700),
                            ft.Text("위치 저장", size=18,
                                    weight=ft.FontWeight.BOLD,
                                    color=ft.Colors.DEEP_PURPLE_700),
                        ], spacing=8),

                        # 입력 + 삭제
                        ft.Row([
                            memo_input,
                            ft.IconButton(
                                ft.Icons.DELETE_SWEEP,
                                on_click=clear_sequence,
                                tooltip="현재 이름의 데이터 초기화",
                                icon_color=ft.Colors.RED_400,
                                icon_size=24,
                            ),
                        ], spacing=8),

                        # 저장 버튼
                        ft.FilledButton(
                            content=ft.Row([
                                ft.Icon(ft.Icons.SAVE, color="white", size=22),
                                ft.Text(
                                    "현재 위치 저장 (JSON 누적)",
                                    color="white", size=16,
                                    weight=ft.FontWeight.BOLD,
                                ),
                            ], spacing=10, alignment=ft.MainAxisAlignment.CENTER),
                            style=ft.ButtonStyle(
                                bgcolor=ft.Colors.DEEP_PURPLE_500,
                                shape=ft.RoundedRectangleBorder(radius=10),
                                padding=15,
                            ),
                            width=float("inf"),
                            height=65,
                            on_click=save_position,
                        ),

                        # 저장된 데이터 보기 버튼
                        ft.OutlinedButton(
                            content=ft.Row([
                                ft.Icon(ft.Icons.FOLDER_OPEN, size=18,
                                        color=ft.Colors.DEEP_PURPLE_500),
                                ft.Text(
                                    "저장된 데이터 보기",
                                    size=14, weight=ft.FontWeight.BOLD,
                                    color=ft.Colors.DEEP_PURPLE_500,
                                ),
                            ], spacing=8, alignment=ft.MainAxisAlignment.CENTER),
                            style=ft.ButtonStyle(
                                shape=ft.RoundedRectangleBorder(radius=10),
                                side=ft.BorderSide(1.5, ft.Colors.DEEP_PURPLE_300),
                            ),
                            width=float("inf"),
                            height=45,
                            on_click=show_saved_data,
                        ),

                        ft.Divider(height=1, color=ft.Colors.GREY_300),

                        # 로그 헤더
                        ft.Row([
                            ft.Icon(ft.Icons.LIST_ALT, size=18,
                                    color=ft.Colors.BLUE_GREY_600),
                            ft.Text("저장 로그", size=16,
                                    weight=ft.FontWeight.BOLD,
                                    color=ft.Colors.BLUE_GREY_700),
                        ], spacing=6),

                        # 로그 리스트
                        ft.Container(
                            content=log_view,
                            bgcolor=ft.Colors.GREY_50,
                            border_radius=10,
                            border=ft.border.all(1, ft.Colors.GREY_300),
                            expand=True,
                            padding=10,
                        ),
                    ], spacing=12, expand=True),
                    bgcolor="white",
                    border_radius=15,
                    padding=20,
                    expand=1,
                ),
            ], expand=True, spacing=15),
            expand=True,
            padding=15,
        ),
    ], expand=True)
