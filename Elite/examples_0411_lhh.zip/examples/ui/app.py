# ui/app.py
# UI 전체를 조립하는 진입점입니다.
# 큐 관리, 화면 전환, 종료/재시작 로직을 담당합니다.

import os
import time
import datetime
import threading
import multiprocessing
import flet as ft

from robot_worker import robot_worker
from config import APP_TITLE, APP_THEME, APP_BG_COLOR, LABELS, LAYOUT
from ui.state import AppState
from ui.boot_overlay import BootOverlay
from ui.header import build_header
from ui.control_panel import build_control_panel
from ui.auto_panel import build_auto_panel
from ui.teaching_panel import build_teaching_page
from ui.modify_panel import build_modify_page

def build_ui(page: ft.Page, params: dict):
    # ── 페이지 기본 설정 ──────────────────────────────
    page.title      = APP_TITLE
    page.theme_mode = APP_THEME
    page.bgcolor    = APP_BG_COLOR
    page.padding    = 0

    # ── 공유 상태 & 부팅 오버레이 초기화 ─────────────
    state        = AppState(params)
    boot_overlay = BootOverlay(page)

    # ── 로그 리스트 & 핸들러 ──────────────────────────
    log_list = ft.ListView(expand=True, spacing=5, padding=10, auto_scroll=True)

    def log_handler(msg: str):
        ts = datetime.datetime.now().strftime("[%H:%M:%S]")
        log_list.controls.append(
            ft.Text(f"{ts} {msg}", size=LAYOUT["log_font_size"], color=ft.Colors.BLACK87)
        )
        try:
            page.update()
        except Exception:
            pass

    # ── 멀티프로세싱 큐 & 워커 프로세스 시작 ─────────
    cmd_queue  = multiprocessing.Queue()
    log_queue  = multiprocessing.Queue()
    robot_proc = multiprocessing.Process(
        target=robot_worker,
        args=(cmd_queue, log_queue),
        daemon=True,
    )
    robot_proc.start()

    # ── 태스크 실행 요청 ──────────────────────────────
    def run_task(task_type: str):
        cmd_queue.put((task_type, state.current_params))

    # ── 즉각 제어 (메인 프로세스에서 직접 실행) ───────
    def instant_robot_action(action: str):
        def _action():
            from robot_controller import RobotController
            r = RobotController(log_handler)
            if action == "STOP":
                r.emergency_stop()
                log_queue.put(("TASK_END", "STOP"))
            elif action == "PAUSE":
                r.pause_program()
            elif action == "RESUME":
                r.resume_program()
        threading.Thread(target=_action, daemon=True).start()

    # ── 시스템 종료 ───────────────────────────────────
    def direct_shutdown():
        try:
            page.launch_url("javascript:window.open('','_self').close();")
        except Exception:
            pass

        page.controls.clear()
        boot_overlay.hide()
        page.controls.append(
            ft.Container(
                content=ft.Column([
                    ft.Icon(ft.Icons.POWER_OFF, size=80, color=ft.Colors.GREY_500),
                    ft.Text(
                        LABELS["shutdown_title"],
                        size=30, weight="bold",
                        color=ft.Colors.BLUE_GREY_700,
                    ),
                    ft.Text(
                        LABELS["shutdown_sub"],
                        size=18,
                        color=ft.Colors.GREY_600,
                    ),
                ], alignment=ft.MainAxisAlignment.CENTER,
                   horizontal_alignment=ft.CrossAxisAlignment.CENTER),
                alignment=ft.Alignment(0, 0),
                expand=True,
            )
        )
        page.update()
        cmd_queue.put(("SHUTDOWN", None))

    # ── 시스템 재시작 ─────────────────────────────────
    def restart_system():
        boot_overlay.show()
        cmd_queue.put(("RESTART", None))

    # ── 큐 리더 스레드 (워커 → UI 메시지 처리) ────────
    def queue_reader():
        while True:
            try:
                msg_type, msg_content = log_queue.get()
                if   msg_type == "LOG":          log_handler(msg_content)
                elif msg_type == "BOOT_SUCCESS": boot_overlay.hide()
                elif msg_type == "BOOT_FAILED":  boot_overlay.show_failed()
                elif msg_type == "TASK_START":   state.set_buttons_disabled(True, page)
                elif msg_type == "TASK_END":
                    state.set_buttons_disabled(False, page)
                    state.reset_pause_toggle(page)
                elif msg_type == "SHUTDOWN_DONE":
                    time.sleep(0.5)
                    os._exit(0)
            except Exception:
                pass

    threading.Thread(target=queue_reader, daemon=True).start()

    # ── 티칭 페이지 전환 ──────────────────────────────
    def show_teaching():
        page.controls.clear()
        teaching = build_teaching_page(page, on_back=show_control)
        page.controls.append(teaching)
        page.update()

    # ── 위치 수정 페이지 전환 ──────────────────────────────
    def show_modify():
        page.controls.clear()
        modify = build_modify_page(page, on_back=show_control)
        page.controls.append(modify)
        page.update()

    # ── 전체 화면 조립 ────────────────────────────────
    def show_control():
        state.action_buttons.clear()   # 재조립 시 중복 등록 방지
        header = build_header(page, on_restart=restart_system, on_shutdown=direct_shutdown)
        left   = build_control_panel(
            state, page, run_task,
            on_reset_params=show_control,
            on_teaching=show_teaching,
            on_modify=show_modify
        )
        right  = build_auto_panel(state, page, log_list, run_task, instant_robot_action)

        page.controls.clear()
        page.controls.append(
            ft.Column([
                header,
                ft.Container(
                    content=ft.Row([left, right], expand=True),
                    expand=True,
                    bgcolor=APP_BG_COLOR,
                ),
            ], expand=True)
        )
        page.update()

    # ── 최초 실행 ─────────────────────────────────────
    show_control()
    boot_overlay.show()
    run_task("BOOTING")
    