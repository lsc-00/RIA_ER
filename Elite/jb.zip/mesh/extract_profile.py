#!/usr/bin/env python3
"""
국솥 STL 에서 내솥의 설계 형상을 복원해 저장한다.

    python3 extract_profile.py

입력  pot_base.STL (mm)
      strainer_effector_link.stl (mm, 참고용)
      scoop.yaml (실제 뜰채 치수, 그림용)
      <워크스페이스>/src/RIA_calibration/config/plane_calibration.yaml (조리면 z, 있으면 바닥 높이 계산에 쓴다)
출력  kettle_profile.yaml      설계 형상(평면 + 원호) · 100 L 운용 값 · 설치 위치 · 수위 표 · CAD 링
      strainer_geometry.yaml   뜰채 STL 치수 (참고용. 실제 도구는 scoop.yaml)
      kettle_profile.png       단면 그림

방법
  1. z 가 같은 CAD 꼭짓점끼리 원을 맞춘다. 잘 맞는 링들의 중심이 회전축이다.
  2. 조리 공간을 향한 면의 링을 바닥 가장자리부터 위로 잇는다 (CAD 링).
  3. 벽 기울기가 다시 커지는 곳부터는 바깥으로 말린 림 립이다.
  4. 바닥 평면에 접하고 서로 접하는 원호로 벽 링을 맞춘다. 가장 적은 개수로 허용 오차 안에
     들어오는 원호 조합을 설계 형상으로 본다.
  5. 림 립은 벽 끝에 접하는 작은 원호와 직선으로 나타낸다.
"""

import struct
import sys
from pathlib import Path

import numpy as np
import yaml
from scipy.optimize import least_squares

sys.dont_write_bytecode = True     # 옆 모듈을 import 해도 이 디렉토리에 __pycache__ 를 남기지 않는다

HERE = Path(__file__).resolve().parent
POT_STL = HERE / 'pot_base.STL'
STRAINER_STL = HERE / 'strainer_effector_link.stl'
PROFILE_YAML = HERE / 'kettle_profile.yaml'
STRAINER_YAML = HERE / 'strainer_geometry.yaml'
PROFILE_PNG = HERE / 'kettle_profile.png'
WS = next(p for p in HERE.parents if (p / 'src' / 'RIA_kettle').is_dir())   # 워크스페이스 (이 폴더 위치와 무관)
CALIBRATION_YAML = WS / 'src' / 'RIA_calibration' / 'config' / 'plane_calibration.yaml'

SPEC_VOLUME_L = 250.0                     # 에너텍 ENR-500 사양의 내솥용량
SOUP_VOLUME_L = 100.0                     # 운용 조건: 국물은 항상 100 L (음식 부피 · 증발 무시)
URDF_POT_ORIGIN = (0.15, 1.09, -0.685)    # cs_pot_urdf.xacro 의 visual origin. 실제 설치와 다르다.

# 이 STL 에 맞춘 값이다. 다른 솥이면 kettle_profile.png 를 보고 조정한다.
RING_Z_STEP = 0.0002             # 같은 링으로 묶을 z 간격 [m]
RING_MAX_RESIDUAL = 0.0005       # 원 맞춤 허용 잔차 [m]
RING_MIN_POINTS = 12
RING_MIN_AZIMUTH_BINS = 6        # 30° 구간 12개 중 몇 곳 이상에 점이 있어야 링으로 인정
TRUNNION_HALF_WIDTH_DEG = 40.0   # 틸팅 축 보스(STL ±y 방향) 주변 방위는 링 계산에서 뺀다
POT_MAX_RADIUS = 0.60            # 축에서 이보다 먼 면은 뺀다. 기둥·프레임 꼭짓점이 같은 높이의 링에 섞이면 원 맞춤이 깨진다
POT_DEPTH_WINDOW = 0.42          # 림 꼭대기에서 이만큼 아래까지만 내솥. 더 아래는 인덕션 하우징
MIN_CAVITY_RINGS = 8             # 이보다 적게 이어지면 추출이 잘못된 것으로 보고 멈춘다
CHAIN_MAX_STEP = 0.08            # 단면 링을 이어 갈 때 허용하는 최대 간격 [m]
LIP_TILT_JUMP_DEG = 2.0          # 벽 기울기가 이만큼 다시 커지는 곳부터 림 립
ARC_FIT_TOLERANCE = 0.00005      # CAD 링이 이 안에 들어오면 설계 원호로 인정 [m]
MAX_WALL_ARCS = 3
STRAINER_NET_Y = -0.395          # 뜰채 STL 에서 이보다 -y 쪽이 망
STRAINER_MOUNT_Y = -0.11         # 이보다 +y 쪽이 마운트


# -- STL -------------------------------------------------------------------

def load_stl(path):
    """binary STL → (N, 3, 3) 삼각형 꼭짓점 [m]. 파일 단위는 mm 로 본다."""
    raw = Path(path).read_bytes()
    count = struct.unpack('<I', raw[80:84])[0]
    if len(raw) != 84 + 50 * count:
        raise ValueError(f'{Path(path).name}: binary STL 형식이 아닙니다.')
    record = np.dtype([('normal', '<f4', 3), ('v', '<f4', (3, 3)), ('attr', '<u2')])
    tri = np.frombuffer(raw, dtype=record, count=count, offset=84)['v']
    return tri.astype(np.float64) * 0.001


def unique_vertices(tri):
    return np.unique(np.round(tri.reshape(-1, 3), 7), axis=0)


# -- CAD 링 ------------------------------------------------------------------

def fit_circle(p):
    a = np.c_[2 * p[:, 0], 2 * p[:, 1], np.ones(len(p))]
    sol, *_ = np.linalg.lstsq(a, (p[:, :2] ** 2).sum(1), rcond=None)
    cx, cy = sol[:2]
    radius = float(np.sqrt(sol[2] + cx * cx + cy * cy))
    residual = float(np.abs(np.hypot(p[:, 0] - cx, p[:, 1] - cy) - radius).max())
    return float(cx), float(cy), radius, residual


def find_rings(vertices):
    """z 가 같은 꼭짓점 묶음 중 원에 잘 맞는 것 → 행마다 (r, z, cx, cy)."""
    key = np.round(vertices[:, 2] / RING_Z_STEP).astype(np.int64)
    order = np.argsort(key, kind='stable')
    key, vertices = key[order], vertices[order]
    rings = []
    for p in np.split(vertices, np.flatnonzero(np.diff(key)) + 1):
        if len(p) < RING_MIN_POINTS:
            continue
        cx, cy, radius, residual = fit_circle(p)
        if residual > RING_MAX_RESIDUAL or radius < 0.02:
            continue
        az = np.arctan2(p[:, 1] - cy, p[:, 0] - cx)
        bins = np.unique(np.floor((az + np.pi) / (np.pi / 6)).astype(int) % 12)
        if len(bins) >= RING_MIN_AZIMUTH_BINS:
            rings.append((radius, float(p[:, 2].mean()), cx, cy))
    return np.array(rings)


def find_axis(tri):
    rings = find_rings(unique_vertices(tri))
    rings = rings[rings[:, 0] > 0.05]
    center = np.median(rings[:, 2:4], axis=0)
    near = np.hypot(*(rings[:, 2:4] - center).T) < 0.002
    center = np.median(rings[near, 2:4], axis=0)
    spread = float(np.hypot(*(rings[near, 2:4] - center).T).max())
    return center, spread, int(near.sum())


def cavity_rings(tri, axis):
    """조리 공간 경계 링 (r, z) 을 아래에서 위로. 구간 이름도 같이 돌려준다."""
    c = tri.mean(axis=1)
    n = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    n /= np.linalg.norm(n, axis=1, keepdims=True) + 1e-15
    radial = c[:, :2] - axis
    rc = np.linalg.norm(radial, axis=1)
    radial /= rc[:, None] + 1e-15
    n_r = (n[:, :2] * radial).sum(1)
    facing_cavity = (-n_r + n[:, 2]) > 0.3
    az = np.degrees(np.arctan2(radial[:, 1], radial[:, 0]))
    trunnion = np.abs(np.abs(az) - 90.0) < TRUNNION_HALF_WIDTH_DEG
    near_axis = rc < POT_MAX_RADIUS

    rings = find_rings(unique_vertices(tri[facing_cavity & ~trunnion & near_axis]))
    rings = rings[np.hypot(rings[:, 2] - axis[0], rings[:, 3] - axis[1]) < 0.001]
    z_top = rings[:, 1].max()
    cand = rings[rings[:, 1] > z_top - POT_DEPTH_WINDOW][:, :2]

    chain = [cand[np.argmin(cand[:, 0])]]
    while True:
        cur = chain[-1]
        up = cand[(cand[:, 1] > cur[1] + 1e-6) & (cand[:, 0] >= cur[0] - 0.001)]
        if len(up) == 0:
            break
        d = np.hypot(up[:, 0] - cur[0], up[:, 1] - cur[1])
        i = int(np.argmin(d))
        if d[i] > CHAIN_MAX_STEP:
            break
        chain.append(up[i])
    chain = np.array(chain)
    if len(chain) < MIN_CAVITY_RINGS:
        raise RuntimeError(f'단면 링을 {len(chain)}개만 이었습니다. 추출 범위 상수를 확인하세요.\n'
                           f'  후보 링 (r, z): {np.round(cand, 4).tolist()}')

    tilt = np.degrees(np.arctan2(np.diff(chain[:, 0]), np.diff(chain[:, 1])))   # 0 = 수직
    lip_start = len(chain)
    for k in range(1, len(tilt)):
        if tilt[k] > tilt[k - 1] + LIP_TILT_JUMP_DEG:
            lip_start = k + 1
            break
    sections = (['bottom_edge'] + ['wall'] * (lip_start - 1)
                + ['rim_lip'] * (len(chain) - lip_start))
    return chain, sections


# -- 설계 형상 (평면 + 접하는 원호) -------------------------------------------------

def _u(angle):
    """원호 중심에서 angle 방향 단위벡터 (r, h). 0 = 바로 아래."""
    return np.array([np.sin(angle), -np.cos(angle)])


def _angle(center, point):
    return float(np.arctan2(point[0] - center[0], -(point[1] - center[1])))


def chain_arcs(r0, radii, joints):
    """바닥 평면 끝 (r0, 0) 에서 시작해 차례로 접하는 원호들."""
    arcs, point, start = [], np.array([r0, 0.0]), 0.0
    for i, radius in enumerate(radii):
        center = point - radius * _u(start)
        end = joints[i] if i < len(joints) else None
        arcs.append({'center': center, 'radius': float(radius), 'start': start, 'end': end})
        if end is not None:
            point, start = center + radius * _u(end), end
    return arcs


def distance_to_arcs(arcs, points):
    best = np.full(len(points), np.inf)
    for arc in arcs:
        v = points - arc['center']
        ang = np.arctan2(v[:, 0], -v[:, 1])
        end = np.pi if arc['end'] is None else arc['end']
        inside = (ang >= arc['start'] - 1e-12) & (ang <= end + 1e-12)
        d = np.where(inside, np.abs(np.hypot(v[:, 0], v[:, 1]) - arc['radius']), np.inf)
        for a in [arc['start']] + ([] if arc['end'] is None else [arc['end']]):
            e = arc['center'] + arc['radius'] * _u(a)
            d = np.minimum(d, np.hypot(*(points - e).T))
        best = np.minimum(best, d)
    return best


def fit_wall_arcs(wall):
    """벽 링을 가장 적은 개수의 접하는 원호로. → (원호 목록, 링별 오차)"""
    r0, points = wall[0, 0], wall[1:]
    for n in range(1, MAX_WALL_ARCS + 1):
        def residual(x, n=n):
            joints = x[n:]
            if np.any(np.diff(joints) <= 0):
                return np.full(len(points), 1.0)
            return distance_to_arcs(chain_arcs(r0, x[:n], joints), points)

        best = None
        for radius0 in (0.3, 0.45, 0.7):
            for spread in (0.6, 0.8, 1.0):
                joints0 = list(np.radians(np.linspace(0.0, 80.0 * spread, n + 1)[1:-1]))
                x0 = [radius0] * n + joints0
                bounds = ([0.02] * n + [0.0] * (n - 1), [5.0] * n + [np.pi / 2] * (n - 1))
                s = least_squares(residual, x0, bounds=bounds)
                if best is None or s.cost < best.cost:
                    best = s
        error = np.abs(best.fun)
        if error.max() <= ARC_FIT_TOLERANCE or n == MAX_WALL_ARCS:
            arcs = chain_arcs(r0, best.x[:n], best.x[n:])
            arcs[-1]['end'] = _angle(arcs[-1]['center'], wall[-1])
            return arcs, error


def circle_through(p1, p2, p3):
    a = np.array([[2 * (p2 - p1)[0], 2 * (p2 - p1)[1]], [2 * (p3 - p2)[0], 2 * (p3 - p2)[1]]])
    b = np.array([p2 @ p2 - p1 @ p1, p3 @ p3 - p2 @ p2])
    center = np.linalg.solve(a, b)
    return center, float(np.hypot(*(p1 - center)))


def angle_between_deg(v1, v2):
    c = abs(float(v1 @ v2)) / (np.linalg.norm(v1) * np.linalg.norm(v2))
    return float(np.degrees(np.arccos(np.clip(c, -1.0, 1.0))))


def design_pieces(wall, lip, arcs):
    r0 = float(wall[0, 0])
    pieces = [{'name': 'bottom', 'type': 'line', 'start_rh_m': [0.0, 0.0], 'end_rh_m': [r0, 0.0]}]
    for i, arc in enumerate(arcs, 1):
        pieces.append({
            'name': f'wall_arc_{i}', 'type': 'arc', 'radius_m': arc['radius'], 'center_rh_m': arc['center'],
            'start_rh_m': arc['center'] + arc['radius'] * _u(arc['start']),
            'end_rh_m': arc['center'] + arc['radius'] * _u(arc['end']),
            'sweep_deg': float(np.degrees(arc['end'] - arc['start'])),
        })
    top = np.asarray(pieces[-1]['end_rh_m'])
    tangency = []
    if len(lip) >= 2:
        center, radius = circle_through(top, lip[0], lip[1])
        tangency.append(angle_between_deg(top - arcs[-1]['center'], center - top))
        sweep = np.degrees((_angle(center, lip[1]) - _angle(center, top) + np.pi) % (2 * np.pi) - np.pi)
        pieces.append({'name': 'rim_lip', 'type': 'arc', 'radius_m': radius, 'center_rh_m': center,
                       'start_rh_m': top, 'end_rh_m': lip[1], 'sweep_deg': float(sweep)})
        if len(lip) >= 3:
            tangency.append(90.0 - angle_between_deg(lip[-1] - lip[1], lip[1] - center))
            pieces.append({'name': 'rim_top', 'type': 'line', 'start_rh_m': lip[1], 'end_rh_m': lip[-1]})
    elif len(lip) == 1:
        pieces.append({'name': 'rim_top', 'type': 'line', 'start_rh_m': top, 'end_rh_m': lip[0]})
    return pieces, tangency


# -- 뜰채 STL (참고용) -----------------------------------------------------------

def extract_strainer(tri):
    v = unique_vertices(tri)
    net = v[v[:, 1] < STRAINER_NET_Y]
    rim_z = float(net[:, 2].max())
    body = net[net[:, 2] < rim_z - 0.01]
    a = np.c_[2 * body, np.ones(len(body))]
    sol, *_ = np.linalg.lstsq(a, (body ** 2).sum(1), rcond=None)
    center = sol[:3]
    radius = float(np.sqrt(sol[3] + center @ center))
    rms = float(np.sqrt(np.mean((np.linalg.norm(body - center, axis=1) - radius) ** 2)))
    bottom = net[net[:, 2] < net[:, 2].min() + 0.002].mean(axis=0)
    rim = net[net[:, 2] > rim_z - 0.002]
    rim_radius = float(np.hypot(rim[:, 0] - center[0], rim[:, 1] - center[1]).mean())
    cap = float(np.degrees(np.arccos(np.clip((center[2] - rim_z) / radius, -1.0, 1.0))))

    spans = (tri[:, :, 1].min(axis=1) < -0.30) & (tri[:, :, 1].max(axis=1) > -0.15)
    hv = unique_vertices(tri[spans])
    hc = hv.mean(axis=0)
    direction = np.linalg.svd(hv - hc)[2][0]
    if direction[1] < 0:
        direction = -direction
    along = (hv - center) @ direction
    perp = (hv - hc) - np.outer((hv - hc) @ direction, direction)
    mount = v[v[:, 1] > STRAINER_MOUNT_Y]
    mount_along = (mount - center) @ direction

    return {
        'source': {'stl': STRAINER_STL.name, 'units_in_file': 'mm', 'triangles': int(len(tri)),
                   'note': '참고용. 실제 도구는 크기가 달라 scoop.yaml 치수를 쓴다.'},
        'frame': {'description': 'STL 원래 좌표 [m]. URDF(cs_macro_strainer.xacro)에서 wrist_3_link 원점에 그대로 붙는다.'},
        'net': {
            'sphere_center_m': center, 'sphere_radius_m': radius,
            'sphere_fit_rms_mm': round(rms * 1000, 2),
            'rim_z_m': rim_z, 'rim_radius_m': rim_radius,
            'depth_m': rim_z - float(net[:, 2].min()),
            'cap_half_angle_deg': round(cap, 2),
            'bottom_center_m': bottom,
        },
        'handle': {
            'axis_direction': direction,
            'diameter_m': 2 * float(np.linalg.norm(perp, axis=1).max()),
            'from_net_center_m': [float(along.min()), float(along.max())],
            'z_from_net_center_m': float(hc[2] - center[2]),
        },
        'mount': {
            'bbox_min_m': mount.min(axis=0), 'bbox_max_m': mount.max(axis=0),
            'from_net_center_m': [float(mount_along.min()), float(mount_along.max())],
        },
        'bottom_center_distance_from_origin_m': float(np.linalg.norm(bottom)),
    }


# -- 저장 ------------------------------------------------------------------

def clean(obj, digits=5):
    if isinstance(obj, dict):
        return {k: clean(v, digits) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, np.ndarray)):
        return [clean(v, digits) for v in obj]
    if isinstance(obj, (float, np.floating)):
        return round(float(obj), digits)
    if isinstance(obj, np.integer):
        return int(obj)
    return obj


class _Dumper(yaml.SafeDumper):
    """스칼라만 담은 리스트(좌표, 링 한 줄)는 한 줄로, 나머지는 블록으로 쓴다."""


def _represent_list(dumper, data):
    flow = all(not isinstance(v, (list, dict)) for v in data)
    return dumper.represent_sequence('tag:yaml.org,2002:seq', data, flow_style=flow)


_Dumper.add_representer(list, _represent_list)


PRECISE_SECTIONS = ('design',)   # 원호 중심 · 끝점을 따로 반올림하면 접합이 어긋나므로 0.1 µm 까지 남긴다


def write_yaml(path, header, doc):
    doc = {k: clean(v, 7 if k in PRECISE_SECTIONS else 5) for k, v in doc.items()}
    with open(path, 'w', encoding='utf-8') as f:
        for line in header:
            f.write(f'# {line}\n' if line else '#\n')
        yaml.dump(doc, f, Dumper=_Dumper, allow_unicode=True, sort_keys=False,
                  default_flow_style=False, width=1000)


def read_surface_z():
    if not CALIBRATION_YAML.exists():
        return None
    doc = yaml.safe_load(CALIBRATION_YAML.read_text(encoding='utf-8')) or {}
    value = doc.get('plane_calibrator', {}).get('ros__parameters', {}).get('cooking_surface_z')
    return None if value is None else float(value)


def save_png(kettle, planner):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(10.5, 8.2))
    b = kettle.boundary
    level = kettle.level_h
    soup = np.vstack([b[b[:, 1] <= level], [[kettle.surface_radius, level], [0.0, level]]])
    ax.fill(soup[:, 0], soup[:, 1], color='#a5d8ff', alpha=0.6,
            label=f'soup {kettle.soup_volume_L:.0f} L  (level h = {level * 1000:.1f} mm)')

    colors = {'bottom': '#212529', 'wall_arc_1': '#1971c2', 'wall_arc_2': '#e8590c',
              'wall_arc_3': '#2f9e44', 'rim_lip': '#868e96', 'rim_top': '#868e96'}
    for piece in kettle.pieces:
        pts = piece.sample(0.001)
        label = piece.name if piece.kind == 'line' else f'{piece.name}: R {piece.radius * 1000:.1f} mm'
        ax.plot(pts[:, 0], pts[:, 1], color=colors.get(piece.name, '#495057'), lw=2.4, label=label)
    for arc in kettle.walls:
        ax.plot(*arc.center, '+', color=colors.get(arc.name), ms=14, mew=2)
        ax.annotate(f'pivot  R {arc.radius * 1000:.0f}', arc.center, xytext=(6, 4), textcoords='offset points',
                    color=colors.get(arc.name), fontsize=9)
    if kettle.cad_rings:
        rings = np.array([[r, h] for r, h, _ in kettle.cad_rings])
        ax.plot(rings[:, 0], rings[:, 1], 'o', mfc='none', mec='#212529', ms=5, label='CAD rings')

    path = planner.waterline_path()
    tcp = np.array([p.tcp_rh_m for p in path])
    ax.plot(tcp[:, 0], tcp[:, 1], '-', color='#7048e8', lw=1.6, alpha=0.55,
            label=f'TCP path: wall contact {path[0].contact_h_m * 1000:.0f} → {path[-1].contact_h_m * 1000:.0f} mm '
                  f'(rotate {path[-1].tilt_deg - path[0].tilt_deg:.1f}° about pivot R470)')
    ax.plot(tcp[[0, -1], 0], tcp[[0, -1], 1], 'o', color='#7048e8', ms=4, alpha=0.55)

    pose = planner.pose_at(level)
    scoop = planner.scoop
    sphere, axis, handle = np.array(pose.sphere_center_rh_m), pose.axis_rh, pose.handle_rh
    cap = np.radians(scoop.cap_half_angle_deg)
    t = np.linspace(-cap, cap, 100)
    bowl = sphere + scoop.sphere_radius_m * (-np.cos(t)[:, None] * axis + np.sin(t)[:, None] * handle)
    rim_c = np.array(pose.rim_center_side_rh_m)
    ax.plot(bowl[:, 0], bowl[:, 1], color='#7048e8', lw=3,
            label=f'scoop  ø{scoop.rim_diameter_m * 1000:.0f} x {scoop.depth_m * 1000:.0f} mm, tilt {pose.tilt_deg:+.1f}°')
    ax.plot([pose.rim_wall_side_rh_m[0], rim_c[0]], [pose.rim_wall_side_rh_m[1], rim_c[1]], color='#7048e8', lw=0.8)
    handle_end = rim_c + scoop.handle_length_m * handle
    ax.plot([rim_c[0], handle_end[0]], [rim_c[1], handle_end[1]], color='#7048e8', lw=3)
    ax.plot(*pose.tcp_rh_m, 'o', color='#7048e8', ms=6)
    ax.plot([pose.pivot_rh_m[0], pose.contact_r_m], [pose.pivot_rh_m[1], pose.contact_h_m], '--', color='#7048e8', lw=0.8)
    ax.annotate(f'clearance {planner.clearance_m * 1000:.0f} mm at the waterline',
                (pose.contact_r_m, pose.contact_h_m), xytext=(0.16, 0.31), textcoords='data',
                color='#5f3dc4', fontsize=9, arrowprops=dict(arrowstyle='->', color='#7048e8'))

    ax.axvline(0, color='#adb5bd', ls='-.', lw=0.8)
    top = max(kettle.rim_top[1], max(a.center[1] for a in kettle.walls)) + 0.03
    ax.set_xlim(-0.01, 0.62)
    ax.set_ylim(-0.03, top)
    ax.set_aspect('equal')
    ax.grid(alpha=0.3)
    ax.set_xlabel('r  (distance from kettle axis) [m]')
    ax.set_ylabel('h  (height above bottom) [m]')
    ax.set_title('ENR-500 inner pot: flat bottom + tangent arcs (from pot_base.STL)')
    ax.legend(loc='lower right', fontsize=8.5)
    fig.tight_layout()
    fig.savefig(PROFILE_PNG, dpi=110)
    plt.close(fig)


def main():
    pot = load_stl(POT_STL)
    axis, spread, n_axis_rings = find_axis(pot)
    chain, sections = cavity_rings(pot, axis)
    bottom_z = float(chain[0, 1])
    rings = np.c_[chain[:, 0], chain[:, 1] - bottom_z]
    is_wall = np.array([s != 'rim_lip' for s in sections])
    wall, lip = rings[is_wall], rings[~is_wall]
    arcs, fit_error = fit_wall_arcs(wall)
    pieces, tangency = design_pieces(wall, lip, arcs)

    header = [
        'kettle_profile.yaml — 국솥(에너텍 ENR-500) 내솥 형상 · 로봇 기준 설치 위치 · 설계 운용 수위.',
        'extract_profile.py 가 pot_base.STL 에서 자동 생성한 파일. 직접 고치지 말 것.',
        '(placement 의 축 위치만 측정값으로 채워 넣는다: wall_touch_center.py apply, measure_kettle_axis.py 저장 — 이 머리말은 유지된다.)',
        '읽는 곳: ria_kettle KettleModel (계획기 · 스쿱 충돌 검사 · food_motion_node · pixel_to_base_node).',
        '지금 수면 높이는 이 파일이 아니라 water_level.yaml (여기 operating 은 100 L 설계값).',
        '',
        '좌표: 솥 좌표계 (원점 = 회전축과 바닥 평면의 교점, r = 축에서 수평 거리, h 위쪽, m)',
        '',
        '절 · 항목',
        '  source       STL 원본 (파일 · 단위 · 삼각형 수 · 복원 방법)',
        '  frame        STL 좌표에서 솥 축 위치 axis_in_stl_m · 바닥 높이 bottom_z_in_stl_m · 원 맞춤에 쓴 링 수 · 틸팅 회전축',
        '  design       설계 형상 조각 (bottom 바닥 평면 · wall_arc_1/2 벽 원호 · rim_lip · rim_top). 모든 계산이 이것을 쓴다.',
        '               start_rh_m / end_rh_m 조각 양 끝 (r, h) · center_rh_m / radius_m 원호 중심 · 반경 · sweep_deg 원호 각. fit = CAD 링과의 오차',
        '  operating    설계 운용 수위: soup_volume_L 일 때 level_h_m (바닥 위 수위) · surface_radius_m (수면 반경) · 그 높이의 벽 조각 · 벽 기울기',
        '  summary      요약 치수: 바닥 평면 반경 · 벽 끝 (r, h) · 림 꼭대기 (r, h) · 벽 끝 내경 · 벽 끝까지 부피 · 사양 부피',
        '  placement    로봇 base 기준 설치: axis_xy_in_base_m (솥 축 x, y — 로봇 벽 짚기) · bottom_z_in_base_m (솥 바닥 z)',
        '               *_source = 측정 방법 기록. urdf_draft 는 참고용 (실제 설치와 다름)',
        '  level_table  부피 [L] → 수위 level_h_m · 수면 반경 surface_radius_m 표',
        '  cad_rings    STL 에서 뽑은 원래 링 (r, h, 부위) — 설계 형상 검증용',
    ]
    urdf_axis = [axis[0] + URDF_POT_ORIGIN[0], axis[1] + URDF_POT_ORIGIN[1]]
    doc = {
        'source': {
            'stl': POT_STL.name, 'units_in_file': 'mm', 'triangles': int(len(pot)),
            'generated_by': Path(__file__).name,
            'method': 'CAD 꼭짓점 링마다 원 맞춤 → 조리 공간 쪽 링 연결 → 바닥 평면에 접하는 원호로 맞춤',
        },
        'frame': {
            'description': '솥 좌표계. 원점 = 회전축과 바닥 평면의 교점, h 는 위쪽, 단위 m. 회전체라 방위 기준은 필요 없다.',
            'axis_in_stl_m': axis, 'bottom_z_in_stl_m': bottom_z,
            'axis_ring_count': n_axis_rings,
            'ring_center_spread_mm': round(spread * 1000, 3),
            'trunnion_axis_in_stl': 'y (틸팅 회전축. 솥은 이 축을 중심으로 기운다)',
        },
        'design': {
            'description': 'CAD 링을 바닥 평면 + 서로 접하는 원호로 복원한 설계 형상. 모든 계산은 이것을 쓴다. '
                           '원호 각도는 원호 중심에서 본 방향 (0 = 바로 아래).',
            'pieces': pieces,
            'fit': {
                'wall_arc_count': len(arcs),
                'wall_ring_count': int(len(wall) - 1),
                'max_error_mm': round(float(fit_error.max()) * 1000, 4),
                'rms_error_mm': round(float(np.sqrt(np.mean(fit_error ** 2))) * 1000, 4),
                'rim_tangency_error_deg': [round(t, 3) for t in tangency],
            },
        },
        'cad_rings': {
            'columns': ['r_m', 'h_m', 'section'],
            'note': 'STL 에서 뽑은 원래 점. 설계 형상 검증용.',
            'rings': [[float(r), float(h), s] for (r, h), s in zip(rings, sections)],
        },
    }
    write_yaml(PROFILE_YAML, header, doc)       # 모델을 읽어 운용 값을 계산하기 위한 1차 저장

    from kettle_model import KettleModel
    from scoop_path import ScoopGeometry, WallScoopPlanner

    kettle = KettleModel.from_yaml(PROFILE_YAML)
    level = float(kettle.level_for_volume(SOUP_VOLUME_L))
    level_arc, level_alpha = kettle.wall_arc_at(level)
    surface_z = read_surface_z()
    bottom_base = None if surface_z is None else surface_z - level

    level_rows = []
    for litre in np.arange(10, int(kettle.max_volume_L) + 1, 10):
        h = float(kettle.level_for_volume(litre))
        level_rows.append([int(litre), h, float(kettle.wall_radius(h))])

    final = {
        'source': doc['source'],
        'frame': doc['frame'],
        'design': doc['design'],
        'operating': {
            'soup_volume_L': SOUP_VOLUME_L,
            'level_h_m': level,
            'surface_radius_m': float(kettle.wall_radius(level)),
            'wall_piece_at_level': level_arc.name,
            'wall_tilt_at_level_deg': 90.0 - float(np.degrees(level_alpha)),
            'note': '국물은 항상 100 L 로 본다 (음식 부피 · 증발 무시). 이 수면이 평면 보정의 조리면(cooking_surface_z)이다.',
        },
        'summary': {
            'bottom_flat_radius_m': kettle.bottom_flat_radius,
            'wall_top_r_m': kettle.wall_top[0], 'wall_top_h_m': kettle.wall_top[1],
            'rim_top_r_m': kettle.rim_top[0], 'rim_top_h_m': kettle.rim_top[1],
            'inner_diameter_at_wall_top_m': 2 * kettle.wall_top[0],
            'volume_to_wall_top_L': round(kettle.max_volume_L, 1),
            'spec_volume_L': SPEC_VOLUME_L,
        },
        'placement': {
            'axis_xy_in_base_m': None,
            'bottom_z_in_base_m': bottom_base,
            'bottom_z_source': (f'plane_calibration.yaml cooking_surface_z ({surface_z:.6f}) − {SOUP_VOLUME_L:.0f} L 수위 '
                                f'({level:.5f}). CAD 기준.' if bottom_base is not None
                                else '평면 보정 파일을 찾지 못해 비워 둠'),
            'note': '솥 축의 x, y 는 CAD 로 알 수 없다. 카메라에서 수면 테두리를 여러 점 찍거나 TCP 로 벽을 짚어 '
                    '원을 맞춘 뒤 채울 것.',
            'urdf_draft': {
                'file': 'cs_pot_urdf.xacro',
                'axis_xy_in_base_m': urdf_axis,
                'bottom_z_in_base_m': bottom_z + URDF_POT_ORIGIN[2],
                'warning': '실제 설치와 다르다. 참고만 할 것.',
            },
        },
        'level_table': {
            'columns': ['volume_L', 'level_h_m', 'surface_radius_m'],
            'rows': level_rows,
        },
        'cad_rings': doc['cad_rings'],
    }
    write_yaml(PROFILE_YAML, header, final)

    strainer_doc = extract_strainer(load_stl(STRAINER_STL))
    write_yaml(STRAINER_YAML, ['extract_profile.py 가 strainer_effector_link.stl 에서 자동 생성한 파일. 참고용.'],
               strainer_doc)

    kettle = KettleModel.from_yaml(PROFILE_YAML)
    save_png(kettle, WallScoopPlanner(kettle, ScoopGeometry.from_yaml()))

    print(f'회전축 (STL 좌표)   x={axis[0]:+.4f}  y={axis[1]:+.4f} m   (링 {n_axis_rings}개, 중심 흩어짐 {spread * 1000:.3f} mm)')
    print(f'CAD 링             {len(rings)}개  (바닥 가장자리 1, 벽 {int(is_wall.sum()) - 1}, 림 립 {int((~is_wall).sum())})')
    print(f'설계 형상          벽 원호 {len(arcs)}개, CAD 벽 링 오차 최대 {fit_error.max() * 1000:.4f} mm, '
          f'림 접합 오차 {", ".join(f"{t:.3f}°" for t in tangency)}')
    print(kettle.describe())
    if bottom_base is not None:
        print(f'바닥 z (로봇 base)   {bottom_base:.5f} m  = 보정 조리면 {surface_z:.6f} − 수위 {level:.5f}')
    for path in (PROFILE_YAML, STRAINER_YAML, PROFILE_PNG):
        print(f'저장: {path.name}')


if __name__ == '__main__':
    main()
