#!/usr/bin/env python3
"""
로봇 팔 링크(위팔 · 아래팔 · 손목 1~3)의 충돌 메시를 관절각에 붙여 솥과의 여유를 잰다. 로봇에 연결하지 않는다.

    python3 arm_clearance.py motion_runs/<기록>.yaml ...    기록된 경로(블렌드 포함)를 다시 확인
    python3 arm_clearance.py --self-test

왜
  계획기(ria_kettle)의 경로 규칙은 스쿱 망 · 손잡이 · 손목 캡슐까지만 본다. 2026-09-15 22:21 벽 마주 보기
  (반경 28.8 cm, 방위 −36°, 수면 z −0.225) 에서 아래팔이 로봇 쪽(+Y) 림에 닿아 PROTECTIVE_STOP.
  같은 경로를 이 검사로 보면 벽따라세우기 끝에서 아래팔 −14 mm (바로 뒤 22:25 완료한 경로는 +79 mm 이상).

판정 (robot_runtime.yaml checks.arm_*)
  - 솥 안 · 림 위 (솥 축에서 림 반경 + 2 cm 안): 링크 점의 솥 경계 부호 거리
  - 림 바깥 고리 (림 반경 + 2 cm ~ + arm_outer_ring_m): 링크 점 높이 − 림 꼭대기 (솥 외피 · 기둥은 모델에 없어 림 높이로 막음)
  두 값 중 작은 것이 arm_min_clearance_m 이상이어야 한다.
  관절각은 역기구학 (zone_motion_check.track_ik), 링크 위치는 URDF 명목 기구학 + 공식 충돌 메시 (컨트롤러와 약 9 mm 차이).
"""

import argparse
import math
import struct
import sys
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import yaml

sys.dont_write_bytecode = True

HERE = Path(__file__).resolve().parent

from runtime_config import RT, WS  # noqa: E402  (ria_kettle 경로를 잡는다)

MESH_DIR = (WS / 'src' / 'vendor' / 'Elite_Robots_CS_ROS2_Driver' / 'eli_cs_robot_description'
            / 'meshes' / 'cs612' / 'collision')
MESH_FILES = {'shoulder': 'shoulder.stl', 'upperarm': 'upperarm.stl', 'forearm': 'forearm.stl',
              'wrist_1': 'wrist1.stl', 'wrist_2': 'wrist2.stl', 'wrist_3': 'wrist3.stl'}
INNER_EXTRA_M = 0.02
COLLIDED_LOG = '20260915_222151_click_wall_face.yaml'     # 아래팔 림 충돌 (PROTECTIVE_STOP)
COMPLETED_LOG = '20260915_222507_click_wall_face.yaml'    # 같은 수면 · 정책, 완료


def load_stl_points(path, voxel_m):
    """STL 꼭짓점을 voxel_m 격자로 줄인 점들 (N, 3) [m]."""
    data = Path(path).read_bytes()
    if data[:5].lower() == b'solid' and b'facet' in data[:400]:
        v = np.array([[float(t) for t in line.split()[1:4]]
                      for line in data.decode(errors='ignore').splitlines() if line.strip().startswith('vertex')])
    else:
        n = struct.unpack_from('<I', data, 80)[0]
        rec = np.dtype([('n', '<f4', 3), ('v', '<f4', (3, 3)), ('a', '<u2')])
        v = np.frombuffer(data, dtype=rec, count=n, offset=84)['v'].reshape(-1, 3).astype(float)
    _, idx = np.unique(np.round(v / voxel_m).astype(np.int64), axis=0, return_index=True)
    return v[idx]


@dataclass
class ArmCheck:
    value_m: float                  # 경로 전체 최소 여유 (위 판정 두 값 중 작은 것)
    link: str
    kind: str
    index: int                      # 샘플 번호
    stage: str
    point: list                     # 가장 가까운 링크 점 (base)
    per_link: dict = field(default_factory=dict)


class ArmModel:
    _shared = None

    def __init__(self, links=None, voxel_m=None, outer_ring_m=None):
        from check_flange_fk import load_kinematics
        c = RT.checks
        self.links = list(c.arm_links if links is None else links)
        voxel = float(c.arm_mesh_voxel_m if voxel_m is None else voxel_m)
        self.outer_ring = float(c.arm_outer_ring_m if outer_ring_m is None else outer_ring_m)
        self.kinematics = load_kinematics()
        self.points = {name: load_stl_points(MESH_DIR / MESH_FILES[name], voxel) for name in self.links}

    @classmethod
    def shared(cls):
        if cls._shared is None:
            cls._shared = cls()
        return cls._shared

    def frames(self, q):
        """링크 이름 → base 기준 4×4 (관절 회전까지 적용한 링크 좌표계 = 충돌 메시 좌표계)."""
        from check_flange_fk import JOINTS, rot_z, urdf_origin
        T, out = np.eye(4), {}
        for name, angle in zip(JOINTS, q):
            k = self.kinematics[name]
            T = T @ urdf_origin([k['x'], k['y'], k['z']], [k['roll'], k['pitch'], k['yaw']])
            J = np.eye(4)
            J[:3, :3] = rot_z(angle)
            T = T @ J
            out[name] = T.copy()
        return out

    def margins(self, kettle, q):
        """링크별 (여유 m, 종류, base 점)."""
        F = self.frames(q)
        axis = np.asarray(kettle.placement['axis_xy_in_base_m'], dtype=float)
        rim_r = float(kettle.rim_top[0])
        rim_z = float(kettle.placement['bottom_z_in_base_m']) + float(kettle.rim_top[1])
        out = {}
        for name in self.links:
            T = F[name]
            P = self.points[name] @ T[:3, :3].T + T[:3, 3]
            r = np.hypot(P[:, 0] - axis[0], P[:, 1] - axis[1])
            best = (math.inf, '', None)
            inner = r <= rim_r + INNER_EXTRA_M
            if inner.any():
                d = np.asarray(kettle.signed_distance_xyz(P[inner], frame='base'), dtype=float)
                j = int(np.argmin(d))
                best = (float(d[j]), '솥 안 · 림', P[inner][j])
            ring = ~inner & (r <= rim_r + self.outer_ring)
            if ring.any():
                h = P[ring][:, 2] - rim_z
                j = int(np.argmin(h))
                if h[j] < best[0]:
                    best = (float(h[j]), '림 바깥 (림 꼭대기 위 높이)', P[ring][j])
            out[name] = best
        return out

    def check_path(self, kettle, qs, stages):
        """관절각 목록 → 경로 전체에서 가장 작은 여유 (ArmCheck). qs 가 비면 None."""
        worst, per_link = None, {n: math.inf for n in self.links}
        for i, q in enumerate(qs):
            for name, (value, kind, p) in self.margins(kettle, q).items():
                per_link[name] = min(per_link[name], value)
                if worst is None or value < worst.value_m:
                    worst = ArmCheck(value, name, kind, i, stages[i] if i < len(stages) else '',
                                     None if p is None else np.round(p, 3).tolist())
        if worst is not None:
            worst.per_link = per_link
        return worst


def make_path_check(planner, solver, need_m=None):
    """TargetPolicyPlanner.path_check 용: 경로 샘플 → (통과, 이유).
    역기구학이 안 되거나(관절 뜀 포함) 팔 링크가 솥에 checks.arm_min_clearance_m 보다 가까우면 실패 → 계획기가 다음 후보를 고른다."""
    from zone_motion_check import track_ik
    arm = ArmModel.shared()
    need = float(RT.checks.arm_min_clearance_m) if need_m is None else need_m

    def check(samples):
        qs, problems = track_ik(solver, samples)
        if problems:
            return False, f'역기구학: {problems[0]}'
        res = arm.check_path(planner.kettle, qs, [s for s, _, _ in samples])
        if res is not None and res.value_m < need:
            return False, (f'로봇 팔({res.link})이 솥에 {res.value_m * 1000:+.0f} mm ({res.stage}, {res.kind}, '
                           f'기준 {need * 1000:.0f} mm)')
        return True, ''

    return check


def samples_from_log(path):
    """실행 기록 → (기록, 계획기(그 실행의 수면), 블렌드 포함 경로 샘플)."""
    from ria_kettle import rpy_to_matrix
    from ria_kettle.zone_motion import Waypoint, ZoneMotionPlanner
    d = yaml.safe_load(Path(path).read_text(encoding='utf-8'))
    z = (d.get('config') or {}).get('surface_z_m')
    planner = ZoneMotionPlanner.from_yaml(water_surface_z=z if z is not None else 'current')
    wps = [planner.home] + [Waypoint(m['stage'], np.asarray(m['pose'][:3], dtype=float), rpy_to_matrix(m['pose'][3:]))
                            for m in d['moves']]
    radii = [0.0] + [float(m['r']) for m in d['moves']]
    radii[-1] = 0.0
    return d, planner, planner.sample(wps, radii)


def load_solver():
    from move_home_safe import make_solver
    from zone_motion_check import load_mdh
    return make_solver(load_mdh(False))


def check_log(path, solver, arm):
    from zone_motion_check import track_ik
    d, planner, samples = samples_from_log(path)
    qs, problems = track_ik(solver, samples)
    return d, arm.check_path(planner.kettle, qs, [s for s, _, _ in samples]), problems


def report(path, d, res, problems):
    need = float(RT.checks.arm_min_clearance_m)
    print(f'{Path(path).name}: {d.get("title")} {d.get("target_polar_cm_deg")} → {d.get("result")}')
    if problems:
        print(f'  역기구학 문제: {problems[0]}')
    if res is None:
        print('  관절각 없음')
        return False
    print('  링크별 최소 여유 [mm]: ' + ', '.join(f'{n} {v * 1000:+.0f}' for n, v in res.per_link.items()))
    ok = res.value_m >= need
    print(f'  {"통과" if ok else "막음"}: 최소 {res.value_m * 1000:+.0f} mm ({res.stage} · {res.link} · {res.kind} · base {res.point}), '
          f'기준 {need * 1000:.0f} mm')
    return ok


def self_test():
    solver, _loader = load_solver()
    arm = ArmModel()
    ok = True
    for name, expect in ((COLLIDED_LOG, False), (COMPLETED_LOG, True)):
        path = HERE / 'motion_runs' / name
        if not path.exists():
            print(f'  [SKIP] {name} 없음')
            continue
        d, res, problems = check_log(path, solver, arm)
        got = res is not None and res.value_m >= float(RT.checks.arm_min_clearance_m)
        good = got == expect and (expect or res.link == 'forearm')
        ok &= good
        print(f'  [{"OK" if good else "FAIL"}] {name}: 실제 결과 "{d.get("result")}" ↔ 검사 {"통과" if got else "막음"}'
              f' (최소 {res.value_m * 1000:+.0f} mm, {res.link}, {res.stage})')
    return 0 if ok else 1


def main():
    parser = argparse.ArgumentParser(description='로봇 팔 링크 ↔ 솥 여유 확인 (로봇 연결 없음).')
    parser.add_argument('logs', nargs='*', help='motion_runs/*.yaml')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        return self_test()
    if not args.logs:
        parser.error('기록 파일을 주거나 --self-test')
    solver, _loader = load_solver()
    arm = ArmModel()
    ok = True
    for path in args.logs:
        ok &= report(path, *check_log(path, solver, arm))
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
