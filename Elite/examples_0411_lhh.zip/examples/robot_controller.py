import math
import struct
import time
import json
import os
import elite_cs_sdk as cs

# ==============================================================================
# 고정 상수 (파라미터 아닌 것들)
# ==============================================================================
ROBOT_IP = "192.168.0.100"

HOME_POS_DEG        = [0.0, -90.0, -90.0, -90.0, 90.0, 0.0]
CENTER_XYZ          = [0.80, -0.0, 0.3]
START_XYZ           = [0.50, -0.0, 0.3]
CENTER_JOINT_DEG    = [25.1, -83.00, -139.31, -47.68, 90.01, -69.29]

# 동작별 블렌드(전환 반경) 상수는 속도와 무관하게 유지
SCOOP_BLEND    = 0.05
SHAKE_BLEND    = 0.01
DISCHARGE_BLEND = 0.05

def _vel(params: dict, key: str) -> float:
    """params에서 속도를 읽고 전체 배율(SPEED_FACTOR_PCT)을 곱해 반환합니다."""
    factor = params.get("SPEED_FACTOR_PCT", 100.0) / 100.0
    return round(params.get(key, 1.0) * factor, 4)

JSON_PATH = "positions_data.json"

POSITIONS = {
    "SCOOP_W1_DEG"        : [20.71, -83.00, -139.31, -47.68,  90.01,  -69.29],
    "SCOOP_W2_DEG"        : [33.35, -101.85, -154.86, -12.85,  46.13,  -96.14],
    "SCOOP_W3_DEG"        : [24.54,  -92.51, -139.28,  -2.02,  14.10, -129.45],
    "SCOOP_W4_DEG"        : [51.50,  -93.16, -142.88, -25.98,  14.07,  -95.83],
    "SCOOP_SHAKE_DEG"     : [51.50,  -93.16, -142.88, -25.98,  -3.77,  -95.83],
    "DISCHARGE_START_DEG" : [51.50,  -93.16, -142.88, -25.98,  14.07,  -95.83],
    "W5_MOVE"  : [-10.47, -108.61, -145.39, -8.02, 14.07, -95.83],
    "W6_POUR"  : [-10.47, -108.61, -145.39, -8.02, 14.07,  25.01],
    "W7_FINAL" : [0.0, -90.0, -90.0, -90.0, 90.0, 0.0]
}

def load_positions():
    if os.path.exists(JSON_PATH):
        with open(JSON_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    return DEFAULT_POSITIONS

# 값은 positions_data.json에서 확인
POSITIONS = load_positions()

# ==============================================================================
# 유틸 함수
# ==============================================================================
def deg_to_rad(deg): return deg * (math.pi / 180.0)
def joints_to_str(j): return "[" + ", ".join([f"{deg_to_rad(d):.5f}" for d in j]) + "]"
def to_str(p):        return "[" + ", ".join([f"{x:.5f}" for x in p]) + "]"

# ==============================================================================
# 로봇 제어 클래스
# ==============================================================================
class CartesianInfoPackage(cs.PrimaryPackage):
    def __init__(self): super().__init__(4); self.pose = None
    def parser(self, data: bytes):
        try: self.pose = list(struct.unpack_from('>iBdddddddddddd', data)[2:8])
        except: self.pose = None

class RobotController:
    def __init__(self, log_callback):
        self.log = log_callback
        self.primary   = cs.PrimaryClientInterface()
        self.dashboard = cs.DashboardClientInterface()
        self.pose_pkg  = CartesianInfoPackage()

    def connect_primary(self):
        try: return self.primary.connect(ROBOT_IP, 30001)
        except: return False

    def disconnect_primary(self):
        try: self.primary.disconnect()
        except: pass

    def get_pose(self):
        if self.primary.getPackage(self.pose_pkg, 1000) and self.pose_pkg.pose:
            return self.pose_pkg.pose
        return None

    def wait_for_motion(self, timeout=60, initial_sleep=1.0):
        time.sleep(initial_sleep)
        if not self.dashboard.connect(ROBOT_IP, 29999):
            time.sleep(timeout)
            return

        start_time = time.time()
        while time.time() - start_time < timeout:
            try:
                safety = self.dashboard.safetyMode()
                if safety in [
                    cs.SafetyMode.PROTECTIVE_STOP,
                    cs.SafetyMode.FAULT,
                    cs.SafetyMode.VIOLATION,
                    cs.SafetyMode.ROBOT_EMERGENCY_STOP,
                    cs.SafetyMode.SYSTEM_EMERGENCY_STOP
                ]:
                    self.log(f"⚠️ [경고] 로봇 안전 정지 감지됨! (상태: {safety.name})")
                    self.dashboard.disconnect()
                    raise RuntimeError(f"로봇 충돌/안전 정지 발생 ({safety.name})")

                status = self.dashboard.runningStatus()
                if status == cs.TaskStatus.STOPPED:
                    break

                time.sleep(0.5)
            except RuntimeError:
                raise
            except Exception:
                time.sleep(0.5)
        self.dashboard.disconnect()

    def dashboard_power_on(self):
        if not self.dashboard.connect(ROBOT_IP, 29999):
            self.log("❌ 대시보드 연결 실패"); return False
        self.log("⚡ 로봇 전원 켜는 중...")
        self.dashboard.powerOn()
        time.sleep(7)
        self.log("🔓 브레이크 해제 중...")
        self.dashboard.brakeRelease()
        time.sleep(5)
        self.dashboard.disconnect()
        self.log("✅ 로봇 부팅 완료")
        return True

    def dashboard_power_off(self):
        if not self.dashboard.connect(ROBOT_IP, 29999): return False
        self.log("📴 로봇 전원 끄는 중...")
        self.dashboard.powerOff()
        time.sleep(2)
        self.dashboard.disconnect()
        return True

    def emergency_stop(self):
        self.log("🚨 [EMERGENCY STOP] 비상 정지!")
        if self.dashboard.connect(ROBOT_IP, 29999):
            self.dashboard.stopProgram()
            self.dashboard.disconnect()
        try:
            self.primary.sendScript("stopj(10.0)")
        except: pass

    def pause_program(self):
        self.log("⏸️ [PAUSE] 작업 일시 정지")
        if self.dashboard.connect(ROBOT_IP, 29999):
            self.dashboard.pauseProgram()
            self.dashboard.disconnect()

    def resume_program(self):
        self.log("▶️ [RESUME] 작업 재개")
        if self.dashboard.connect(ROBOT_IP, 29999):
            self.dashboard.playProgram()
            self.dashboard.disconnect()

    def run_home_pose(self):
        self.log("🚀 홈 위치로 이동 중...")
        self.primary.sendScript(f"movej({joints_to_str(HOME_POS_DEG)}, a=0.5, v=0.3)")
        self.wait_for_motion(timeout=15, initial_sleep=1.0)
        self.log("✅ 홈 위치 도착 완료")

    def run_init_pose(self):
        self.log("🚀 [초기 위치] 이동 중...")
        self.primary.sendScript(f"movej({joints_to_str(CENTER_JOINT_DEG)}, a=0.8, v=0.5)")
        self.wait_for_motion(timeout=15, initial_sleep=1.0)
        self.log("✅ 초기 위치 이동 완료")

    def run_stirring(self, params: dict):
        r  = params["STIR_RADIUS_CM"] / 100.0
        z  = params["STIR_DEPTH_CM"]  / 100.0
        bx = params["X_BIAS_CM"]      / 100.0
        by = params["Y_BIAS_CM"]      / 100.0
        cv = _vel(params, "CIRCLE_VEL")
        ca = _vel(params, "CIRCLE_ACC")

        self.log(f"🔄 [교반] 반경:{params['STIR_RADIUS_CM']}cm "
                 f"깊이:{params['STIR_DEPTH_CM']}cm "
                 f"X보정:{params['X_BIAS_CM']}cm "
                 f"Y보정:{params['Y_BIAS_CM']}cm "
                 f"v={cv:.2f} a={ca:.2f}")
        self.primary.sendScript(f"movej({joints_to_str(CENTER_JOINT_DEG)}, a=0.8, v=0.5)")
        self.wait_for_motion(timeout=15, initial_sleep=1.0)
        pose = self.get_pose()
        if not pose: self.log("❌ 자세 읽기 실패"); return
        fix_rot = pose[3:]
        p_c, p_s = CENTER_XYZ + fix_rot, START_XYZ + fix_rot
        ang = math.atan2(p_s[1]-p_c[1], p_s[0]-p_c[0])
        pts = [[(p_c[0] + r*math.cos(ang - 2*math.pi*i/36)) + bx,
                (p_c[1] + r*math.sin(ang - 2*math.pi*i/36)) + by,
                z] + fix_rot for i in range(73)]
        br = max(0.001, min((2*math.pi*r)/36*0.5, 0.05))
        cmds = ["def run_stir():"]
        cmds.append(f"  movel({to_str(pts[0])}, a=1.0, v=0.8)")
        cmds += [f"  movep({to_str(pt)}, a={ca}, v={cv}, r={br})" for pt in pts[1:]]
        cmds.append(f"  movep({to_str(pts[-1])}, a={ca}, v={cv}, r=0.0)")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        self.wait_for_motion(timeout=60, initial_sleep=2.0)
        self.log("✅ 교반 완료")

    def run_scooping(self, params: dict):
        sv = _vel(params, "SCOOP_VEL")
        sa = _vel(params, "SCOOP_ACC")
        self.log(f"🥄 [뜨기] 작업 실행  v={sv:.2f} a={sa:.2f}")
        cmds = ["def run_scoop():"]
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('SCOOP_W1_DEG'))}, a={sa}, v={sv})")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('SCOOP_W2_DEG'))}, a={sa}, v={sv}, r=0.0)")
        cmds.append("  sleep(2.0)")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('SCOOP_W3_DEG'))}, a={sa}, v={sv}, r={SCOOP_BLEND})")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        self.wait_for_motion(timeout=30, initial_sleep=2.0)
        self.log("✅ 뜨기 작업 완료")

    def run_shaking(self, params: dict):
        sv = _vel(params, "SCOOP_VEL")
        sa = _vel(params, "SCOOP_ACC")
        hv = _vel(params, "SHAKE_VEL")
        ha = _vel(params, "SHAKE_ACC")
        self.log(f"👋 [털기] 작업 실행  shake v={hv:.2f} a={ha:.2f}")
        cmds = ["def run_shake():"]
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('SCOOP_W4_DEG'))}, a={sa}, v={sv}, r=0.0)")
        for _ in range(4):
            cmds.append(f"  movej({joints_to_str(POSITIONS.get('SCOOP_SHAKE_DEG'))}, a={ha}, v={hv}, r={SHAKE_BLEND})")
            cmds.append(f"  movej({joints_to_str(POSITIONS.get('SCOOP_W4_DEG'))},    a={ha}, v={hv}, r={SHAKE_BLEND})")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('SCOOP_W4_DEG'))}, a={sa}, v={sv}, r=0.0)")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        self.wait_for_motion(timeout=40, initial_sleep=2.0)
        self.log("✅ 털기 작업 완료")

    def run_discharge(self, params: dict):
        dv = _vel(params, "DISCHARGE_VEL")
        da = _vel(params, "DISCHARGE_ACC")
        self.log(f"🚚 [배출] 작업 실행  v={dv:.2f} a={da:.2f}")
        cmds = ["def run_discharge():"]
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('DISCHARGE_START_DEG'))}, a={da}, v={dv}, r=0.0)")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('W5_MOVE'))},             a={da}, v={dv}, r={DISCHARGE_BLEND})")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('W6_POUR'))},             a={da}, v={dv}, r=0.0)")
        cmds.append("  sleep(2.0)")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('W5_MOVE'))},             a={da}, v={dv}, r={DISCHARGE_BLEND})")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('DISCHARGE_START_DEG'))}, a={da}, v={dv}, r=0.0)")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('W7_FINAL'))},            a={da}, v={dv}, r=0.0)")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        self.wait_for_motion(timeout=40, initial_sleep=2.0)
        self.log("✅ 배출 작업 완료")

    def run_integrated_test(self, params: dict):
        r  = params["STIR_RADIUS_CM"] / 100.0
        z  = params["STIR_DEPTH_CM"]  / 100.0
        bx = params["X_BIAS_CM"]      / 100.0
        by = params["Y_BIAS_CM"]      / 100.0
        cv = _vel(params, "CIRCLE_VEL")
        ca = _vel(params, "CIRCLE_ACC")
        sv = _vel(params, "SCOOP_VEL")
        sa = _vel(params, "SCOOP_ACC")
        hv = _vel(params, "SHAKE_VEL")
        ha = _vel(params, "SHAKE_ACC")
        dv = _vel(params, "DISCHARGE_VEL")
        da = _vel(params, "DISCHARGE_ACC")

        self.log(f"▶ [전체 시퀀스] 실행  배율:{params.get('SPEED_FACTOR_PCT',100):.0f}%")
        self.primary.sendScript(f"movej({joints_to_str(CENTER_JOINT_DEG)}, a=0.8, v=0.5)")
        self.wait_for_motion(timeout=15, initial_sleep=1.0)
        pose = self.get_pose()
        if not pose: return
        fix_rot = pose[3:]
        p_c, p_s = CENTER_XYZ + fix_rot, START_XYZ + fix_rot
        ang = math.atan2(p_s[1]-p_c[1], p_s[0]-p_c[0])
        pts = [[(p_c[0] + r*math.cos(ang - 2*math.pi*i/36)) + bx,
                (p_c[1] + r*math.sin(ang - 2*math.pi*i/36)) + by,
                z] + fix_rot for i in range(73)]
        br = max(0.001, min((2*math.pi*r)/36*0.5, 0.05))
        cmds = ["def run_fry_process():"]
        cmds.append(f"  movel({to_str(pts[0])}, a=1.0, v=0.8)")
        cmds += [f"  movep({to_str(pt)}, a={ca}, v={cv}, r={br})" for pt in pts[1:]]
        cmds.append(f"  movep({to_str(pts[-1])}, a={ca}, v={cv}, r=0.0)")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('SCOOP_W1_DEG'))}, a={sa}, v={sv})")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('SCOOP_W2_DEG'))}, a={sa}, v={sv}, r=0.0)")
        cmds.append("  sleep(2.0)")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('SCOOP_W3_DEG'))}, a={sa}, v={sv}, r={SCOOP_BLEND})")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('SCOOP_W4_DEG'))}, a={sa}, v={sv}, r=0.0)")
        for _ in range(4):
            cmds.append(f"  movej({joints_to_str(POSITIONS.get('SCOOP_SHAKE_DEG'))}, a={ha}, v={hv}, r={SHAKE_BLEND})")
            cmds.append(f"  movej({joints_to_str(POSITIONS.get('SCOOP_W4_DEG'))},    a={ha}, v={hv}, r={SHAKE_BLEND})")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('SCOOP_W4_DEG'))},            a={sa}, v={sv}, r=0.0)")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('DISCHARGE_START_DEG'))},     a={da}, v={dv}, r=0.0)")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('W5_MOVE'))},                 a={da}, v={dv}, r={DISCHARGE_BLEND})")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('W6_POUR'))},                 a={da}, v={dv}, r=0.0)")
        cmds.append("  sleep(2.0)")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('W5_MOVE'))},                 a={da}, v={dv}, r={DISCHARGE_BLEND})")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('DISCHARGE_START_DEG'))},     a={da}, v={dv}, r=0.0)")
        cmds.append(f"  movej({joints_to_str(POSITIONS.get('W7_FINAL'))},                a={da}, v={dv}, r=0.0)")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        self.log("🏁 전체 시퀀스 명령 전송 완료")
        self.wait_for_motion(timeout=120, initial_sleep=2.0)
        self.log("✅ [전체 시퀀스] 모든 동작이 성공적으로 완료되었습니다!")