import numpy as np
import pytest

from ria_kettle import KettleModel, ScoopBody, ScoopGeometry, ScoopMount, rpy_to_matrix

# 2026-09-14 벽 짚기 B (src/vendor/dev_log/jb/mesh/wall_touch_center.py): 같은 스쿱 뒷면 점을 네 벽에 살짝 댄 TCP. 로봇 base, m / RPY rad.
WALL_TOUCH = {
    'far': [1.264766, -0.003498, -0.109784, 3.090239, 0.015202, -1.561197],
    'left': [0.813595, 0.485972, -0.109762, 3.090242, 0.015177, -0.001083],
    'near': [0.282911, -0.019232, -0.109829, 3.090347, 0.015271, 1.569785],
    'right': [0.793131, -0.493088, -0.109881, 3.090301, 0.015224, -3.13281],
}


@pytest.fixture(scope='module')
def kettle():
    return KettleModel.from_yaml(water_surface_z=None)      # 설계 수위 100 L 기준


@pytest.fixture(scope='module')
def body():
    return ScoopBody(ScoopGeometry.from_yaml(), ScoopMount.from_yaml())


def test_wall_touch_poses_are_in_contact(kettle, body):
    for name, pose in WALL_TOUCH.items():
        c = body.clearance(kettle, pose[:3], rpy_to_matrix(pose[3:]))
        assert abs(c.clearance_m) < 0.004, name
        assert c.part == ScoopBody.CAP, name


def test_pushing_past_the_wall_collides(kettle, body):
    pose = WALL_TOUCH['far']
    c = body.clearance(kettle, np.add(pose[:3], [0.03, 0.0, 0.0]), rpy_to_matrix(pose[3:]))
    assert c.clearance_m < -0.02


def test_scoop_at_kettle_center_is_free(kettle, body):
    ax, ay = kettle.placement['axis_xy_in_base_m']
    z = kettle.placement['bottom_z_in_base_m'] + kettle.level_h
    c = body.clearance(kettle, [ax, ay, z], rpy_to_matrix([np.pi, 0.0, -np.pi / 2]))
    assert c.clearance_m > 0.05


def test_rim_top_is_under_the_flange(body):
    assert body.rim_top_tool()[1] == pytest.approx(0.025, abs=0.005)


def test_surface_contains_xy(kettle):
    ax, ay = kettle.placement['axis_xy_in_base_m']
    r = kettle.surface_radius
    assert kettle.surface_contains_xy(ax + r - 0.04, ay, margin_m=0.03)
    assert not kettle.surface_contains_xy(ax + r - 0.02, ay, margin_m=0.03)
    assert kettle.radial_distance_xy(ax, ay + 0.1) == pytest.approx(0.1)
