#!/usr/bin/env python3
"""
카메라 화면에서 음식 자리를 클릭하면, 그 좌표로 스쿱 모션을 계획해 영상 위에 겹쳐 보여 주고 원하면 로봇으로 시연한다.

    ./click_target_motion.sh                         카메라를 띄우고 창을 연다 (권장)
    python3 click_target_motion.py --image frame.png --click 420 300 --no-window --out preview.png   (오프라인 확인)
    python3 click_target_motion.py --self-test       카메라 · 로봇 없이 계산 점검

좌표
  클릭 픽셀 → 로봇 x, y 는 평면 보정 호모그래피 (pixel_to_base_node 와 같은 변환, 수면 높이 평면).
  계획은 ria_kettle.target_policy (가운데 곧게 쓸기 / 대각선 훑기 / 벽 마주 보기).
  경로 · 스쿱 윤곽은 평면 보정점으로 맞춘 PnP 카메라로 3D 점을 투영해 그린다. 호모그래피와 솥 가장자리에서 수 cm 다를 수 있어
  모양 확인용이다. 보정점 영역(회색 선) 밖을 클릭하면 좌표가 수 cm 틀릴 수 있다고 표시한다.

창 조작 (화면 글자는 영어)
  왼쪽 클릭   그 자리로 계획                   c  지우기          f  영상 멈춤 · 재생
  0 1 2 3     정책 자동 / center / edge_sweep / wall_face (다시 계획)
  w           벽 마주 보기의 벽 쪽 세 단계 여유 순환 (robot_runtime.yaml click_tool.wall_clearance_cycle_mm, 이 창에서만, 다시 계획)
  a           공중 시연 (--air, 기본 click_tool.air = auto)       g  실제 높이 실행
  h           홈 복귀 (move_home_safe.py --go)
  space       정지 (stopl)                     s  그림 저장 (영상 겹침 + 세 방향 그림)     q, Esc  끝내기
  a · g · h 는 run_target_motion.py 와 같은 점검(로봇 상태 · TCP 설정 · 홈 자세 · 경로 규칙 · 역기구학)을 통과한 뒤
  터미널에서 yes 를 입력해야 움직인다. 결과는 motion_runs/ 에 남는다. 비상정지 버튼은 손 닿는 곳에.
"""

import argparse
import datetime as dt
import math
import subprocess
import sys
import threading
import time
from pathlib import Path

import numpy as np
import yaml

sys.dont_write_bytecode = True

HERE = Path(__file__).resolve().parent

import run_target_motion as runner  # noqa: E402  (ria_kettle 경로를 잡는다)
from measure_kettle_axis import (MEASUREMENT_YAML, PANEL_WIDTH, CameraGeometry, PlaneCalibration,  # noqa: E402
                                 draw_polyline, put_text)
from ria_kettle import ScoopBody  # noqa: E402
from ria_kettle.kettle_model import parse_water_surface_z  # noqa: E402
from ria_kettle.target_policy import WALL_STAGES, TargetPolicyPlanner  # noqa: E402
from ria_kettle.zone_motion import HOME, ZoneMotionPlanner  # noqa: E402
from runtime_config import RT  # noqa: E402

WINDOW = 'scoop motion - click a food position on the WATER'
STAGE_EN = {'홈': 'home', '접근': 'approach', '내리기': 'descend', '쓸기': 'sweep', '세우기': 'tilt', '들어올리기': 'lift',
            '벽접근': 'wall_approach', '벽따라세우기': 'wall_tilt', '벽들어올리기': 'wall_lift', '물속자세': 'tilt_in_water'}
POLICY_KEYS = {ord('0'): 'auto', ord('1'): 'center', ord('2'): 'edge_sweep', ord('3'): 'wall_face'}
WALL_CLEARANCES_MM = tuple(int(v) for v in RT.click_tool.wall_clearance_cycle_mm)
STAGE_BGR = [(255, 230, 150), (255, 190, 60), (255, 120, 0), (220, 60, 170), (150, 40, 230)]   # ① → ⑤ (영상 위에서 잘 보이게)
WHITE, GRAY, GREEN, ORANGE, RED, CYAN = (255, 255, 255), (175, 175, 175), (80, 230, 80), (0, 170, 255), (60, 60, 255), (255, 200, 120)


def project_points(geom, points):
    """base 3D 점들 → 픽셀 (N, 2). 카메라 뒤는 nan."""
    cam = geom.pnp
    pts = np.atleast_2d(np.asarray(points, dtype=float))
    out = np.full((len(pts), 2), np.nan)
    if cam is None or geom.K is None:
        return out
    c = (cam.R @ (pts - cam.position).T).T
    ok = c[:, 2] > 1e-6
    uv = (geom.K @ (c[ok] / c[ok, 2:3]).T).T[:, :2]
    if np.any(geom.D):
        uv = np.array([geom._real(u, v) for u, v in uv]).reshape(-1, 2)
    out[ok] = uv
    return out


class MotionPreview:
    def __init__(self, geom, planner, tp, args, solver=None, loader=None):
        import cv2
        self.geom, self.planner, self.tp, self.args = geom, planner, tp, args
        self.solver, self._loader = solver, loader
        self.policy = 'auto'
        self.wall_mm = int(round(planner.min_clearance_for('벽접근') * 1000))
        self.target = None
        self.plan, self.plan_seconds, self.overlay = None, None, None
        self.planning, self.generation = False, 0
        self.status = 'click a food position on the water'
        self.plan_lock = threading.Lock()
        self.busy = False
        self.stop_event = threading.Event()
        uv = np.asarray(geom.calib.samples_uv, dtype=np.float32)
        self.hull = cv2.convexHull(uv) if len(uv) >= 3 else None
        self.static = self._static_overlay()
        print(f'수면: {planner.surface_source}, 보정 평면 z {geom.calib.surface_z:+.3f} → 클릭 좌표 변환 '
              + (f'PnP 카메라로 수면 z {planner.surface_z:+.3f} 에서 (보정 평면과 {abs(planner.surface_z - geom.calib.surface_z) * 1000:.0f} mm 차이)'
                 if self.use_pnp else '평면 보정 호모그래피'))

    # -- 수면 ↔ 픽셀 -----------------------------------------------------------------

    @property
    def use_pnp(self):
        """수면이 평면 보정 높이와 click_tool.pnp_switch_m 넘게 다르면 호모그래피(보정 평면 전용) 대신 PnP 카메라로 실제 수면 높이에서 계산한다."""
        return (self.geom.pnp is not None
                and abs(self.planner.surface_z - self.geom.calib.surface_z) > float(RT.click_tool.pnp_switch_m))

    def surface_to_pixel(self, x, y):
        if self.use_pnp:
            p = project_points(self.geom, [x, y, self.planner.surface_z])[0]
            return None if np.isnan(p[0]) else (float(p[0]), float(p[1]))
        return self.geom.plane_to_pixel(x, y)

    def pixel_to_surface(self, u, v):
        if self.use_pnp:
            x, y = self.geom.pixel_to_plane_pnp(u, v, self.planner.surface_z)
        else:
            x, y = self.geom.pixel_to_plane(u, v)
        return float(x), float(y)

    # -- 그릴 것 ------------------------------------------------------------------

    def _static_overlay(self):
        g, z, k = self.geom, self.planner, self.planner.kettle
        ax, ay = z.axis_xy
        t = np.linspace(0.0, 2 * np.pi, 181)
        rc = float(z.cfg['zones']['center_radius_m'])

        def ring(r):
            return [self.surface_to_pixel(ax + r * math.cos(a), ay + r * math.sin(a)) for a in t]

        bounds = [[self.surface_to_pixel(ax + r * math.cos(math.radians(d)), ay + r * math.sin(math.radians(d)))
                   for r in np.linspace(rc, k.surface_radius, 12)] for d in (0, 90, 180, 270)]
        rim = project_points(g, np.c_[ax + float(k.rim_top[0]) * np.cos(t), ay + float(k.rim_top[0]) * np.sin(t),
                                      np.full_like(t, z.rim_top_z)])
        labels = []
        for d in z.cfg['zones']['edge_centers_deg']:
            a = math.radians(float(d))
            r_label = 0.5 * (rc + k.surface_radius)
            labels.append((f'edge_{int(d)}', self.surface_to_pixel(ax + r_label * math.cos(a), ay + r_label * math.sin(a))))
        return {'surface': ring(k.surface_radius), 'center': ring(rc), 'bounds': bounds,
                'rim': [None if np.isnan(p[0]) else tuple(p) for p in rim], 'axis': self.surface_to_pixel(ax, ay), 'labels': labels}

    def _plan_overlay(self, plan):
        import cv2
        from zone_motion_check import SWEEP_STAGES, key_stages
        if plan is None or plan.check is None or not plan.waypoints:
            return None
        z, g = self.planner, self.geom
        path = project_points(g, np.array([p for st, p, _ in plan.samples if st != HOME]))
        cap = z.body.parts == ScoopBody.CAP
        hulls = []
        for (name, w), color in zip(key_stages(plan), STAGE_BGR):
            px = project_points(g, z.body.points_base(w.position, w.R)[cap][::3])
            px = px[~np.isnan(px[:, 0])]
            hull = cv2.convexHull(px.astype(np.float32)) if len(px) >= 3 else None
            hulls.append((name, hull, project_points(g, w.position)[0], color))
        mouth = [self.surface_to_pixel(x, y) for x, y in z.mouth_waterline_xy(plan.samples, stages=SWEEP_STAGES)[::4]]
        band = None
        if plan.params.get('capture_band_m'):
            lo, hi = plan.params['capture_band_m']
            a = math.radians(plan.params['heading_deg'])
            band = [self.surface_to_pixel(z.axis_xy[0] + r * math.cos(a), z.axis_xy[1] + r * math.sin(a)) for r in (lo, hi)]
        return {'path': [None if np.isnan(p[0]) else tuple(p) for p in path], 'hulls': hulls, 'mouth': mouth, 'band': band}

    def draw(self, frame, frozen=False):
        import cv2
        img = frame.copy()
        s = self.static
        if self.hull is not None:
            cv2.polylines(img, [self.hull.astype(np.int32)], True, (150, 150, 150), 1, cv2.LINE_AA)
        draw_polyline(img, s['surface'], (230, 230, 230), 1)
        draw_polyline(img, s['center'], (200, 200, 200), 1, dashed=True)
        for b in s['bounds']:
            draw_polyline(img, b, (200, 200, 200), 1, dashed=True)
        draw_polyline(img, s['rim'], ORANGE, 1, dashed=True)
        if s['axis'] is not None:
            cv2.drawMarker(img, tuple(int(round(v)) for v in s['axis']), WHITE, cv2.MARKER_CROSS, 10, 1)
        for text, p in s['labels']:
            if p is not None:
                put_text(img, text, (int(p[0]) - 25, int(p[1])), (210, 210, 210), 0.38)

        o = self.overlay
        if o is not None:
            for p in o['mouth']:
                if p is not None:
                    cv2.circle(img, (int(round(p[0])), int(round(p[1]))), 1, ORANGE, -1)
            if o['band'] and all(p is not None for p in o['band']):
                a, b = o['band']
                cv2.line(img, (int(a[0]), int(a[1])), (int(b[0]), int(b[1])), ORANGE, 4, cv2.LINE_AA)
            for i, (name, hull, marker, color) in enumerate(o['hulls']):
                if hull is not None:
                    cv2.polylines(img, [hull.astype(np.int32)], True, color, 2, cv2.LINE_AA)
                if not np.isnan(marker[0]):
                    cv2.circle(img, (int(round(marker[0])), int(round(marker[1]))), 4, color, -1, cv2.LINE_AA)
                    put_text(img, str(i + 1), (int(marker[0]) + 6, int(marker[1]) - 4), color, 0.5)   # 영상 글꼴은 ASCII 만
            draw_polyline(img, o['path'], WHITE, 1)
        if self.target is not None:
            u, v = self.target['uv']
            cv2.drawMarker(img, (int(round(u)), int(round(v))), RED, cv2.MARKER_TILTED_CROSS, 16, 2)
        return self._with_panel(img, frozen)

    def _with_panel(self, img, frozen):
        import cv2
        rows = [('SCOOP MOTION PREVIEW', WHITE), ('click a food position on the WATER', GRAY),
                (f'policy [{self.policy}]   wall stages {self.wall_mm} mm' + ('   [FROZEN]' if frozen else ''), WHITE),
                (f'water z {self.planner.surface_z:+.3f}  ({"PnP" if self.use_pnp else "homography"})   '
                 f'depth {float(self.planner.cfg["motion"]["marker_depth_m"]) * 1000:.0f} mm', WHITE), ('', WHITE)]
        t = self.target
        if t is not None:
            rows += [(f'target  x {t["xy"][0]:+.3f}  y {t["xy"][1]:+.3f} m', WHITE),
                     (f'        r {t["r"] * 100:.1f} cm   az {t["az"]:.0f} deg   {t["zone"] or "outside"}', WHITE)]
            if t['extrapolated']:
                rows.append(('  outside calibrated area: +-cm error', ORANGE))
        if self.planning:
            rows.append(('planning ...', CYAN))
        elif self.plan is not None:
            p = self.plan
            rows.append((f'{p.policy}: {"OK" if p.ok else "FAIL"}   offset {p.mouth_offset_m * 100:.1f} cm   '
                         f'{self.plan_seconds:.1f} s', GREEN if p.ok else ORANGE))
            if p.check is not None:
                c = p.check
                rows += [(f'  clearance {c.clearance.clearance_m * 1000:.0f} mm @ {STAGE_EN.get(c.clearance_stage, "?")}', WHITE),
                         (f'  reach {c.reach_m:.2f} m   slow {sum(c.segment_slow)}/{len(c.segment_slow)}', WHITE)]
                if p.params.get('gamma_deg') is not None:
                    rows.append((f'  mouth {p.params["gamma_deg"]:.0f} deg  depth {p.params["depth_m"] * 100:+.0f} cm', WHITE))
                if p.params.get('capture_band_m'):
                    lo, hi = p.params['capture_band_m']
                    rows.append((f'  covers r {lo * 100:.1f}~{hi * 100:.1f} cm (orange bar)', ORANGE))
            if not p.ok:
                rows.append(('  reason: see terminal', ORANGE))
        rows += [('', WHITE), ('stages: 1 descend 2 mid 3 end 4 tilt 5 lift', GRAY), ('white = marker path', GRAY), ('', WHITE),
                 (f'status: {self.status}', CYAN if not self.busy else ORANGE), ('', WHITE), ('KEYS', GRAY)]
        rows += [(k, GRAY) for k in ('L-click plan   c clear   f freeze', '0 auto 1 center 2 sweep 3 wall',
                                     'w wall-stage clearance 35/25/15',
                                     'a AIR demo (' + ('auto height' if self.args.air == 'auto' else f'+{self.args.air * 100:.0f} cm')
                                     + ')   g REAL run',
                                     'h home   SPACE STOP', 's save png   q quit', '(a g h: confirm yes in terminal)')]
        h, w = img.shape[:2]
        canvas = np.full((max(h, 16 + 16 * len(rows)), w + PANEL_WIDTH, 3), 32, dtype=np.uint8)
        canvas[:h, :w] = img
        for i, (text, color) in enumerate(rows):
            cv2.putText(canvas, text, (w + 10, 20 + i * 16), cv2.FONT_HERSHEY_SIMPLEX, 0.42, color, 1, cv2.LINE_AA)
        return canvas

    # -- 계획 ---------------------------------------------------------------------

    def click(self, u, v, plan=True):
        import cv2
        if self.busy:
            self.status = 'robot action running - click ignored'
            return
        x, y = self.pixel_to_surface(u, v)
        d = np.array([x, y]) - self.planner.axis_xy
        extrapolated = self.hull is not None and cv2.pointPolygonTest(self.hull, (float(u), float(v)), False) < 0
        self.target = {'uv': (float(u), float(v)), 'xy': np.array([x, y]), 'r': float(np.hypot(*d)),
                       'az': math.degrees(math.atan2(d[1], d[0])), 'zone': self.planner.zone_of_xy(x, y),
                       'extrapolated': bool(extrapolated)}
        if plan:
            self.replan()

    def replan(self, wait=False):
        if self.target is None:
            return
        self.generation += 1
        gen, target, policy, wall = self.generation, self.target, self.policy, self.wall_mm
        self.planning, self.plan, self.overlay = True, None, None
        self.status = 'planning'

        def work():
            with self.plan_lock:
                self.planner.stage_min_clearance.update({s: wall / 1000.0 for s in WALL_STAGES})
                t0 = time.monotonic()
                plan = self.tp.plan(*target['xy']) if policy == 'auto' else self.tp.plan_policy(policy, *target['xy'])
                seconds = time.monotonic() - t0
                overlay = self._plan_overlay(plan)
            if gen != self.generation:
                return
            self.plan, self.plan_seconds, self.overlay, self.planning = plan, seconds, overlay, False
            self.status = 'ready' if plan.ok else 'plan failed (terminal)'
            print(f'\n[클릭] base ({target["xy"][0]:+.4f}, {target["xy"][1]:+.4f}) · 반경 {target["r"] * 100:.1f} cm · '
                  f'방위 {target["az"]:.0f}° · 구역 {target["zone"]} · 정책 {policy} · 벽 쪽 여유 {wall} mm'
                  + (' · 보정점 영역 밖 (좌표 수 cm 오차 가능)' if target['extrapolated'] else ''))
            print(f'  → {plan.label}: {"OK" if plan.ok else "실패"}  비껴감 {plan.mouth_offset_m * 100:.1f} cm  ({seconds:.1f} s)  {plan.reason}')
            if plan.check is not None:
                print('  단계별 최소 여유 [mm]: ' + ', '.join(f'{s} {v * 1000:.0f}' for s, v in plan.check.stage_min.items()))

        if wait:
            work()
        else:
            threading.Thread(target=work, daemon=True).start()

    # -- 로봇 ---------------------------------------------------------------------

    def start_action(self, kind):
        if self.busy:
            self.status = 'already running'
            return
        if kind in ('air', 'real') and (self.plan is None or self.planning or not self.plan.waypoints):
            self.status = 'no plan yet - click first'
            return
        self.busy = True
        self.stop_event.clear()
        threading.Thread(target=self._action, args=(kind,), daemon=True).start()

    def _action(self, kind):
        try:
            if kind == 'home':
                self.status = 'home: answer in terminal'
                if runner.confirmed(input('\n홈 복귀 (move_home_safe.py --go) 하려면 yes 입력: ')):
                    self.status = 'moving home'
                    subprocess.run([sys.executable, str(HERE / 'move_home_safe.py'), '--go'], check=False)
                    self.status = 'home done (see terminal)'
                else:
                    self.status = 'home canceled'
                return
            plan, target = self.plan, self.target
            air = self.args.air if kind == 'air' else 0.0
            self.status = 'checking'
            with self.plan_lock:
                self.planner.stage_min_clearance.update({s: self.wall_mm / 1000.0 for s in WALL_STAGES})
                info = runner.prepare(self.planner, plan, air, self.args.speed_scale, self.solver, read_robot=True,
                                      smooth=not self.args.no_smooth)
            where = f'실제보다 {info["air"] * 100:.0f} cm 위 공중 시연' if not info['real'] else '실제 높이 실행 (스쿱이 국물에 들어감)'
            print(f'\n===== {where}: {plan.label} (반경 {target["r"] * 100:.1f} cm · 방위 {target["az"]:.0f}°) =====')
            for row in runner.moves_table(info['moves']):
                print('   ' + row)
            for line in info['lines']:
                print('  ' + line)
            if info['problems']:
                print('중단 조건:')
                for p in info['problems']:
                    print('  - ' + p)
                self.status = 'checks failed (terminal)'
                return
            if info['real']:
                print(f'확인: 수면이 계획 수위 ({self.planner.surface_source}) · 솥이 측정 때 자리 그대로 · 비상정지 버튼이 손 닿는 곳에 있는지')
            self.status = 'confirm in terminal'
            if not runner.confirmed(input('움직이려면 yes 입력 (창에서 SPACE = 정지): ')):
                self.status = 'canceled'
                print('취소했습니다.')
                return
            self.status = 'RUNNING - SPACE to stop'
            started = dt.datetime.now()
            record = {}
            result, final_tcp = runner.execute(info['moves'], False, self.planner.home.position, self.stop_event,
                                               accel=info['accel'], record=record)
            err = float(np.linalg.norm(np.asarray(final_tcp[:3]) - info['moves'][-1][1])) * 1000
            info['metrics'] = runner.motion_metrics(record.get('rows', []), info['samples'])
            print(f'결과: {result}. 마지막 TCP {np.round(final_tcp, 4).tolist()} (계획 끝과 {err:.1f} mm)')
            print(runner.metrics_line(info['metrics']) + (f' (RTSI 오류: {record["error"]})' if record.get('error') else ''))
            log = runner.write_log({'started': started, 'name': f'click_{plan.policy}', 'title': plan.label,
                                    'target_base_xy': [float(v) for v in target['xy']],
                                    'target_polar_cm_deg': [round(target['r'] * 100, 1), round(target['az'], 1)],
                                    'pixel_uv': list(target['uv']), 'policy': self.policy,
                                    'wall_clearance_mm': self.wall_mm, 'smooth': not self.args.no_smooth},
                                   plan, info, result, final_tcp, record)
            print(f'기록: {log.relative_to(HERE)}')
            self.status = 'done - press h for home' if result == '완료' else 'STOPPED (terminal)'
        except Exception as exc:                                   # 창은 계속 살아 있게
            print(f'오류: {exc}')
            self.status = 'error (terminal)'
        finally:
            self.busy = False

    def stop(self):
        self.stop_event.set()
        try:
            runner.send_stop()
            self.status = 'STOP sent'
            print('\n정지 신호(stopl)를 보냈습니다.')
        except Exception as exc:
            print(f'정지 신호 실패: {exc}')

    def save(self, frame):
        import cv2
        from zone_motion_check import SWEEP_STAGES, coverage_cells, dilate, draw_motion, setup_matplotlib
        stamp = dt.datetime.now().strftime('%Y%m%d_%H%M%S')
        out = HERE / f'click_preview_{stamp}.png'
        cv2.imwrite(str(out), self.draw(frame))
        names = [out.name]
        if self.plan is not None and self.plan.check is not None:
            plt, _font = setup_matplotlib()
            cells = dilate(coverage_cells(self.planner.mouth_waterline_xy(self.plan.samples, stages=SWEEP_STAGES)))
            fig = HERE / f'click_plan_{stamp}.png'
            draw_motion(plt, self.planner, self.plan, cells, fig, target_xy=self.target['xy'])
            names.append(fig.name)
        self.status = 'saved ' + ', '.join(names)
        print('저장: ' + ', '.join(names))


# -- 창 · 입력 -------------------------------------------------------------------

def run_window(get_tool, next_frame, spin=None):
    import cv2
    cv2.namedWindow(WINDOW, cv2.WINDOW_NORMAL)
    cv2.resizeWindow(WINDOW, int((640 + PANEL_WIDTH) * 1.6), int(480 * 1.6))
    holder = {'tool': None, 'frozen': None, 'width': None}

    def on_mouse(event, x, y, flags, param):
        tool = holder['tool']
        if tool is None or holder['width'] is None or x >= holder['width']:
            return
        if event == cv2.EVENT_LBUTTONDOWN:
            tool.click(x, y)
    cv2.setMouseCallback(WINDOW, on_mouse)

    while True:
        if spin is not None:
            spin()
        holder['tool'] = holder['tool'] or get_tool()
        tool = holder['tool']
        frame = holder['frozen'] if holder['frozen'] is not None else next_frame()
        holder['width'] = None if frame is None else frame.shape[1]
        if tool is None or frame is None:
            blank = np.zeros((480, 640, 3), dtype=np.uint8)
            put_text(blank, 'waiting for camera image and camera_info ...', (20, 240))
            cv2.imshow(WINDOW, blank)
        else:
            cv2.imshow(WINDOW, tool.draw(frame, holder['frozen'] is not None))
        key = cv2.waitKey(15) & 0xFF
        if key == 32 and tool is not None:                          # SPACE = 정지 (다른 키보다 먼저)
            tool.stop()
            continue
        if key in (ord('q'), 27):
            if tool is not None and tool.busy:
                tool.stop()
            break
        if cv2.getWindowProperty(WINDOW, cv2.WND_PROP_VISIBLE) < 1:
            break
        if tool is None or key == 255:
            continue
        if key in POLICY_KEYS:
            tool.policy = POLICY_KEYS[key]
            tool.replan()
        elif key == ord('w'):
            i = WALL_CLEARANCES_MM.index(tool.wall_mm) if tool.wall_mm in WALL_CLEARANCES_MM else -1
            tool.wall_mm = WALL_CLEARANCES_MM[(i + 1) % len(WALL_CLEARANCES_MM)]
            tool.replan()
        elif key == ord('c'):
            tool.generation += 1
            tool.target, tool.plan, tool.overlay, tool.planning = None, None, None, False
            tool.status = 'cleared'
        elif key == ord('f'):
            holder['frozen'] = None if holder['frozen'] is not None else (None if frame is None else frame.copy())
        elif key == ord('a'):
            tool.start_action('air')
        elif key == ord('g'):
            tool.start_action('real')
        elif key == ord('h'):
            tool.start_action('home')
        elif key == ord('s') and frame is not None:
            tool.save(frame)
    cv2.destroyAllWindows()
    return holder['tool']


def make_tool(calib, K, D, args, with_solver=True, water_surface_z='current'):
    planner = ZoneMotionPlanner.from_yaml(water_surface_z=water_surface_z)
    tp = TargetPolicyPlanner(planner, planner.cfg)
    solver, loader = runner.load_solver() if with_solver else (None, None)
    if solver is not None:
        from arm_clearance import make_path_check
        tp.path_check = make_path_check(planner, solver)      # 팔 링크가 솥에 닿는 후보는 계획 단계에서 거른다
    return MotionPreview(CameraGeometry(calib, K, D), planner, tp, args, solver, loader)


def run_ros(args, calib):
    import rclpy
    from cv_bridge import CvBridge
    from rclpy.node import Node
    from rclpy.qos import qos_profile_sensor_data
    from sensor_msgs.msg import CameraInfo, Image

    class CameraFeed(Node):
        def __init__(self):
            super().__init__('click_target_motion')
            self.bridge = CvBridge()
            self.frame = None
            self.K = self.D = self.size = None
            self.create_subscription(Image, args.image_topic, self._on_image, qos_profile_sensor_data)
            self.create_subscription(CameraInfo, args.info_topic, self._on_info, 10)

        def _on_image(self, msg):
            self.frame = self.bridge.imgmsg_to_cv2(msg, desired_encoding='bgr8')

        def _on_info(self, msg):
            if self.K is None:
                self.K = np.array(msg.k, dtype=float).reshape(3, 3)
                self.D = np.array(msg.d, dtype=float)
                self.size = (msg.width, msg.height)

    rclpy.init()
    feed = CameraFeed()
    box = {}

    def get_tool():
        if 'tool' not in box and feed.K is not None:
            if feed.size != (640, 480):
                print(f'! camera_info 해상도 {feed.size} 가 보정 때(640x480)와 다릅니다. 좌표가 틀어집니다.')
            box['tool'] = make_tool(calib, feed.K, feed.D, args, water_surface_z=args.water_z)
            print('준비됨: 창에서 음식 자리를 클릭하세요.')
        return box.get('tool')

    try:
        run_window(get_tool, lambda: feed.frame, lambda: rclpy.spin_once(feed, timeout_sec=0.0))
    except KeyboardInterrupt:                        # Ctrl+C 로 끌 때 긴 오류 대신 조용히 끝낸다
        tool = box.get('tool')
        if tool is not None and tool.busy:
            tool.stop()
        print('\n종료합니다.')
    finally:
        feed.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


def saved_K():
    if not MEASUREMENT_YAML.exists():
        return None
    K = yaml.safe_load(MEASUREMENT_YAML.read_text(encoding='utf-8'))['camera']['K']
    return None if K is None else np.array(K, dtype=float).reshape(3, 3)


def self_test(calib, args):
    """카메라 · 로봇 없이: 로봇 좌표 → 픽셀 → 클릭 → 같은 로봇 좌표, 계획 · 겹쳐 그리기가 되는지."""
    import cv2
    K = saved_K()
    if K is None:
        print('kettle_axis_measurement.yaml 의 카메라 K 가 없어 건너뜁니다.')
        return 0
    tool = make_tool(calib, K, np.zeros(5), args, with_solver=False, water_surface_z=None)   # 계획 확인은 설계 수위 100 L
    ok = True
    for r, az in ((0.0, 0.0), (0.25, 0.0), (0.40, 225.0)):
        xy = tool.planner.axis_xy + r * np.array([math.cos(math.radians(az)), math.sin(math.radians(az))])
        uv = tool.surface_to_pixel(*xy)
        tool.click(*uv, plan=False)
        tool.replan(wait=True)
        back = float(np.linalg.norm(tool.target['xy'] - xy)) * 1000
        img = tool.draw(np.zeros((480, 640, 3), dtype=np.uint8))
        drawn = tool.overlay is not None and any(h[1] is not None for h in tool.overlay['hulls'])
        good = back < 0.5 and tool.plan is not None and tool.plan.ok and drawn and img.shape[1] == 640 + PANEL_WIDTH
        ok &= good
        print(f'  [{"OK" if good else "FAIL"}] 반경 {r * 100:.0f} cm 방위 {az:.0f}°: 픽셀 ({uv[0]:.0f}, {uv[1]:.0f}) → '
              f'되돌린 좌표 오차 {back:.2f} mm, 정책 {tool.plan.label if tool.plan else "-"} '
              f'{"OK" if tool.plan and tool.plan.ok else "실패"}, 스쿱 윤곽 그림 {drawn}')
        if args.out:
            cv2.imwrite(args.out.replace('.png', f'_r{r * 100:.0f}_az{az:.0f}.png'), img)
    measured = make_tool(calib, K, np.zeros(5), args, with_solver=False)       # 설정의 실측 수면으로 좌표 변환만 확인
    if measured.use_pnp:
        xy = measured.planner.axis_xy + np.array([0.20, -0.10])
        back = float(np.linalg.norm(np.array(measured.pixel_to_surface(*measured.surface_to_pixel(*xy))) - xy)) * 1000
        good = back < 0.5
        ok &= good
        print(f'  [{"OK" if good else "FAIL"}] 실측 수면 z {measured.planner.surface_z:+.3f} (PnP): 좌표 → 픽셀 → 좌표 오차 {back:.2f} mm')
    return 0 if ok else 1


def main():
    parser = argparse.ArgumentParser(description='카메라 클릭 → 스쿱 모션 계획 · 겹쳐 보기 · 시연.')
    tool_cfg = RT.click_tool
    parser.add_argument('--air', type=runner.parse_air, default=str(tool_cfg.air), metavar='M|auto',
                        help='공중 시연 높이 (a 키): auto = 스쿱이 물에 닿지 않는 가장 낮은 높이, 숫자 = 그만큼 위 [m]')
    parser.add_argument('--speed-scale', type=float, default=float(tool_cfg.speed_scale), help='속도 배율 (0 < s ≤ 1)')
    parser.add_argument('--no-smooth', action='store_true', help='블렌드 없이 경유점마다 멈춤 (비교용)')
    parser.add_argument('--water-z', type=parse_water_surface_z, default='current', metavar='Z|design',
                        help='수면 z [m] (이 실행에서만). 기본 = water_level.yaml, design = 설계 수위 100 L')
    parser.add_argument('--image', metavar='PNG', help='(오프라인) 저장된 영상')
    parser.add_argument('--click', nargs=2, type=float, metavar=('U', 'V'), help='(오프라인) 이 픽셀을 클릭한 것으로')
    parser.add_argument('--policy', default='auto', choices=['auto', 'center', 'edge_sweep', 'wall_face'])
    parser.add_argument('--no-window', action='store_true', help='--image 와 함께: 창 없이 --out 으로 저장')
    parser.add_argument('--out', metavar='PNG')
    parser.add_argument('--self-test', action='store_true')
    parser.add_argument('--image-topic', default=tool_cfg.image_topic)
    parser.add_argument('--info-topic', default=tool_cfg.info_topic)
    args = parser.parse_args()
    if not 0.0 < args.speed_scale <= 1.0:
        parser.error('--speed-scale 은 0 초과 1 이하')

    calib = PlaneCalibration.load()
    if args.self_test:
        return self_test(calib, args)
    if args.image:
        import cv2
        frame = cv2.imread(args.image)
        if frame is None:
            raise SystemExit(f'영상을 읽지 못했습니다: {args.image}')
        tool = make_tool(calib, saved_K(), None, args, with_solver=not args.no_window, water_surface_z=args.water_z)
        tool.policy = args.policy
        if args.click:
            tool.click(*args.click, plan=False)
            tool.replan(wait=True)
        if args.no_window:
            out = args.out or 'click_preview.png'
            cv2.imwrite(out, tool.draw(frame))
            print(f'저장: {out}')
        else:
            run_window(lambda: tool, lambda: frame)
        return 0
    run_ros(args, calib)
    return 0


if __name__ == '__main__':
    sys.exit(main())
