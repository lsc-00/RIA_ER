#!/usr/bin/env python3
"""
좌표 입력 정책: 카메라로 찾은 음식 좌표 하나를 받아, 그 음식을 담도록 스쿱 모션을 만든다 (jb/2026-09-15.md 3.2).

    from ria_kettle.target_policy import TargetPolicyPlanner
    tp = TargetPolicyPlanner.from_yaml()
    plan = tp.plan(x, y)        # TargetPlan: policy, ok, reason, mouth_offset_m, waypoints, check, params
    tp.moves(plan)              # [(movel 목표 [x, y, z, rx, ry, rz], 속도 m/s), ...]  벽 근처 구간은 느린 속도

    python3 -m ria_kettle.target_policy                     표본 좌표로 정책 · 결과 표
    python3 -m ria_kettle.target_policy --wall-clearance 15 벽 마주 보기의 벽 쪽 단계 여유만 15 mm 로 바꿔 비교

정책 (설정: zone_motion.yaml 의 policy · wall 절)
  center     가운데 구역 (솥 축 30 cm 이내): 곧게 쓸기. 입구 중심이 목표를 지나도록, 목표 pre_m 앞에서 시작해 post_m 지나칠 때까지.
             쓸기 방향은 center_headings_deg 순서(로봇 쪽 180° 먼저), 입구 중심을 옆으로 비껴 보는 값은 lateral_offsets_m 순서.
  edge_sweep 가장자리, 벽에서 떨어진 음식: 대각선 구역 전체를 벽 따라 호로 훑는다 (구역 먼 끝 → 로봇 쪽 끝).
             입구 중심이 목표 반경을 지나는 호를 먼저 보고, 안 되면 경로 규칙을 지키는 가장 바깥 호.
             스쿱 옆면(폭 38.5 cm)이 수면 아래 벽에 걸려 호 반경은 약 22 cm 가 한계 → 입구 중심은 목표보다 안쪽을 지나고,
             그 차이(비껴감)가 edge_sweep_max_offset_m 이하(입구 선 안에 음식이 들어오는 범위)일 때만 이 정책.
  wall_face  가장자리, 벽에 붙은 음식: 손목을 돌려 입구가 목표 방위의 벽을 마주 보게 한다.
             접근 → 경로 규칙을 지키는 가장 바깥에서 내리기 → 벽 쪽 수평 접근(벽접근, 느리게) →
             벽 원호 중심 둘레로 돌려 올리며 세우기(벽따라세우기, 벽 쪽 점의 간격이 그대로) → 수직으로 들어 올리기.
             입구 각도 · 깊이는 wall.gammas_deg × wall.depths_m 중에서, 수평 접근 끝에 '물에 잠긴 입구가 덮는 수면' 이
             목표를 덮는(또는 가장 가까운) 조합을 고른다. 벽 쪽 두 단계의 최소 여유는 motion.stage_min_clearance_m 로 따로 줄 수 있다.
  가운데 목표가 center 로 안 되면 가장 가까운 대각선 구역의 edge_sweep → wall_face 순으로 시도한다.
  모든 경로는 ZoneMotionPlanner.check_path 의 경로 규칙(단계별 여유 · 벽 쪽 다가감 · 팔 닿는 거리)을 통과해야 ok.

입구 중심 · 덮는 수면
  입구 중심: 쓸 때 망 입구 면이 수면을 지나는 선의 가운데. 표식보다 입구 방향(수평)으로 f 앞 (mouth_geometry).
             입구 50° · 표식 수면 아래 5 cm 에서 f = 9.6 cm, 선 반폭 18.8 cm.
  덮는 수면: 테두리 원판 중 수면 아래에 잠긴 부분을 수면에 비춘 자리 (capture_band). 들어 올릴 때 이 위에 있는 음식이 담긴다.
"""

import argparse
import math
import sys
import time
from dataclasses import dataclass, field

import numpy as np

sys.dont_write_bytecode = True

try:                                   # ROS 패키지로 설치된 경우
    from .scoop_body import rotation_about
    from .zone_motion import CENTER, Waypoint, ZoneMotionPlanner, matrix_to_rpy, wrap_deg
except ImportError:                    # 소스 폴더에서 스크립트로 실행하는 경우
    from scoop_body import rotation_about
    from zone_motion import CENTER, Waypoint, ZoneMotionPlanner, matrix_to_rpy, wrap_deg

POLICY_LABELS = {'center': '가운데 곧게 쓸기', 'edge_sweep': '대각선 훑기', 'wall_face': '벽 마주 보기', 'none': '정책 없음'}
WALL_STAGES = ('벽접근', '벽따라세우기', '벽들어올리기')   # 벽 마주 보기에서 벽 가까이 있는 단계 (따로 여유 기준을 줄 수 있음)


def mouth_geometry(scoop, gamma_deg, depth_m):
    """입구 γ, 표식 깊이일 때 입구 면이 수면을 지나는 선: (표식보다 앞선 수평 거리 f, 선 반폭). 선이 없으면 None.

    단면(입구 방향 수평 · 위)에서 테두리 중심 = 깊이 · (cos γ, sin γ), 입구 면의 기울어진 방향 = (sin γ, −cos γ).
    수면(표식 기준 +depth)과 만나는 곳까지 입구 면을 따라 s 만큼: s = (깊이 · sin γ − depth) / cos γ.
    """
    g = math.radians(gamma_deg)
    s = (scoop.depth_m * math.sin(g) - depth_m) / math.cos(g)
    a = scoop.rim_radius_m
    if abs(s) >= a:
        return None
    return scoop.depth_m * math.cos(g) + s * math.sin(g), math.sqrt(a * a - s * s)


@dataclass
class TargetPlan:
    target_xy: np.ndarray
    zone: object
    policy: str
    ok: bool
    reason: str
    mouth_offset_m: float = math.nan   # 입구 중심(또는 덮는 수면)이 목표에서 비껴간 거리
    waypoints: list = field(default_factory=list)
    check: object = None               # zone_motion.PathCheck
    params: dict = field(default_factory=dict)

    @property
    def label(self):
        return POLICY_LABELS.get(self.policy, self.policy)

    # zone_motion_check 그림 함수와 같은 이름의 속성
    @property
    def samples(self):
        return self.check.samples if self.check else []

    @property
    def clearance(self):
        return self.check.clearance

    @property
    def clearance_stage(self):
        return self.check.clearance_stage

    @property
    def reach_m(self):
        return self.check.reach_m

    @property
    def segment_slow(self):
        return self.check.segment_slow if self.check else []


class TargetPolicyPlanner:
    def __init__(self, zones: ZoneMotionPlanner, config: dict):
        self.z = zones
        p, w, m, precision = config['policy'], config['wall'], config['motion'], config['precision']
        self.gamma_s, self.depth = float(m['sweep_gamma_deg']), float(m['marker_depth_m'])
        mouth = mouth_geometry(zones.scoop, self.gamma_s, self.depth)
        if mouth is None:
            raise ValueError('쓸기 자세에서 입구 면이 수면을 지나지 않습니다 (sweep_gamma_deg · marker_depth_m 확인).')
        self.mouth_f, self.mouth_half = mouth
        self.pre, self.post = float(p['pre_m']), float(p['post_m'])
        self.min_pre, self.min_post = float(p['min_pre_m']), float(p['min_post_m'])
        self.headings = [float(v) for v in p['center_headings_deg']]
        self.laterals = [float(v) for v in p['lateral_offsets_m']]
        self.edge_max_offset = float(p['edge_sweep_max_offset_m'])
        self.wall_max_offset = float(p['wall_face_max_offset_m'])
        self.wall_gammas = [float(v) for v in w['gammas_deg']]
        self.wall_depths = [float(v) for v in w['depths_m']]
        self.wall_tilt = float(w['tilt_deg'])
        self.wall_step = float(w['tilt_step_deg'])
        self.capture_lateral = float(w['capture_lateral_m'])
        self.wall_entry_mode = str(w['entry_mode'])
        self.speed, self.slow_speed = zones.speed_m_s, zones.near_wall_speed_m_s
        self.wall_tol = float(precision['wall_search_tol_m'])
        self.sweep_min_radius = float(precision['sweep_min_radius_m'])
        # 선택: 경로 샘플 → (통과, 이유). 로봇 도구(jb/mesh arm_clearance.make_path_check)가 역기구학 · 팔 링크 ↔ 솥 검사를 넣는다.
        # 넣으면 그 검사에 걸리는 후보는 계획 단계에서 버리고 다음 후보를 고른다.
        self.path_check = None
        # 테두리 원판 (도구 좌표). 입구 방향이 도구 y-z 평면 안이라 도구 x 축이 원판 위에 있다.
        s, d = zones.scoop, zones.opening_tool
        u, v = np.array([1.0, 0.0, 0.0]), np.cross(zones.opening_tool, [1.0, 0.0, 0.0])
        g = np.arange(-s.rim_radius_m, s.rim_radius_m + 1e-9, float(precision['capture_grid_m']))
        gu, gv = np.meshgrid(g, g)
        inside = gu ** 2 + gv ** 2 <= s.rim_radius_m ** 2
        self._rim_disk_tool = s.depth_m * d + gu[inside][:, None] * u + gv[inside][:, None] * v

    @classmethod
    def from_yaml(cls, profile=None, scoop=None, zones=None, water_surface_z='current'):
        """water_surface_z: 'current' = water_level.yaml 의 지금 수면, None = 설계 수위 100 L, 숫자 = 그 z."""
        planner = ZoneMotionPlanner.from_yaml(profile, scoop, zones, water_surface_z)
        return cls(planner, planner.cfg)

    # -- 공통 -----------------------------------------------------------------

    def _polar(self, target):
        d = np.asarray(target, dtype=float) - self.z.axis_xy
        return float(np.hypot(*d)), math.degrees(math.atan2(d[1], d[0]))

    def edge_zone_of(self, target):
        phi = self._polar(target)[1]
        best = min(self.z.cfg['zones']['edge_centers_deg'], key=lambda c: abs(wrap_deg(phi - c)))
        return f'edge_{int(best)}'

    def capture_band(self, position, R, heading_deg):
        """물에 잠긴 테두리 원판을 수면에 비춘 자리 중, 방위 heading 선(옆 ±capture_lateral) 위의 솥 축 기준 반경 범위. 없으면 None."""
        pts = np.asarray(position, dtype=float) + self._rim_disk_tool @ R.T
        a = math.radians(heading_deg)
        e, n = np.array([math.cos(a), math.sin(a)]), np.array([-math.sin(a), math.cos(a)])
        rel = pts[:, :2] - self.z.axis_xy
        sel = (pts[:, 2] < self.z.surface_z) & (np.abs(rel @ n) < self.capture_lateral)
        if not sel.any():
            return None
        along = rel[sel] @ e
        return float(along.min()), float(along.max())

    def _coarse_ok(self, waypoints):
        return self.z.feasible(self.z.check_path(waypoints, self.z.coarse_body))

    def _why(self, check):
        z = self.z
        if check.closing:
            _, stage, part, d, drop = check.closing[0]
            return f'{stage} 중 {part} 가 벽 쪽으로 {drop * 1000:.0f} mm 다가감 (여유 {d * 1000:.0f} mm)'
        violation = z.clearance_violation(check)
        if violation:
            stage, value, need = violation
            return f'{stage} 중 여유 {value * 1000:.0f} mm < {need * 1000:.0f} mm'
        if check.reach_m > z.max_reach:
            return f'팔이 닿지 않음 (어깨 ↔ 손목 {check.reach_m:.3f} m > {z.max_reach:.2f} m)'
        return ''

    def _finish(self, target, zone, policy, waypoints, offset, params):
        check = self.z.check_path(waypoints)
        ok = self.z.feasible(check)
        reason = '' if ok else self._why(check)
        if ok and self.path_check is not None:
            ok, reason = self.path_check(check.samples)
            params = {**params, 'arm_ok': bool(ok)}
        return TargetPlan(np.asarray(target, dtype=float), zone, policy, ok, reason,
                          float(offset), waypoints, check, params)

    # -- 가운데: 곧게 쓸기 --------------------------------------------------------

    def center_waypoints(self, target, heading_deg, lateral_m, pre_m, post_m, body=None):
        a = math.radians(heading_deg)
        u, n = np.array([math.cos(a), math.sin(a)]), np.array([-math.sin(a), math.cos(a)])
        at = np.asarray(target, dtype=float) + lateral_m * n - self.mouth_f * u   # 입구 중심이 목표 옆을 지날 때의 표식
        return self.z._enter_sweep_exit([(at - pre_m * u, heading_deg), (at + post_m * u, heading_deg)], heading_deg, body)

    def _center_for_heading(self, target, zone, heading):
        """한 방향에서 옆 비낌 · 길이 순서대로 규칙을 지키는 첫 계획, 없으면 None."""
        lengths = [(self.pre, self.post), (0.5 * (self.pre + self.min_pre), 0.5 * (self.post + self.min_post)),
                   (self.min_pre, self.min_post)]
        for lateral in self.laterals:
            for pre, post in lengths:
                if not self._coarse_ok(self.center_waypoints(target, heading, lateral, pre, post, self.z.coarse_body)):
                    continue
                plan = self._finish(target, zone, 'center', self.center_waypoints(target, heading, lateral, pre, post),
                                    abs(lateral), {'heading_deg': heading, 'lateral_m': lateral, 'pre_m': pre, 'post_m': post})
                if plan.ok:
                    return plan
        return None

    def _center(self, target, zone):
        """방향마다 규칙을 지키는 계획을 찾고, 입구 비껴감이 가장 작고 그중 팔을 가장 덜 뻗는 것을 고른다.
        팔을 덜 뻗을수록 특이점에서 멀고, 공중 시연(경로를 올림)도 가능해진다."""
        plans = [p for h in self.headings if (p := self._center_for_heading(target, zone, h)) is not None]
        if not plans:
            return TargetPlan(np.asarray(target, dtype=float), zone, 'center', False,
                              '곧게 쓸기 후보(방향 · 옆 비낌 · 길이)가 모두 경로 규칙을 못 지킴')
        return min(plans, key=lambda p: (round(p.mouth_offset_m, 3), p.check.reach_m))

    # -- 가장자리 A: 대각선 훑기 ----------------------------------------------------

    def sweep_waypoints(self, target, zone, radius_m, body=None):
        z = self.z
        c = float(zone.split('_')[1])
        s = 1.0 if 0.0 < c % 360.0 < 180.0 else -1.0             # 로봇 쪽(180°)으로 도는 방향
        phi_t = c + wrap_deg(self._polar(target)[1] - c)
        r = max(radius_m, self.sweep_min_radius)
        at = phi_t - s * math.degrees(math.atan2(self.mouth_f, r))   # 입구 중심이 목표 방위에 올 때의 표식 방위
        start, end = c - 45.0 * s, c + 45.0 * s
        pre_deg, post_deg = math.degrees(self.pre / r), math.degrees(self.post / r)
        if (at - start) * s < pre_deg:
            start = at - s * pre_deg
        if (end - at) * s < post_deg:
            end = at + s * post_deg
        step = float(z.cfg['motion']['sweep_step_deg'])
        phis = np.linspace(start, end, max(int(math.ceil(abs(end - start) / step)), 1) + 1)
        sweep = [(z._xy(radius_m, p), p + 90.0 * s) for p in phis]
        return z._enter_sweep_exit(sweep, sweep[-1][1], body)

    def _edge_sweep(self, target, zone):
        z = self.z
        r_t = self._polar(target)[0]
        need = math.sqrt(max(r_t ** 2 - self.mouth_f ** 2, 0.0))       # 입구 중심이 목표 반경을 지나는 표식 반경
        lo = float(z.cfg['edge']['arc_radius_min_m'])
        radius = z._largest_feasible(lambda v, b: self.sweep_waypoints(target, zone, v, b), lo, max(need, lo))
        offset = abs(r_t - math.hypot(radius, self.mouth_f))
        plan = self._finish(target, zone, 'edge_sweep', self.sweep_waypoints(target, zone, radius), offset,
                            {'arc_radius_m': radius, 'needed_radius_m': need})
        if plan.ok and offset > self.edge_max_offset:
            plan.ok = False
            plan.reason = (f'입구 중심이 목표 반경에서 {offset * 100:.1f} cm 비껴감 '
                           f'(> {self.edge_max_offset * 100:.0f} cm, 호 반경 {radius * 100:.1f} cm 가 한계)')
        return plan

    # -- 가장자리 B: 벽 마주 보기 ---------------------------------------------------

    def _wall_approach(self, heading_deg, gamma_deg, depth_m, r_down, r_end, body=None):
        z = self.z
        R = z.scoop_rotation(heading_deg, gamma_deg)
        z_low = z.surface_z - depth_m
        wps = z.entry_waypoints(z._xy(r_down, heading_deg), heading_deg, z_low, R, body, mode=self.wall_entry_mode)
        if r_end > r_down + 1e-6:
            wps.append(Waypoint('벽접근', np.r_[z._xy(r_end, heading_deg), z_low], R))
        return wps

    def _wall_tilt_lift(self, waypoints, heading_deg, gamma_deg):
        """벽에 가장 가까운 점이 있는 높이의 벽 원호 중심 둘레로 돌려 올리며 세우고(입구 90° 까지), 수직으로 들어 올린다."""
        z, k = self.z, self.z.kettle
        end = waypoints[-1]
        bottom = float(k.placement['bottom_z_in_base_m'])
        near = z.body.clearance(k, end.position, end.R)
        h = min(max(float(near.point_base[2]) - bottom, 0.0), float(k.wall_top[1]))
        arc, _ = k.wall_arc_at(h)
        a = math.radians(heading_deg)
        e_r, e_z = np.array([math.cos(a), math.sin(a), 0.0]), np.array([0.0, 0.0, 1.0])
        pivot = np.r_[z.axis_xy, bottom] + arc.center[0] * e_r + arc.center[1] * e_z
        axis = np.cross(e_r, e_z)                                  # +θ: 반경 방향을 위로 → 벽을 타고 오르며 입구가 들린다
        total = max(min(self.wall_tilt, 90.0 - gamma_deg), 0.0)
        out = list(waypoints)
        if total > 1e-6:
            for th in np.linspace(0.0, total, max(int(math.ceil(total / self.wall_step)), 1) + 1)[1:]:
                Q = rotation_about(axis, math.radians(th))
                out.append(Waypoint('벽따라세우기', pivot + Q @ (end.position - pivot), Q @ end.R))
        top = out[-1]
        # 벽 가까이에서 수직으로 올린다. 솥은 위로 넓어져 여유가 늘기만 하므로 벽 쪽 단계와 같은 기준을 쓴다.
        out.append(Waypoint('벽들어올리기', np.r_[top.position[:2], max(z.safe_z(top.R), top.position[2])], top.R))
        return out, {'pivot_rh_m': (float(arc.center[0]), float(arc.center[1])), 'tilt_deg': total}

    def _wall_candidate(self, heading, gamma, depth):
        """한 자세(입구 γ, 깊이)에서 내리는 반경, 벽 쪽 수평 접근 끝 반경, 그때 덮는 수면."""
        z, k = self.z, self.z.kettle
        r_down = z._largest_feasible(lambda v, b: self._wall_approach(heading, gamma, depth, v, v, b), 0.0, k.surface_radius)
        R = z.scoop_rotation(heading, gamma)
        z_low = z.surface_z - depth
        need = z.min_clearance_for('벽접근')

        def clearance_at(r):
            return z.body.clearance(k, np.r_[z._xy(r, heading), z_low], R).clearance_m

        if clearance_at(r_down) < need:
            return None
        lo, hi = r_down, k.surface_radius + 0.10
        while hi - lo > self.wall_tol:
            mid = 0.5 * (lo + hi)
            lo, hi = (mid, hi) if clearance_at(mid) >= need else (lo, mid)
        return {'gamma': gamma, 'depth': depth, 'r_down': r_down, 'r_end': lo,
                'band': self.capture_band(np.r_[z._xy(lo, heading), z_low], R, heading)}

    @staticmethod
    def _band_offset(band, r_t):
        return math.inf if band is None else max(band[0] - r_t, r_t - band[1], 0.0)

    def _wall_plan(self, target, zone, heading, candidate):
        """한 자세 후보로 끝까지(세우기 · 들어 올리기 포함) 규칙을 지키는 가장 바깥 접근 끝을 찾아 계획을 만든다."""
        z = self.z
        r_t = self._polar(target)[0]
        gamma, depth, r_down = candidate['gamma'], candidate['depth'], candidate['r_down']

        def build(r, body=None):
            return self._wall_tilt_lift(self._wall_approach(heading, gamma, depth, r_down, r, body), heading, gamma)[0]

        r_end = z._largest_feasible(build, r_down, candidate['r_end'], tol=self.wall_tol)
        R = z.scoop_rotation(heading, gamma)
        band = self.capture_band(np.r_[z._xy(r_end, heading), z.surface_z - depth], R, heading)
        waypoints, extra = self._wall_tilt_lift(self._wall_approach(heading, gamma, depth, r_down, r_end), heading, gamma)
        offset = self._band_offset(band, r_t)
        plan = self._finish(target, zone, 'wall_face', waypoints, offset,
                            {'heading_deg': heading, 'gamma_deg': gamma, 'depth_m': depth, 'descend_radius_m': r_down,
                             'approach_radius_m': r_end, 'capture_band_m': band, **extra})
        plan.params['rules_ok'] = plan.ok
        if plan.ok and offset > self.wall_max_offset:
            plan.ok = False
            plan.reason = ('잠긴 입구가 덮는 수면이 ' + ('없음' if band is None else f'반경 {band[0] * 100:.1f}~{band[1] * 100:.1f} cm')
                           + f' 라 목표 {r_t * 100:.1f} cm 에서 {offset * 100:.1f} cm 벗어남 (입구 {gamma:.0f}°, 깊이 {depth * 100:+.0f} cm)')
        return plan

    def _wall_face(self, target, zone):
        r_t, heading = self._polar(target)
        candidates = [c for g in self.wall_gammas for d in self.wall_depths
                      if (c := self._wall_candidate(heading, g, d)) is not None and c['band'] is not None]
        if not candidates:
            return TargetPlan(np.asarray(target, dtype=float), zone, 'wall_face', False,
                              '어느 입구 각도 · 깊이에서도 벽 쪽으로 다가가 입구를 물에 담글 수 없음')
        candidates.sort(key=lambda c: (self._band_offset(c['band'], r_t), -(c['band'][1] - c['band'][0])))

        def rank(plan):
            band = plan.params.get('capture_band_m')
            return (not plan.params.get('rules_ok', False), plan.mouth_offset_m,
                    -(band[1] - band[0]) if band else 0.0)

        best = None
        for candidate in candidates:            # 후보마다 끝까지 확인한 뒤 가장 잘 덮는 것을 고른다
            plan = self._wall_plan(target, zone, heading, candidate)
            if best is None or rank(plan) < rank(best):
                best = plan
            if best.ok and best.mouth_offset_m == 0.0:
                break
        return best

    # -- 선택 -----------------------------------------------------------------

    def plan(self, x, y):
        target = np.array([float(x), float(y)])
        zone = self.z.zone_of_xy(x, y)
        if zone is None:
            return TargetPlan(target, None, 'none', False, '솥 수면 원 밖 (zones.surface_margin_m 포함)')
        tried = []
        if zone == CENTER:
            plan = self._center(target, zone)
            if plan.ok:
                return plan
            tried.append(plan)
            edge = self.edge_zone_of(target)
        else:
            edge = zone
        for policy in (self._edge_sweep, self._wall_face):
            plan = policy(target, edge)
            if plan.ok:
                plan.zone = zone
                return plan
            tried.append(plan)
        best = min((p for p in tried if p.check is not None), key=lambda p: p.mouth_offset_m, default=tried[-1])
        best.reason = ' / '.join(f'{p.label}: {p.reason}' for p in tried)
        best.zone = zone
        return best

    def plan_policy(self, policy, x, y):
        """정책을 지정해서 계획한다 (시험 · 시연용). policy: center | edge_sweep | wall_face."""
        target = np.array([float(x), float(y)])
        zone = self.z.zone_of_xy(x, y)
        if zone is None:
            return TargetPlan(target, None, 'none', False, '솥 수면 원 밖 (zones.surface_margin_m 포함)')
        edge = zone if zone != CENTER else self.edge_zone_of(target)
        if policy == 'center':
            plan = self._center(target, zone)
        elif policy == 'edge_sweep':
            plan = self._edge_sweep(target, edge)
        elif policy == 'wall_face':
            plan = self._wall_face(target, edge)
        else:
            raise ValueError(f'알 수 없는 정책: {policy} (center | edge_sweep | wall_face)')
        plan.zone = zone
        return plan

    def moves(self, plan):
        """movel 목표와 속도. 경유점 k → k+1 구간이 벽 근처면 느린 속도."""
        slow = plan.segment_slow
        return [([*map(float, w.position), *matrix_to_rpy(w.R)], self.slow_speed if slow[k] else self.speed)
                for k, w in enumerate(plan.waypoints[1:])]


def main():
    parser = argparse.ArgumentParser(description='좌표 입력 정책 표본 결과 (로봇 명령 없음).')
    parser.add_argument('--wall-clearance', type=float, help='벽 마주 보기의 벽접근 · 벽따라세우기 단계 최소 여유 [mm]')
    args = parser.parse_args()
    tp = TargetPolicyPlanner.from_yaml()
    if args.wall_clearance is not None:
        tp.z.stage_min_clearance.update({s: args.wall_clearance / 1000.0 for s in WALL_STAGES})
    ax, ay = tp.z.axis_xy
    wall_need = ', '.join(f'{s} {tp.z.min_clearance_for(s) * 1000:.0f} mm' for s in WALL_STAGES)
    print(f'입구 중심: 표식보다 {tp.mouth_f * 100:.1f} cm 앞, 입구 선 반폭 {tp.mouth_half * 100:.1f} cm '
          f'(입구 {tp.gamma_s:.0f}° · 깊이 {tp.depth * 100:.0f} cm). 최소 여유 {tp.z.min_clearance * 1000:.0f} mm, {wall_need}')
    print(f'{"반경":>6} {"방위":>5}  {"구역":10s} {"정책":12s} 결과  비껴감  최소여유  팔뻗음  느린구간  시간  메모')
    for r, az in [(0.0, 0), (0.15, 0), (0.25, 0), (0.25, 180), (0.30, 90), (0.36, 45), (0.36, 135), (0.40, 225), (0.40, 315),
                  (0.43, 45), (0.43, 180), (0.449, 135), (0.449, 0)]:
        a = math.radians(az)
        t0 = time.monotonic()
        plan = tp.plan(ax + r * math.cos(a), ay + r * math.sin(a))
        dt = time.monotonic() - t0
        c = plan.check.clearance.clearance_m * 1000 if plan.check else math.nan
        reach = plan.check.reach_m if plan.check else math.nan
        slow = f'{sum(plan.segment_slow)}/{len(plan.segment_slow)}' if plan.check else '-'
        memo = plan.reason
        if plan.ok and plan.policy == 'wall_face':
            b = plan.params['capture_band_m']
            memo = f'덮는 수면 {b[0] * 100:.1f}~{b[1] * 100:.1f} cm, 입구 {plan.params["gamma_deg"]:.0f}°, 깊이 {plan.params["depth_m"] * 100:+.0f} cm'
        elif plan.ok and plan.policy == 'edge_sweep':
            memo = f'호 반경 {plan.params["arc_radius_m"] * 100:.1f} cm'
        elif plan.ok and plan.policy == 'center':
            memo = f'방향 {plan.params["heading_deg"]:.0f}°, 옆 {plan.params["lateral_m"] * 100:+.0f} cm'
        print(f'{r * 100:5.1f}cm {az:4d}°  {str(plan.zone):10s} {plan.label:12s} {"OK " if plan.ok else "실패"}  '
              f'{plan.mouth_offset_m * 100:4.1f}cm {c:6.0f}mm  {reach:5.3f}  {slow:>7s}  {dt:4.1f}s  {memo}')
    return 0


if __name__ == '__main__':
    sys.exit(main())
