import flet as ft
from ui import build_ui

# ==============================================================================
# 하이퍼파라미터 기본값 (여기서만 수정하면 됩니다)
# ==============================================================================
DEFAULT_PARAMS = {
    # ── 교반 위치·형상 파라미터 ──────────────────────
    "STIR_RADIUS_CM": 31.0,   # 교반 반경 (cm) - 최대 32.5
    "STIR_DEPTH_CM":   1.0,   # 교반 깊이 (cm)
    "X_BIAS_CM":       0.0,   # 앞뒤 보정 (cm)
    "Y_BIAS_CM":       5.0,   # 좌우 보정 (cm)
    # ── 전체 속도 배율 ────────────────────────────────
    "SPEED_FACTOR_PCT": 100.0,  # 전체 속도 배율 (%) - 50~150
    # ── 동작별 속도 (rad/s 또는 m/s) ─────────────────
    "CIRCLE_VEL":    3.0,   # 교반 원운동 속도
    "CIRCLE_ACC":    2.5,   # 교반 원운동 가속도
    "SCOOP_VEL":     0.8,   # 뜨기 속도
    "SCOOP_ACC":     1.0,   # 뜨기 가속도
    "SHAKE_VEL":    13.0,   # 털기 속도
    "SHAKE_ACC":    15.0,   # 털기 가속도
    "DISCHARGE_VEL": 1.0,   # 배출 속도
    "DISCHARGE_ACC": 0.8,   # 배출 가속도
}

if __name__ == "__main__":
    ft.run(
        lambda page: build_ui(page, DEFAULT_PARAMS),
        assets_dir="assets",
        view=ft.AppView.WEB_BROWSER,
        port=8557

        #http://localhost:<port번호>/
        #위에 해당 사이트 인터넷 주소창에 기입

        #전에 사용 중인 포트 끄기
        #lsof -i :8557 -i :8555 2>/dev/null || ss -tlnp | grep -E '855[57]'
        #kill 23112
    )