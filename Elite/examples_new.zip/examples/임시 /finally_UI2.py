import flet as ft
import datetime
import threading
import time
import math
import struct
import elite_cs_sdk as cs
import os

# ==============================================================================
# [1] 로봇 설정 및 데이터 (Configuration)
# ==============================================================================
ROBOT_IP = "192.168.1.200"  # 제어할 로봇의 고정 IP 주소

# 로봇의 주요 자세(Pose) 정의 (단위: Degree)
HOME_POS_DEG = [0.0, -90.0, -90.0, -90.0, 90.0, 0.0]       # 안전한 홈 위치
CENTER_XYZ = [0.80, -0.0, 0.3]                             # 조리 용기(솥)의 중심 좌표 (X, Y, Z)
START_XYZ  = [0.50, -0.0, 0.3]                             # 교반 시작 지점 좌표
CENTER_JOINT_DEG = [20.71, -83.00, -139.31, -47.68, 90.01, -69.29]  # 조리 시작을 위한 관절 각도

# 동작별 속도(Velocity) 및 가속도(Acceleration) 설정
CIRCLE_VEL = 3.0; CIRCLE_ACC = 2.5      # 교반(저어주기) 동작
SCOOP_VEL = 0.8; SCOOP_ACC = 1.0        # 뜨기(건져내기) 동작
SCOOP_BLEND = 0.05                      # 동작 사이의 부드러움(Blending) 값
SHAKE_VEL = 13.0; SHAKE_ACC = 15.0      # 털기 동작 (빠른 왕복을 위해 높게 설정)
SHAKE_BLEND = 0.01

# [뜨기/털기/배출] 시퀀스용 웨이포인트(Waypoints)
SCOOP_W1_DEG = [20.71, -83.00, -139.31, -47.68, 90.01, -69.29]
SCOOP_W2_DEG = [33.35, -101.85, -154.86, -12.85, 46.13, -96.14]
SCOOP_W3_DEG = [24.54, -92.51, -139.28, -2.02, 14.10, -129.45]
SCOOP_W4_DEG = [51.50, -93.16, -142.88, -25.98, 14.07, -95.83]
SCOOP_SHAKE_DEG = [51.50, -93.16, -142.88, -25.98, -3.77, -95.83]

DISCHARGE_VEL = 1.0; DISCHARGE_ACC = 0.8; DISCHARGE_BLEND = 0.05
DISCHARGE_START_DEG = [51.50, -93.16, -142.88, -25.98, 14.07, -95.83]
W5_MOVE = [-10.47, -108.61, -145.39, -8.02, 14.07, -95.83]
W6_POUR = [-10.47, -108.61, -145.39, -8.02, 14.07, 25.01]  # 음식물을 붓는 각도
W7_FINAL = [0.0, -90.0, -90.0, -90.0, 90.0, 0.0]

# 유틸리티 함수: 각도를 라디안으로 변환 및 SDK 전송용 문자열 포맷팅
def deg_to_rad(deg): return deg * (math.pi / 180.0)
def joints_to_str(joints_deg): return "[" + ", ".join([f"{deg_to_rad(j):.5f}" for j in joints_deg]) + "]"
def to_str(p): return "[" + ", ".join([f"{x:.5f}" for x in p]) + "]"

# 로봇 상태(Cartesian 좌표)를 받아오기 위한 데이터 패키지 파서 클래스
class CartesianInfoPackage(cs.PrimaryPackage):
    def __init__(self): super().__init__(4); self.pose = None
    def parser(self, data: bytes):
        try: self.pose = list(struct.unpack_from('>iBdddddddddddd', data)[2:8])
        except: self.pose = None

# ==============================================================================
# [2] 로봇 제어 클래스 (Robot Controller)
# ==============================================================================
class RobotController:
    def __init__(self, log_callback):
        self.log = log_callback # UI 로그창에 메시지를 띄우기 위한 콜백
        self.primary = cs.PrimaryClientInterface()   # 로봇 동작 명령용 인터페이스 (Port 30001)
        self.dashboard = cs.DashboardClientInterface() # 전원/브레이크 제어용 인터페이스 (Port 29999)
        self.pose_pkg = CartesianInfoPackage()

    def connect_primary(self):
        """로봇의 Primary 포트에 연결 시도"""
        try: return self.primary.connect(ROBOT_IP, 30001)
        except: return False

    def disconnect_primary(self):
        """로봇 연결 해제"""
        try: self.primary.disconnect()
        except: pass
    
    def get_pose(self):
        """로봇의 현재 6축 좌표(X, Y, Z, RX, RY, RZ)를 획득"""
        if self.primary.getPackage(self.pose_pkg, 1000) and self.pose_pkg.pose:
            return self.pose_pkg.pose
        return None

    def dashboard_power_on(self):
        """로봇 부팅 시퀀스: 전원 On -> 브레이크 해제"""
        if not self.dashboard.connect(ROBOT_IP, 29999):
            self.log("❌ 대시보드 연결 실패")
            return False
        self.log("⚡ 로봇 전원 켜는 중...")
        self.dashboard.powerOn()
        time.sleep(7) 
        self.log("🔓 브레이크 해제 중...")
        self.dashboard.brakeRelease()
        time.sleep(5) 
        self.dashboard.disconnect()
        self.log("✅ 로봇 부팅 완료")
        return True

    def dashboard_power_off(self):
        """로봇 종료 시퀀스: 전원 Off"""
        if not self.dashboard.connect(ROBOT_IP, 29999):
            return False
        self.log("📴 로봇 전원 끄는 중...")
        self.dashboard.powerOff()
        time.sleep(2)
        self.dashboard.disconnect()
        return True

    def emergency_stop(self):
        """비상 정지 명령 전송"""
        self.log("🚨 [EMERGENCY STOP] 비상 정지 명령 전송!")
        self.primary.sendScript("stopj(10.0)")

    # --- 각 동작별 제어 함수 ---

    def run_home_pose(self):
        """홈 위치로 이동"""
        self.log("🚀 시스템 시작: 홈 위치로 이동 중...")
        self.primary.sendScript(f"movej({joints_to_str(HOME_POS_DEG)}, a=0.5, v=0.3)")
        time.sleep(6)
        self.log("✅ 홈 위치 도착 완료")

    def run_stirring(self):
        """교반(저어주기) 작업: 원형 경로를 계산하여 movep로 실행"""
        self.log("🔄 [교반] 경로 계산 및 실행...")
        self.primary.sendScript(f"movej({joints_to_str(CENTER_JOINT_DEG)}, a=0.8, v=0.5)")
        time.sleep(4)
        pose = self.get_pose()
        if not pose:
            self.log("❌ 자세 읽기 실패"); return
        
        # 현재 회전값(RX, RY, RZ)을 고정한 채로 원형 이동 좌표 계산
        fix_rot = pose[3:]
        p_c, p_s = CENTER_XYZ + fix_rot, START_XYZ + fix_rot
        r = math.sqrt((p_s[0]-p_c[0])**2 + (p_s[1]-p_c[1])**2)
        ang = math.atan2(p_s[1]-p_c[1], p_s[0]-p_c[0])
        
        # 360도를 36등분하여 72개의 포인트를 생성 (원형 궤적)
        pts = [[p_c[0]+r*math.cos(ang-2*math.pi*i/36), p_c[1]+r*math.sin(ang-2*math.pi*i/36), p_s[2]] + fix_rot for i in range(73)]
        br = max(0.001, min((2*math.pi*r)/36*0.5, 0.05)) # 블렌딩 반경 계산
        
        # 로봇 스크립트 작성 및 전송
        cmds = ["def run_stir():"]
        cmds.append(f"  movel({to_str(pts[0])}, a=1.0, v=0.8)")
        cmds += [f"  movep({to_str(pt)}, a={CIRCLE_ACC}, v={CIRCLE_VEL}, r={br})" for pt in pts[1:]]
        cmds.append(f"  movep({to_str(pts[-1])}, a={CIRCLE_ACC}, v={CIRCLE_VEL}, r=0.0)")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        time.sleep(5); self.log("✅ 교반 명령 전송 완료")

    def run_scooping(self):
        """뜨기(건져내기) 동작 시퀀스"""
        self.log("🥄 [뜨기] 작업 실행")
        cmds = ["def run_scoop():"]
        cmds.append(f"  movej({joints_to_str(SCOOP_W1_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL})")
        cmds.append(f"  movej({joints_to_str(SCOOP_W2_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r=0.0)")
        cmds.append("  sleep(2.0)")
        cmds.append(f"  movej({joints_to_str(SCOOP_W3_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r={SCOOP_BLEND})")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        time.sleep(8)

    def run_shaking(self):
        """물기/기름 털기 동작 (빠른 왕복 4회)"""
        self.log("👋 [털기] 작업 실행")
        cmds = ["def run_shake():"]
        cmds.append(f"  movej({joints_to_str(SCOOP_W4_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r=0.0)")
        for _ in range(4):
            cmds.append(f"  movej({joints_to_str(SCOOP_SHAKE_DEG)}, a={SHAKE_ACC}, v={SHAKE_VEL}, r={SHAKE_BLEND})")
            cmds.append(f"  movej({joints_to_str(SCOOP_W4_DEG)}, a={SHAKE_ACC}, v={SHAKE_VEL}, r={SHAKE_BLEND})")
        cmds.append(f"  movej({joints_to_str(SCOOP_W4_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r=0.0)")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        time.sleep(4)

    def run_discharge(self):
        """음식물 배출 및 최종 위치 이동"""
        self.log("🚚 [배출] 작업 실행")
        cmds = ["def run_discharge():"]
        cmds.append(f"  movej({joints_to_str(DISCHARGE_START_DEG)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append(f"  movej({joints_to_str(W5_MOVE)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r={DISCHARGE_BLEND})")
        cmds.append(f"  movej({joints_to_str(W6_POUR)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append("  sleep(2.0)") # 붓는 시간 대기
        cmds.append(f"  movej({joints_to_str(W5_MOVE)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r={DISCHARGE_BLEND})")
        cmds.append(f"  movej({joints_to_str(DISCHARGE_START_DEG)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append(f"  movej({joints_to_str(W7_FINAL)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        time.sleep(12); self.log("✅ 배출 작업 완료")

    def run_integrated_test(self):
        """[전체 자동 시퀀스] 교반 -> 뜨기 -> 털기 -> 배출 일괄 실행"""
        self.log("▶ [전체 시퀀스] 실행")
        # (각 동작의 스크립트를 하나로 합쳐서 전송하여 연속 동작 구현)
        # ... (상세 로직은 개별 함수와 동일)
        self.log("🏁 전체 시퀀스 명령 전송 완료")

# ==============================================================================
# [3] UI 메인 코드 (Flet Framework)
# ==============================================================================
def main(page: ft.Page):
    # 윈도우 기본 설정 (제목, 크기, 배경색 등)
    page.title = "RIA Lab Control Panel"
    page.window.width = 1200
    page.window.height = 800
    page.padding = 0
    page.theme_mode = ft.ThemeMode.LIGHT
    page.bgcolor = ft.Colors.BLUE_GREY_50
    page.theme = ft.Theme(font_family="NanumGothic")

    page.window.center()
    page.window.prevent_close = True # 실수로 끄는 것 방지

    # 로그 표시용 리스트뷰
    global log_list
    log_list = ft.ListView(expand=True, spacing=5, padding=10, auto_scroll=True)

    def log_handler(msg):
        """메시지를 로그 리스트에 추가하고 화면 갱신"""
        ts = datetime.datetime.now().strftime("[%H:%M:%S]")
        if log_list.page:
            log_list.controls.append(ft.Text(f"{ts} {msg}", size=14, color=ft.Colors.BLACK87))
            try: page.update()
            except: pass

    robot = RobotController(log_handler)

    def direct_shutdown():
        """시스템 안전 종료: 로봇 전원 끄기 후 프로그램 종료"""
        page.snack_bar = ft.SnackBar(ft.Text("종료 중..."), open=True)
        page.update()
        def _shutdown():
            robot.dashboard_power_off()
            page.window.destroy()
            os._exit(0)
        threading.Thread(target=_shutdown, daemon=True).start()

    # 윈도우 X 버튼 클릭 시 종료 시퀀스 실행
    page.on_window_event = lambda e: direct_shutdown() if e.data == "close" else None

    def run_task(task_type):
        """비동기(Thread)로 로봇 동작 업무 수행"""
        def _task():
            # 부팅 업무
            if task_type == "BOOTING":
                if robot.dashboard_power_on():
                    show_control() # 제어 화면으로 전환
                    time.sleep(1)
                    run_task("HOME")
                else:
                    log_handler("❌ 부팅 실패")
                return

            # 나머지 동작 업무 (Primary 연결 필요)
            if not robot.connect_primary():
                log_handler("❌ 로봇 연결 실패")
                return
            try:
                if task_type == "INIT": robot.run_init_pose()
                elif task_type == "STIR": robot.run_stirring()
                elif task_type == "SCOOP": robot.run_scooping()
                elif task_type == "SHAKE": robot.run_shaking()
                elif task_type == "DISCHARGE": robot.run_discharge()
                elif task_type == "ALL": robot.run_integrated_test()
                elif task_type == "HOME": robot.run_home_pose()
                elif task_type == "STOP": robot.emergency_stop()
            except Exception as e: log_handler(f"⚠️ 에러: {e}")
            finally: robot.disconnect_primary()
        
        # UI 프리징 방지를 위해 항상 별도 스레드에서 로봇 명령 수행
        threading.Thread(target=_task, daemon=True).start()

    def on_btn_click(e):
        """버튼 클릭 시 해당 텍스트에 맞는 동작 매핑"""
        txt = e.control.content.controls[1].value if isinstance(e.control.content, ft.Row) else "ALL"
        task = "ALL"
        if "초기" in txt: task = "INIT"
        elif "교반" in txt: task = "STIR"
        elif "뜨기" in txt: task = "SCOOP"
        elif "털기" in txt: task = "SHAKE"
        elif "배출" in txt: task = "DISCHARGE"
        elif "비상" in txt: task = "STOP"
        run_task(task)

    # --- UI 컴포넌트 빌더 함수들 ---

    def btn(text, icon, color):
        """공통 스타일의 버튼 생성 함수"""
        return ft.ElevatedButton(
            content=ft.Row([ft.Icon(icon, size=24, color="white"), ft.Text(text, size=18, weight="bold", color="white")], spacing=20),
            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=10), bgcolor=color, padding=20),
            width=float("inf"), height=70, on_click=on_btn_click
        )

    def build_control_panel():
        """좌측 수동 제어 버튼들과 우측 자동 제어/로그 영역 구성"""
        # ... (Flet UI 구조 코드)
        return ft.Row([...], expand=True)

    def show_booting_screen():
        """부팅 중 로딩 화면 표시"""
        page.clean()
        page.add(ft.Container(content=ft.Column([...]), expand=True))
        page.update()
        run_task("BOOTING")

    def show_home(e=None):
        """메인 홈 화면 (시작하기/종료하기 버튼)"""
        page.clean()
        page.add(ft.Stack([...], expand=True))
        page.update()

    def show_control(e=None):
        """실제 로봇 제어 화면"""
        page.clean()
        header = ft.Container(...)
        page.add(ft.Column([header, ft.Container(build_control_panel(), expand=True)], expand=True))
        page.update()

    # 상단 실시간 시계 업데이트 스레드
    clock_text = ft.Text("", size=16)
    def update_clock():
        while True:
            clock_text.value = datetime.datetime.now().strftime("현재시간 %H:%M:%S")
            try: page.update()
            except: break
            time.sleep(1)
    
    threading.Thread(target=update_clock, daemon=True).start()
    show_home() # 앱 시작 시 홈 화면 표시

# Flet 앱 실행
ft.app(target=main, assets_dir="assets")