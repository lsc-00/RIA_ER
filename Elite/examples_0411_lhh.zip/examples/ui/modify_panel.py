# ui/modify_panel.py
# 교반 좌표 수정 페이지를 담당합니다.
# 현재 교반 좌표를 표시하고 JSON에 저장된 위치로 수정합니다.

import flet as ft
import elite_cs_sdk as cs
import struct
import math
import time
import threading
import json
import os

from robot_controller import ROBOT_IP, HOME_POS_DEG, CENTER_JOINT_DEG, POSITIONS

def build_modify_page(page: ft.Page, on_back):
    # ── [1. 상태 관리 변수 선언 - 가장 상단에 배치] ────────────────
    current_target_name = None   # 좌측에서 선택한 W1~W4 이름
    selected_new_coords = None   # 팝업에서 선택한 새로운 좌표값

    current_selection_title = ft.Text("위치를 선택해주세요", size=16, weight="bold", color=ft.Colors.PURPLE_700)
    # 수정 전 좌표 (좌측 선택) 표시용
    before_coords_text = ft.Text("수정 전 좌표 : 선택 없음", size=14, no_wrap=True, overflow=ft.TextOverflow.ELLIPSIS, color=ft.Colors.BLUE_GREY_800)
    # 수정할 좌표 (우측 로그 선택) 표시용
    after_coords_text = ft.Text("수정 후 좌표 : 선택 없음", size=14, no_wrap=True, overflow=ft.TextOverflow.ELLIPSIS, color=ft.Colors.DEEP_ORANGE_700)

    stop_evt = threading.Event()
    log_view = ft.ListView(expand=True, spacing=4)
    
    # ── [좌측 패널] ──────────────────────────────────
    def create_joint_card(name, values):
        joint_labels = ["J1", "J2", "J3", "J4", "J5", "J6"]
        row_content = ft.Row(
            [ft.Text(f"{joint_labels[i]}: {values[i]:.1f}°", size=11, color=ft.Colors.BLUE_GREY_700) for i in range(6)],
            spacing=8, wrap=True
        )
        
        return ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Icon(ft.Icons.LOCATION_ON, size=16, color=ft.Colors.PURPLE),
                    ft.Text(name, weight="bold", size=14, color=ft.Colors.PURPLE_800)
                ]),
                ft.Divider(height=1, color=ft.Colors.PURPLE_100),
                row_content
            ], spacing=5),
            padding=12, bgcolor="#F3F0FA", border_radius=8,
            border=ft.border.all(1, "#E1D5F5"), margin=ft.margin.only(bottom=10),
            # 클릭 이벤트 추가
            on_click=lambda _: on_position_click(name, values),
            # 마우스 올렸을 때 피드백
            ink=True,
        )

        return ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Icon(ft.Icons.LOCATION_ON, size=16, color=ft.Colors.PURPLE),
                    ft.Text(name, weight="bold", size=14, color=ft.Colors.PURPLE_800),
                ]),
                ft.Divider(height=1, color=ft.Colors.PURPLE_100),
                row_content
            ], spacing=5),
            padding=12,
            bgcolor="#F3F0FA",
            border_radius=8,
            border=ft.border.all(1, "#E1D5F5"),
            margin=ft.margin.only(bottom=10)
        )

    def load_json_data(file_path):
        if os.path.exists(file_path):
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    return json.load(f)
            except Exception as e:
                print(f"JSON 로드 오류: {e}")
                return {}
        return {}

    # ── [클릭 이벤트 핸들러] ────────────────────────
    def on_position_click(name, values):
        """좌측 '기본 위치' 카드 클릭 시"""
        nonlocal current_target_name
        current_target_name = name
        current_selection_title.value = f"현재 {name} 수정 중"
        # 좌표 리스트를 보기 좋게 포맷팅
        coords_display = [f"{v:.1f}" for v in values] if isinstance(values, list) else values
        before_coords_text.value = f"수정 전 ({name}): {coords_display}"
        page.update()
    
    def on_log_item_click(log_name, log_values):
        """우측 '저장 로그' 아이템 클릭 시"""
        page.update()

    # ── 돌아가기 ─────────────────────────────────────
    def do_back(e):
        stop_evt.set()
        try:
            primary.disconnect()
        except Exception:
            pass
        on_back()

    # ── [JSON 데이터 다이얼로그 함수] ────────────────
    def show_detail_dialog(name, coords):
        """저장 로그 항목을 클릭했을 때 해당 데이터만 상세 팝업으로 표시"""
        # 데이터가 딕셔너리 형태인 경우 joints와 poses 추출
        joint_list = coords.get("joints", []) if isinstance(coords, dict) else [coords]
        pose_list  = coords.get("poses", []) if isinstance(coords, dict) else []
        
        def select_and_close(val, idx):
            nonlocal selected_new_coords
            selected_new_coords = val
            after_coords_text.value = f"수정 후 ({name} #{idx+1}):\n{val}"
            _close_dlg(dlg)
            page.update()
        
        # 상세 행 생성 로직 (제공해주신 show_saved_data의 로직 활용)
        point_rows = []
        for idx in range(len(joint_list)):
            j_vals = joint_list[idx]
            p_vals = pose_list[idx] if idx < len(pose_list) else []
            j_str = ", ".join([f"{v:.2f}" for v in j_vals]) if isinstance(j_vals, list) else str(j_vals)
            p_str = ", ".join([f"{v:.4f}" for v in p_vals]) if p_vals else "-"

            point_rows.append(
                ft.Container(
                    content=ft.Column([
                        ft.Row([
                            ft.Text(f"#{idx+1} 선택하기", size=12, weight="bold", color=ft.Colors.PURPLE_700),
                            ft.Icon(ft.Icons.CHEVRON_RIGHT, size=14, color=ft.Colors.PURPLE_300)
                        ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                        ft.Text(f"Joint: [{j_str}]", size=11, color=ft.Colors.BLUE_GREY_600, font_family="Consolas"),
                        ft.Text(f"Pose: [{p_str}]", size=11, color=ft.Colors.BLUE_GREY_600, font_family="Consolas"),
                    ], spacing=2),
                    bgcolor=ft.Colors.GREY_50,
                    border_radius=8,
                    padding=12,
                    ink=True,
                    on_click=lambda e, v=j_vals, i=idx: select_and_close(v, i)
                )
            )

        dlg = ft.AlertDialog(
            title=ft.Row([
                ft.Icon(ft.Icons.LOCATION_ON, color=ft.Colors.DEEP_PURPLE_500),
                ft.Text(f"{name} 상세 정보")
            ]),
            content=ft.Container(
                content=ft.Column(point_rows, scroll=ft.ScrollMode.AUTO),
                width=400, height=300
            ),
            actions=[ft.TextButton("닫기", on_click=lambda e: _close_dlg(dlg))]
        )
        page.overlay.append(dlg)
        dlg.open = True
        page.update()

    def _close_dlg(dlg):
        dlg.open = False
        page.update()

    def save_positions():
        with open("positions_data.json", "w", encoding="utf-8") as f:
            json.dump(POSITIONS, f, indent=4, ensure_ascii=False)

    def do_modify(e):
        """[핵심] 수정하기 버튼 클릭 시 JSON 파일 및 메모리 업데이트"""
        nonlocal current_target_name, selected_new_coords
        
        if not current_target_name or not selected_new_coords:
            log_view.controls.insert(
                0,
                ft.Container(
                    content=ft.Text(
                        f"수정할 대상과 새로운 좌표를 모두 선택해주세요.",
                        size=12, color=ft.Colors.RED_800,
                    ),
                    bgcolor=ft.Colors.RED_50,
                    border_radius=6,
                    padding=ft.padding.symmetric(horizontal=8, vertical=4),
                ),
            )
            page.update()
            return

        # 1. 메모리(POSITIONS 딕셔너리) 업데이트
        POSITIONS[current_target_name] = selected_new_coords
        
        save_positions()

        # 3. [추가] 우측 UI 텍스트 초기화
        current_selection_title.value = "위치를 선택해주세요"
        before_coords_text.value = "수정 전 좌표 : 선택 없음"
        after_coords_text.value = "수정 후 좌표 : 선택 없음"

        # 4. 좌측 리스트 컴포넌트 재구성
        left_cards_column.controls = [
            create_joint_card(k, POSITIONS[k]) 
            for k in list(POSITIONS.keys())[:4]
        ]

        log_view.controls.insert(
            0,
            ft.Container(
                content=ft.Text(
                    f"{current_target_name}의 좌표가 수정됨",
                    size=12, color=ft.Colors.GREEN_800,
                ),
                bgcolor=ft.Colors.GREEN_50,
                border_radius=6,
                padding=ft.padding.symmetric(horizontal=8, vertical=4),
            ),
        )

        page.update()
        
    # [2] 초기화 로직 함수
    def reset_to_default(e):
        # 1. 메모리 업데이트 (전체 덮어쓰기)
        DEFAULT_POSITIONS = load_json_data("positions_data_origin.json")
        for key, value in DEFAULT_POSITIONS.items():
            POSITIONS[key] = value

        save_positions()

        # 2. [추가] 선택 상태 변수 초기화
        nonlocal current_target_name, selected_new_coords
        current_target_name = None
        selected_new_coords = None

        # 3. [추가] 우측 UI 텍스트 초기화
        current_selection_title.value = "위치를 선택해주세요"
        before_coords_text.value = "수정 전 좌표 : 선택 없음"
        after_coords_text.value = "수정 후 좌표 : 선택 없음"

        # 4. 좌측 리스트 컴포넌트 재구성
        left_cards_column.controls = [
            create_joint_card(k, POSITIONS[k]) 
            for k in list(POSITIONS.keys())[:4]
        ]

        log_view.controls.insert(
            0,
            ft.Container(
                content=ft.Text(
                    f"기본 좌표로 초기화됨",
                    size=12, color=ft.Colors.GREEN_800,
                ),
                bgcolor=ft.Colors.GREEN_50,
                border_radius=6,
                padding=ft.padding.symmetric(horizontal=8, vertical=4),
            ),
        )

        # 3. UI 갱신 (페이지 새로고침 또는 컴포넌트 업데이트)
        page.update()


    # ==============================================================
    # 페이지 레이아웃 조립
    # ==============================================================
    left_cards_column = ft.Column(
        [create_joint_card(k, POSITIONS[k]) for k in list(POSITIONS.keys())[:4]],
        scroll=ft.ScrollMode.AUTO, 
        expand=True
    )

    # ── 저장 로그 리스트 생성 ────────────────────────
    log_items = ft.Column(scroll=ft.ScrollMode.ALWAYS, expand=True)
    
    TEACHING_DATA = "teaching_data.json"
    saved_data = load_json_data(TEACHING_DATA)
    
    # JSON 파일 내의 데이터를 반복문으로 추가 + 다이럴로그
    for name, coords in saved_data.items():
        coords_val = coords.get('joints', coords) if isinstance(coords, dict) else coords
        on_log_item_click(name, coords_val)

        log_items.controls.append(
            ft.Container(
                content=ft.Row([
                    ft.Icon(ft.Icons.STORAGE, size=16, color=ft.Colors.BLUE_GREY_400),
                    ft.Column([
                        ft.Text(name, size=13, weight="bold"),
                        ft.Text(f"{coords_val}", size=11, color=ft.Colors.GREY_600, no_wrap=True, overflow=ft.TextOverflow.ELLIPSIS),
                    ], spacing=2, expand=True),
                ]),
                padding=10, border=ft.border.all(1, ft.Colors.GREY_100),
                border_radius=8, margin=ft.margin.only(bottom=5), bgcolor=ft.Colors.WHITE,
                ink=True,
                # [수정된 부분] 클릭 시 팝업을 열고, 동시에 상단 비교 텍스트도 업데이트
                on_click=lambda e, n=name, v=coords: [
                    on_log_item_click(n, v.get('joints', v) if isinstance(v, dict) else v), # 상단 텍스트 업데이트
                    show_detail_dialog(n, v) # 상세 팝업 오픈
                ]
            )
        )

    # ── 좌측 하단 '저장돤 데이터' 섹션 (수정된 부분) ───────
    left_panel = ft.Column([
        ft.Row([
            ft.Icon(ft.Icons.LIST_ALT, color=ft.Colors.BLUE_GREY), 
            ft.Text("현재 위치 (W1-W4)", size=16, weight="bold")
        ]),
        ft.Container(height=10),
        # 리스트 영역 (스크롤 가능하게 유지)
        ft.Container(
            content=left_cards_column,
            #expand=2,
        ),
        # [추가] 초기화 버튼 영역
        ft.Divider(height=1, color=ft.Colors.GREY_300),
        ft.Row([
            ft.Icon(ft.Icons.HISTORY, color=ft.Colors.BLUE_GREY), 
            ft.Text("저장된 데이터", size=16, weight="bold")
        ]),
        ft.Container(
            content=log_items, # 위에서 만든 log_items를 여기에 배치
            expand=True,
            bgcolor=ft.Colors.WHITE,
            padding=10,
            border=ft.border.all(1, ft.Colors.GREY_300),
            border_radius=5,
            height=300 # 적절한 높이 설정
        ),
    ], expand=True, spacing=10)

    # ── [4. 우측 상단 정보 영역 구성] ──────────────────────────────
    # 현재 수정 중 타이틀 아래에 전/후 좌표가 나열됩니다.
    selection_info_panel = ft.Container(
        content=ft.Column([
            ft.Row([ft.Icon(ft.Icons.EDIT_LOCATION_ALT, color=ft.Colors.PURPLE), current_selection_title]),
            ft.Divider(height=1, color=ft.Colors.PURPLE_100),
            ft.Container(content=before_coords_text, padding=5),
            ft.Container(content=after_coords_text, padding=5),
        ], spacing=5),
        padding=15, bgcolor=ft.Colors.PURPLE_50, border_radius=10, border=ft.border.all(1, "#E1D5F5")
    )

    button_row = ft.Row([
        ft.ElevatedButton(
            "✅ 수정하기",
            bgcolor=ft.Colors.PURPLE_700,
            color="white",
            height=50,
            expand=True, # 공간을 나눠 갖도록 설정
            on_click=do_modify
        ),
        ft.OutlinedButton(
            content=ft.Row([
                ft.Icon(ft.Icons.RESTART_ALT, size=18),
                ft.Text("기본값으로 초기화", size=13),
            ], spacing=5),
            style=ft.ButtonStyle(
                color=ft.Colors.RED_600,
                side=ft.BorderSide(1, ft.Colors.RED_200),
                shape=ft.RoundedRectangleBorder(radius=8),
            ),
            height=50,
            on_click=reset_to_default
        )
    ], alignment=ft.MainAxisAlignment.CENTER, spacing=10)

    # ── 우측 패널 전체 조립 ──────────────────────────
    right_panel = ft.Column([
        ft.Container(
            content=ft.Column([
                current_selection_title,
                before_coords_text,
                ft.Row(
                    controls=[after_coords_text],
                    scroll=ft.ScrollMode.AUTO,
                )
            ], spacing=10),
            padding=20,
            bgcolor=ft.Colors.PURPLE_50,
            border_radius=12,
            border=ft.border.all(1, ft.Colors.PURPLE_100),

            #alignment=ft.alignment.Alignment(-1, 0), # Container 자체를 부모 안에서 좌측에 밀착
            width=float("inf"), # 명시적으로 가로 너비를 무한대로 설정 (가장 확실한 방법)
        ),
        button_row, # 위에서 만든 버튼 가로 줄 삽입

        # 로그 리스트
        ft.Container(
            content=log_view,
            bgcolor=ft.Colors.GREY_50,
            border_radius=10,
            border=ft.border.all(1, ft.Colors.GREY_300),
            expand=True,
            padding=10,
        ),
    ], expand=True, spacing=20)

    # ── [4. 최종 레이아웃 조립] ──────────────────────────────────
    return ft.Column([
        # ── 헤더 바 ──────────────────────────────────
        ft.Container(
            content=ft.Row([
                ft.FilledButton(
                    content=ft.Row([
                        ft.Icon(ft.Icons.ARROW_BACK, color="white", size=20),
                        ft.Text(
                            "제어 화면으로 돌아가기",
                            color="white", size=14,
                            weight=ft.FontWeight.BOLD,
                        ),
                    ], spacing=8),
                    style=ft.ButtonStyle(
                        bgcolor=ft.Colors.BLUE_GREY_600,
                        shape=ft.RoundedRectangleBorder(radius=8),
                    ),
                    on_click=do_back,
                ),
                ft.Row([
                    ft.Icon(ft.Icons.EDIT_LOCATION_ALT, size=24, color=ft.Colors.DEEP_PURPLE_700),
                    ft.Text(
                        "위치 수정 (Modify)",
                        size=22, weight=ft.FontWeight.BOLD,
                        color=ft.Colors.DEEP_PURPLE_700,
                    ),
                ], spacing=8),
                ft.Container(width=200),  # 중앙 정렬용 스페이서
            ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
            bgcolor="white",
            padding=ft.padding.symmetric(horizontal=20, vertical=14),
            shadow=ft.BoxShadow(
                blur_radius=10,
                color=ft.Colors.with_opacity(0.08, ft.Colors.BLACK),
            ),
        ),
        # 메인 콘텐츠 (좌측: W1-W4 리스트, 우측: 조립된 right_panel)
        ft.Container(
            content=ft.Row([
                ft.Container(content=left_panel, expand=1, padding=10),
                ft.VerticalDivider(width=1, color=ft.Colors.GREY_300),
                # 수정된 부분: "우측 영역" 텍스트 대신 실제 조립한 right_panel을 넣음
                ft.Container(content=right_panel, expand=1, padding=10),
            ], expand=True),
            expand=True
        )
    ], expand=True)