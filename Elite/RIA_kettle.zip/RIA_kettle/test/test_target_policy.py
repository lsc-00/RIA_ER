import math

import numpy as np
import pytest

from ria_kettle.target_policy import WALL_STAGES, TargetPolicyPlanner, mouth_geometry


@pytest.fixture(scope='module')
def tp():
    return TargetPolicyPlanner.from_yaml(water_surface_z=None)   # 알고리즘 시험은 설계 수위 100 L 기준


def at(tp, r, deg):
    a = math.radians(deg)
    return tp.z.axis_xy + r * np.array([math.cos(a), math.sin(a)])


def test_mouth_geometry_matches_sampled_waterline(tp):
    z = tp.z
    for gamma, depth in ((21.0, 0.0), (50.0, 0.05)):
        f, half = mouth_geometry(z.scoop, gamma, depth)
        R = z.scoop_rotation(180.0, gamma)
        marker = np.array([*z.axis_xy, z.surface_z - depth])
        pts = z.mouth_waterline_xy([('쓸기', marker, R)], band_m=0.002, step_m=0.002)
        forward = -(pts[:, 0] - marker[0])
        assert 0.5 * (forward.min() + forward.max()) == pytest.approx(f, abs=0.002)
        assert 0.5 * np.ptp(pts[:, 1]) == pytest.approx(half, abs=0.003)


def test_outside_target_has_no_policy(tp):
    plan = tp.plan(*at(tp, 0.50, 30.0))
    assert plan.policy == 'none' and not plan.ok


def test_center_target_sweeps_the_mouth_over_the_target(tp):
    target = at(tp, 0.0, 0.0)
    plan = tp.plan(*target)
    assert plan.ok and plan.policy == 'center'
    a = math.radians(plan.params['heading_deg'])
    u, n = np.array([math.cos(a), math.sin(a)]), np.array([-math.sin(a), math.cos(a)])
    start = next(w for w in plan.waypoints if w.stage == '내리기').position[:2] + tp.mouth_f * u
    end = [w for w in plan.waypoints if w.stage == '쓸기'][-1].position[:2] + tp.mouth_f * u
    assert (target - start) @ u > 0 and (end - target) @ u > 0      # 입구 중심이 목표 앞에서 시작해 지나친다
    assert abs((target - start) @ n) <= max(map(abs, tp.laterals)) + 1e-9


def test_ok_plans_obey_path_rules_and_slow_down_near_the_wall(tp):
    for r, deg in ((0.10, 200.0), (0.36, 45.0), (0.43, 135.0)):
        plan = tp.plan(*at(tp, r, deg))
        if not plan.ok:
            assert plan.reason
            continue
        assert tp.z.feasible(plan.check)
        moves = tp.moves(plan)
        assert len(moves) == len(plan.waypoints) - 1
        speeds = {s for _, s in moves}
        assert speeds <= {tp.speed, tp.slow_speed}
        if any(plan.segment_slow):
            assert tp.slow_speed in speeds


def test_wall_face_follows_the_wall_and_reports_the_capture_band(tp):
    r = 0.43
    plan = tp._wall_face(at(tp, r, 135.0), 'edge_135')
    if plan.check is None:
        pytest.skip(plan.reason)
    stages = [w.stage for w in plan.waypoints]
    assert '벽접근' in stages and stages[-1] == '벽들어올리기'
    lo, hi = plan.params['capture_band_m']
    assert lo < hi
    assert plan.mouth_offset_m == pytest.approx(max(lo - r, r - hi, 0.0), abs=1e-6)
    # 벽 원호 중심 둘레로 돌리는 동안 벽 쪽 점의 여유가 거의 그대로 (벽 쪽으로 다가가지 않음)
    assert not plan.check.closing


def test_plan_policy_forces_the_requested_policy(tp):
    plan = tp.plan_policy('wall_face', *at(tp, 0.40, 225.0))
    assert plan.policy == 'wall_face' and plan.zone == 'edge_225'
    with pytest.raises(ValueError):
        tp.plan_policy('unknown', *at(tp, 0.40, 225.0))


def test_lower_wall_stage_clearance_reaches_closer_to_the_wall(tp):
    target = at(tp, 0.449, 135.0)
    base = tp._wall_face(target, 'edge_135')
    saved = dict(tp.z.stage_min_clearance)
    try:
        tp.z.stage_min_clearance.update({s: 0.015 for s in WALL_STAGES})
        closer = tp._wall_face(target, 'edge_135')
    finally:
        tp.z.stage_min_clearance.clear()
        tp.z.stage_min_clearance.update(saved)
    assert closer.params['capture_band_m'][1] > base.params['capture_band_m'][1]
