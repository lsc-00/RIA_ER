#!/usr/bin/env python3
"""
kettle_viewer.html 을 만든다. 브라우저로 열면 3D 솥 · 스쿱과 단면 그림을 함께 볼 수 있다.

    python3 make_viewer.py        # extract_profile.py 를 먼저 실행해 kettle_profile.yaml 이 있어야 한다

솥 STL 을 HTML 안에 넣어 두므로 파일 하나만 열면 된다.
3D 는 three.js 를 인터넷(CDN)에서 받는다. 인터넷이 없어도 단면 그림은 동작한다.
"""

import base64
import json
import sys
from pathlib import Path

import numpy as np
import yaml

sys.dont_write_bytecode = True     # 옆 모듈을 import 해도 이 디렉토리에 __pycache__ 를 남기지 않는다

from extract_profile import POT_STL, PROFILE_YAML, load_stl  # noqa: E402
from kettle_model import KettleModel  # noqa: E402
from scoop_path import ScoopGeometry  # noqa: E402

HERE = Path(__file__).resolve().parent
OUTPUT = HERE / 'kettle_viewer.html'
QUANT_M = 1e-4          # 메시 좌표를 0.1 mm 단위 int16 으로 줄여 넣는다 (±3.27 m 까지)


def pack_mesh(tri):
    q = np.round(tri.reshape(-1, 3) / QUANT_M)
    if np.abs(q).max() > np.iinfo(np.int16).max:
        raise ValueError('메시가 int16 범위(±3.27 m)를 넘습니다.')
    return base64.b64encode(q.astype('<i2').tobytes()).decode('ascii')


def rounded(values, digits=5):
    return np.round(np.asarray(values, dtype=float), digits).tolist()


def main():
    if not PROFILE_YAML.exists():
        raise SystemExit(f'{PROFILE_YAML.name} 가 없습니다. 먼저 python3 extract_profile.py 를 실행하세요.')
    profile = yaml.safe_load(PROFILE_YAML.read_text(encoding='utf-8'))
    kettle = KettleModel.from_yaml(PROFILE_YAML, sample_step=0.001)
    scoop = ScoopGeometry.from_yaml()

    frame = profile['frame']
    origin = np.array([*frame['axis_in_stl_m'], frame['bottom_z_in_stl_m']])
    stl = load_stl(POT_STL) - origin          # 솥 중심 · 바닥 기준으로 옮긴다
    # 솥 좌표계 x, y 는 로봇 base 와 같은 방향이다 (kettle_model.base_to_kettle 과 같은 정의).
    # 실물 배치: robot +X = STL +Y, robot +Y = STL −X  →  점 좌표는 x = y_stl, y = −x_stl (−90°)
    pot = np.stack([stl[..., 1], -stl[..., 0], stl[..., 2]], axis=-1)

    data = {
        'summary': profile['summary'],
        'operating': profile['operating'],
        'placement': profile['placement'],
        'pieces': profile['design']['pieces'],
        'fit': profile['design']['fit'],
        'rings': profile['cad_rings']['rings'],
        'boundary': rounded(kettle.boundary),
        'scoop': {
            'rim_diameter_m': scoop.rim_diameter_m, 'depth_m': scoop.depth_m,
            'rim_radius_m': scoop.rim_radius_m, 'sphere_radius_m': scoop.sphere_radius_m,
            'cap_half_angle_deg': scoop.cap_half_angle_deg,
            'handle_length_m': scoop.handle_length_m, 'handle_diameter_m': scoop.handle_diameter_m,
        },
        'scale': QUANT_M,
        'meshes': {'pot': pack_mesh(pot)},
    }
    payload = json.dumps(data, ensure_ascii=False, separators=(',', ':'))
    OUTPUT.write_text(TEMPLATE.replace('__DATA__', payload), encoding='utf-8')
    print(f'저장: {OUTPUT.name} ({OUTPUT.stat().st_size / 1e6:.1f} MB)')
    print(f'열기: xdg-open {OUTPUT}')


TEMPLATE = r'''<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>ENR-500 내솥 · 스쿱 뷰어</title>
<style>
:root {
  --bg: #f4f5f7; --panel: #ffffff; --ink: #1d2330; --muted: #5f6878; --line: #e1e5eb;
  --accent: #e8590c; --arc1: #1971c2; --arc2: #e8590c; --water: #1c7ed6; --net: #7048e8;
  --wall: #212529; --lip: #868e96; --ok: #2b8a3e; --warn: #d9480f;
  --view-top: #eef1f5; --view-bottom: #d3d9e2;
}
@media (prefers-color-scheme: dark) {
  :root {
    --bg: #14171c; --panel: #1b1f26; --ink: #e6e9ef; --muted: #9aa3b2; --line: #2b313c;
    --accent: #ff8a4c; --arc1: #74c0fc; --arc2: #ff8a4c; --water: #4dabf7; --net: #b197fc;
    --wall: #e9ecef; --lip: #adb5bd; --ok: #69db7c; --warn: #ffa94d;
    --view-top: #252a33; --view-bottom: #171a20;
  }
}
* { box-sizing: border-box; }
body { margin: 0; padding: 16px; background: var(--bg); color: var(--ink);
       font: 14px/1.5 system-ui, -apple-system, "Noto Sans KR", "Apple SD Gothic Neo", sans-serif; }
header, main, .notes { max-width: 1440px; margin-left: auto; margin-right: auto; }
header { margin-bottom: 12px; }
h1 { font-size: 20px; margin: 0 0 2px; }
header p { margin: 0; color: var(--muted); }
main { display: grid; grid-template-columns: minmax(0, 1.2fr) minmax(0, 1fr); gap: 12px; align-items: start; }
@media (max-width: 960px) { main { grid-template-columns: 1fr; } }
.card { background: var(--panel); border: 1px solid var(--line); border-radius: 10px; padding: 12px; min-width: 0; }
.card h2 { font-size: 13px; margin: 0 0 8px; color: var(--muted); font-weight: 600; }
#view3d { position: relative; height: 640px; border-radius: 8px; overflow: hidden;
          background: linear-gradient(var(--view-top), var(--view-bottom)); }
#view3d canvas { display: block; }
#msg3d { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center;
         padding: 24px; text-align: center; color: var(--muted); }
.toggles { display: flex; flex-wrap: wrap; gap: 6px 16px; margin-top: 8px; font-size: 13px; }
#profile { width: 100%; height: 460px; display: block; border-radius: 8px; background: var(--bg); cursor: crosshair; }
#cursor { min-height: 20px; margin-top: 4px; font-size: 12px; color: var(--muted); font-variant-numeric: tabular-nums; }
.legend { display: flex; flex-wrap: wrap; gap: 2px 14px; font-size: 12px; color: var(--muted); }
.sw { display: inline-block; width: 16px; height: 3px; margin-right: 5px; vertical-align: middle; border-radius: 2px; }
.sw.dot { width: 8px; height: 8px; border-radius: 50%; border: 1.5px solid var(--wall); background: none; }
.sw.dash { height: 0; border-top: 2px dotted var(--net); border-radius: 0; }
.controls { display: grid; gap: 10px; margin: 12px 0; }
.ctl label { display: flex; justify-content: space-between; gap: 8px; font-size: 13px; }
.ctl output { color: var(--accent); font-weight: 600; font-variant-numeric: tabular-nums; }
input[type=range] { width: 100%; accent-color: var(--accent); }
table { width: 100%; border-collapse: collapse; font-size: 13px; font-variant-numeric: tabular-nums; }
td { padding: 5px 2px; border-bottom: 1px solid var(--line); vertical-align: top; }
td:last-child { text-align: right; }
.ok { color: var(--ok); } .warn { color: var(--warn); }
.notes { margin-top: 12px; padding-left: 20px; color: var(--muted); font-size: 12.5px; }
.notes li { margin: 3px 0; }
</style>
</head>
<body>
<header>
  <h1>ENR-500 내솥 · 스쿱 뷰어</h1>
  <p>내솥 설계 형상(바닥 평면 + 원호 2개)과 국물 100 L 수면, 스쿱이 벽에서 일정 간격을 두고 벽을 따라가는 자세를 봅니다.</p>
</header>
<main>
  <section class="card">
    <h2>3D · 드래그 회전 · 휠 확대 · 우클릭 드래그 이동</h2>
    <div id="view3d"><div id="msg3d">3D 뷰를 불러오는 중…</div></div>
    <div class="toggles">
      <label><input type="checkbox" id="tCut" checked> 절반 잘라 보기</label>
      <label><input type="checkbox" id="tRings" checked> 설계 단면선</label>
      <label><input type="checkbox" id="tWater" checked> 국물</label>
      <label><input type="checkbox" id="tScoop" checked> 스쿱</label>
      <label><input type="checkbox" id="tPath" checked> TCP 경로 · 피벗</label>
      <label>스쿱 방위
        <select id="sAz">
          <option value="0">0° 먼 쪽 (+x)</option>
          <option value="90">90° 왼쪽 (+y)</option>
          <option value="180">180° 로봇 쪽 (−x)</option>
          <option value="270">270° 오른쪽 (−y)</option>
        </select>
      </label>
    </div>
  </section>
  <section class="card">
    <h2>단면 (r, h) · 마우스를 올리면 경계까지 거리</h2>
    <canvas id="profile"></canvas>
    <div id="cursor"></div>
    <div class="legend" id="legend"></div>
    <div class="controls">
      <div class="ctl"><label for="sH">스쿱을 댈 벽 높이 <output id="oH"></output></label><input type="range" id="sH"></div>
      <div class="ctl"><label for="sC">벽과 남길 여유 <output id="oC"></output></label><input type="range" id="sC"></div>
      <div class="ctl"><label for="sM">테두리에서 떨어진 각도 (벽에 대는 망의 점) <output id="oM"></output></label><input type="range" id="sM"></div>
    </div>
    <table id="readout"></table>
  </section>
</main>
<ul class="notes">
  <li>좌표: 솥 좌표계 (원점 = 회전축과 바닥 평면의 교점, h 위쪽, m). x · y 방향은 로봇 base 와 같습니다 (robot +X = STL +Y).
    빨간 화살표는 로봇 쪽(−x)에서 솥을 향하는 로봇 +X 방향입니다. 로봇까지 거리는 측정 전이라 그리지 않았습니다.</li>
  <li id="noteDesign"></li>
  <li id="noteScoop"></li>
  <li>벽을 따라 움직일 때 스쿱은 피벗(벽 원호의 중심)을 기준으로 통째로 돕니다. 점선이 그때 TCP(망 바닥 중심)가 그리는 경로입니다.</li>
  <li>로봇을 쓰는 동안 솥은 기울이지 않는다고 봅니다 (틸팅 미사용).</li>
</ul>
<script src="https://cdn.jsdelivr.net/npm/three@0.128.0/build/three.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/three@0.128.0/examples/js/controls/OrbitControls.js"></script>
<script>
'use strict';
const DATA = __DATA__;

const $ = (id) => document.getElementById(id);
const cssVar = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();
const mm = (m, digits = 1) => `${(m * 1000).toFixed(digits)} mm`;
const toDeg = (rad) => rad * 180 / Math.PI;
const toRad = (d) => d * Math.PI / 180;
const add = (p, q, k = 1) => [p[0] + k * q[0], p[1] + k * q[1]];
const dirAt = (a) => [Math.sin(a), -Math.cos(a)];      // 원호 중심에서 각도 a 방향 (0 = 바로 아래)
const wrap = (a) => { let x = (a + Math.PI) % (2 * Math.PI); if (x < 0) x += 2 * Math.PI; return x - Math.PI; };

function interp(xs, ys, x) {
  const n = xs.length;
  if (x <= xs[0]) return ys[0];
  if (x >= xs[n - 1]) return ys[n - 1];
  let lo = 0, hi = n - 1;
  while (hi - lo > 1) { const mid = (lo + hi) >> 1; if (xs[mid] <= x) lo = mid; else hi = mid; }
  return ys[lo] + (ys[hi] - ys[lo]) * (x - xs[lo]) / (xs[hi] - xs[lo]);
}

const OP = DATA.operating;
const SUM = DATA.summary;
const SC = DATA.scoop;
const B = DATA.boundary;
const BR = B.map((p) => p[0]);
const BH = B.map((p) => p[1]);
const R_MAX = BR[BR.length - 1];
const H_TOP = BH[BH.length - 1];
const LEVEL = OP.level_h_m;

const PIECES = DATA.pieces.map((p) => {
  if (p.type !== 'arc') return Object.assign({}, p, { pts: [p.start_rh_m, p.end_rh_m] });
  const c = p.center_rh_m;
  const angle = (q) => Math.atan2(q[0] - c[0], -(q[1] - c[1]));
  const a0 = angle(p.start_rh_m), sweep = wrap(angle(p.end_rh_m) - a0);
  const pts = [];
  for (let i = 0; i <= 96; i++) pts.push(add(c, dirAt(a0 + sweep * i / 96), p.radius_m));
  return Object.assign({}, p, { pts });
});
const WALLS = PIECES.filter((p) => p.type === 'arc' && p.name.startsWith('wall_arc'));
const H_WALL = WALLS[WALLS.length - 1].end_rh_m[1];
const wallLabel = (w) => `벽 원호 ${WALLS.indexOf(w) + 1} · R ${(w.radius_m * 1000).toFixed(0)} mm`;
const pieceColor = (p, col) => (p.name === 'wall_arc_1' ? col.arc1 : p.name.startsWith('wall_arc') ? col.arc2
  : p.name === 'bottom' ? col.wall : col.lip);

// ---- kettle_model.py / scoop_path.py 와 같은 계산 ------------------------------
function arcAt(h) {
  const hh = Math.max(0, Math.min(H_WALL, h));
  const w = WALLS.find((p) => hh <= p.end_rh_m[1] + 1e-12) || WALLS[WALLS.length - 1];
  return { w, alpha: Math.acos(Math.max(-1, Math.min(1, (w.center_rh_m[1] - hh) / w.radius_m))) };
}
function nearestOnBoundary(r, h) {
  let best = Infinity, point = B[0];
  for (let i = 0; i < B.length - 1; i++) {
    const ax = B[i][0], ay = B[i][1], dx = B[i + 1][0] - ax, dy = B[i + 1][1] - ay;
    const t = Math.max(0, Math.min(1, ((r - ax) * dx + (h - ay) * dy) / (dx * dx + dy * dy || 1e-18)));
    const px = ax + t * dx, py = ay + t * dy, d = Math.hypot(r - px, h - py);
    if (d < best) { best = d; point = [px, py]; }
  }
  return { d: best, p: point };
}
const isFree = (r, h) => (r <= R_MAX && h >= interp(BR, BH, r)) || h >= H_TOP;
function signedDistance(r, h) {
  const q = nearestOnBoundary(r, h);
  return { d: isFree(r, h) ? q.d : -q.d, p: q.p };
}

function planScoop(hContact, clearance, marginDeg, withCheck = true) {
  const { w, alpha } = arcAt(hContact);
  const Rs = SC.sphere_radius_m, cap = toRad(SC.cap_half_angle_deg);
  const psi = cap - toRad(marginDeg);
  const sphere = add(w.center_rh_m, dirAt(alpha), w.radius_m - Rs - clearance);
  const tilt = alpha - psi;
  const axis = [-Math.sin(tilt), Math.cos(tilt)];
  const side = [-Math.cos(tilt), -Math.sin(tilt)];           // 축에 수직, 솥 중심 쪽 (손잡이)
  const tcp = add(sphere, axis, -Rs);
  const rimBase = add(sphere, axis, -Rs * Math.cos(cap));
  const pose = {
    w, alpha, psi, cap, sphere, tilt, axis, side, tcp,
    contact: add(w.center_rh_m, dirAt(alpha), w.radius_m),
    rimWall: add(rimBase, side, -Rs * Math.sin(cap)),
    rimCenter: add(rimBase, side, Rs * Math.sin(cap)),
    pivotDist: Math.hypot(tcp[0] - w.center_rh_m[0], tcp[1] - w.center_rh_m[1]),
  };
  if (withCheck) pose.clearance = signedDistance(sphere[0], sphere[1]).d - Rs;
  return pose;
}
function tcpPath(clearance, marginDeg) {
  const pts = [];
  for (let h = 0.005; h <= H_WALL - 0.002; h += 0.004) pts.push(planScoop(h, clearance, marginDeg, false).tcp);
  return pts;
}

// ---- 상태와 조작 ------------------------------------------------------------
const state = { hContact: Math.round(LEVEL * 1000) / 1000, clearance: 0.01, margin: 5, cursor: null };
const sH = $('sH'), sC = $('sC'), sM = $('sM');
Object.assign(sH, { min: 5, max: Math.floor(H_WALL * 1000) - 2, step: 1, value: Math.round(state.hContact * 1000) });
Object.assign(sC, { min: 0, max: 40, step: 1, value: Math.round(state.clearance * 1000) });
Object.assign(sM, { min: 0, max: Math.floor(SC.cap_half_angle_deg), step: 1, value: state.margin });
for (const el of [sH, sC, sM]) {
  el.addEventListener('input', () => {
    state.hContact = +sH.value / 1000; state.clearance = +sC.value / 1000; state.margin = +sM.value;
    update();
  });
}
const fitError = DATA.fit.max_error_mm < 0.001 ? '0.001 mm 미만' : `${DATA.fit.max_error_mm} mm`;
$('noteDesign').textContent = `설계 형상은 CAD 벽 링 ${DATA.fit.wall_ring_count}개를 원호 ${DATA.fit.wall_arc_count}개로 맞춘 것입니다 `
  + `(최대 오차 ${fitError}). 국물은 항상 ${OP.soup_volume_L} L 로 봅니다.`;
$('noteScoop').textContent = `스쿱: 테두리 지름 ${(SC.rim_diameter_m * 1000).toFixed(0)} mm, 깊이 ${(SC.depth_m * 1000).toFixed(0)} mm `
  + `→ 구 반경 ${(SC.sphere_radius_m * 1000).toFixed(1)} mm, 구면 범위 망 바닥에서 ${SC.cap_half_angle_deg.toFixed(1)}°. `
  + `손잡이 길이는 STL 값입니다.`;

function renderLegend(col) {
  const items = [
    [`background:${col.wall}`, '바닥'],
    ...WALLS.map((w) => [`background:${pieceColor(w, col)}`, wallLabel(w)]),
    [`background:${col.lip}`, '림 립'],
    ['', 'CAD 링', 'dot'],
    ['', 'TCP 경로', 'dash'],
    [`background:${col.water}`, `국물 ${OP.soup_volume_L} L`],
    [`background:${col.net}`, '스쿱'],
  ];
  $('legend').innerHTML = items.map(([style, text, cls]) =>
    `<span><i class="sw ${cls || ''}" style="${style}"></i>${text}</span>`).join('');
}

function renderReadout(p) {
  const clearOk = p.clearance >= state.clearance - 0.0005;
  const rows = [
    ['국물 (고정)', `${OP.soup_volume_L} L · 수위 ${mm(LEVEL)} · 수면 반경 ${OP.surface_radius_m.toFixed(3)} m`],
    ['닿는 벽', `${wallLabel(p.w)} · 기울기 ${(90 - toDeg(p.alpha)).toFixed(1)}° (0° = 수직)`],
    ['피벗 (원호 중심)', `(${p.w.center_rh_m[0].toFixed(3)}, ${p.w.center_rh_m[1].toFixed(3)}) m`],
    ['스쿱 기울기', `${toDeg(p.tilt) >= 0 ? '+' : ''}${toDeg(p.tilt).toFixed(1)}° ${p.tilt >= 0 ? '(솥 중심 쪽)' : '(벽 쪽)'}`],
    ['TCP · 망 바닥 중심', `(${p.tcp[0].toFixed(3)}, ${p.tcp[1].toFixed(3)}) m · 피벗까지 ${p.pivotDist.toFixed(3)} m`],
    ['망 테두리 높이 (벽 쪽 / 중심 쪽)', `${mm(p.rimWall[1], 0)} / ${mm(p.rimCenter[1], 0)} · 수위 ${mm(LEVEL, 0)}`],
    ['경계까지 실제 최소 여유', `<span class="${clearOk ? 'ok' : 'warn'}">${mm(p.clearance)}${clearOk ? '' : ' · 다른 곳이 더 가깝습니다'}</span>`],
    ['벽에 대는 망의 점', `망 바닥에서 ${toDeg(p.psi).toFixed(1)}° · 테두리까지 ${state.margin}°`],
  ];
  $('readout').innerHTML = rows.map(([k, v]) => `<tr><td>${k}</td><td>${v}</td></tr>`).join('');
}

// ---- 단면 그림 --------------------------------------------------------------
const cv = $('profile');
const ctx = cv.getContext('2d');
const view = {};
function layout() {
  const w = cv.clientWidth, h = cv.clientHeight;
  if (w < 120 || h < 120) return false;            // 아직 화면 배치가 끝나지 않았다
  const dpr = window.devicePixelRatio || 1;
  if (cv.width !== Math.round(w * dpr) || cv.height !== Math.round(h * dpr)) {
    cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
  }
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  const pivotTop = Math.max(...WALLS.map((p) => p.center_rh_m[1]));
  Object.assign(view, { w, h, rMin: -0.02, rMax: Math.max(0.62, R_MAX + 0.04), hMin: -0.03,
                        hMax: Math.max(0.42, H_TOP + 0.04, pivotTop + 0.04), padL: 46, padR: 10, padT: 18, padB: 30 });
  view.s = Math.min((w - view.padL - view.padR) / (view.rMax - view.rMin), (h - view.padT - view.padB) / (view.hMax - view.hMin));
  view.x0 = view.padL - view.rMin * view.s;
  view.y0 = h - view.padB + view.hMin * view.s;
  return true;
}
const X = (r) => view.x0 + r * view.s;
const Y = (h) => view.y0 - h * view.s;
function tracePath(points) {
  ctx.beginPath();
  points.forEach(([r, h], i) => (i ? ctx.lineTo(X(r), Y(h)) : ctx.moveTo(X(r), Y(h))));
}
function dot(pt, radius, color) { ctx.fillStyle = color; ctx.beginPath(); ctx.arc(X(pt[0]), Y(pt[1]), radius, 0, Math.PI * 2); ctx.fill(); }

function draw2D(p, path) {
  if (!layout()) return;
  const col = Object.fromEntries(['ink', 'muted', 'line', 'wall', 'lip', 'water', 'net', 'accent', 'arc1', 'arc2']
    .map((k) => [k, cssVar(`--${k}`)]));
  renderLegend(col);
  ctx.clearRect(0, 0, view.w, view.h);
  ctx.font = '11px system-ui, sans-serif';
  ctx.lineWidth = 1;
  for (let i = 0; i * 0.05 <= view.rMax + 1e-9; i++) {
    const r = i * 0.05;
    ctx.strokeStyle = col.line; ctx.beginPath(); ctx.moveTo(X(r), Y(view.hMin)); ctx.lineTo(X(r), Y(view.hMax)); ctx.stroke();
    if (i % 2 === 0) { ctx.fillStyle = col.muted; ctx.textAlign = 'center'; ctx.fillText(r.toFixed(1), X(r), view.h - view.padB + 16); }
  }
  for (let i = 0; i * 0.05 <= view.hMax + 1e-9; i++) {
    const h = i * 0.05;
    ctx.strokeStyle = col.line; ctx.beginPath(); ctx.moveTo(X(view.rMin), Y(h)); ctx.lineTo(X(view.rMax), Y(h)); ctx.stroke();
    ctx.fillStyle = col.muted; ctx.textAlign = 'right'; ctx.fillText(h.toFixed(2), view.padL - 6, Y(h) + 4);
  }
  ctx.textAlign = 'left'; ctx.fillStyle = col.muted; ctx.fillText('h [m]', 4, 12);
  ctx.textAlign = 'right'; ctx.fillText('r [m]', view.w - view.padR, view.h - 4);

  ctx.save();
  ctx.beginPath(); ctx.rect(view.padL, view.padT, view.w - view.padL - view.padR, view.h - view.padT - view.padB); ctx.clip();
  ctx.setLineDash([5, 4]); ctx.strokeStyle = col.muted;
  ctx.beginPath(); ctx.moveTo(X(0), Y(view.hMin)); ctx.lineTo(X(0), Y(view.hMax)); ctx.stroke();
  ctx.setLineDash([]);

  const soup = B.filter((q) => q[1] <= LEVEL);
  soup.push([OP.surface_radius_m, LEVEL], [0, LEVEL]);
  tracePath(soup); ctx.closePath();
  ctx.globalAlpha = 0.22; ctx.fillStyle = col.water; ctx.fill(); ctx.globalAlpha = 1;
  ctx.strokeStyle = col.water; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(X(0), Y(LEVEL)); ctx.lineTo(X(OP.surface_radius_m), Y(LEVEL)); ctx.stroke();

  ctx.lineJoin = 'round';
  for (const piece of PIECES) { ctx.lineWidth = 2.6; ctx.strokeStyle = pieceColor(piece, col); tracePath(piece.pts); ctx.stroke(); }
  for (const [r, h] of DATA.rings) {
    ctx.strokeStyle = col.wall; ctx.lineWidth = 1.2; ctx.beginPath(); ctx.arc(X(r), Y(h), 3.5, 0, Math.PI * 2); ctx.stroke();
  }
  ctx.font = '11px system-ui, sans-serif'; ctx.textAlign = 'left';
  for (const w of WALLS) {
    const c = w.center_rh_m, color = pieceColor(w, col), on = w === p.w;
    ctx.strokeStyle = color; ctx.lineWidth = on ? 2.5 : 1.5;
    ctx.beginPath(); ctx.moveTo(X(c[0]) - 7, Y(c[1])); ctx.lineTo(X(c[0]) + 7, Y(c[1]));
    ctx.moveTo(X(c[0]), Y(c[1]) - 7); ctx.lineTo(X(c[0]), Y(c[1]) + 7); ctx.stroke();
    ctx.fillStyle = color; ctx.fillText(`피벗 R${(w.radius_m * 1000).toFixed(0)}`, X(c[0]) + 9, Y(c[1]) - 6);
  }

  if ($('tPath').checked) {
    ctx.setLineDash([2, 4]); ctx.strokeStyle = col.net; ctx.lineWidth = 1.5; tracePath(path); ctx.stroke(); ctx.setLineDash([]);
  }
  ctx.setLineDash([4, 4]); ctx.strokeStyle = col.net; ctx.lineWidth = 1;
  tracePath([p.w.center_rh_m, p.contact]); ctx.stroke(); ctx.setLineDash([]);

  const bowl = [];
  for (let i = 0; i <= 60; i++) {
    const t = -p.cap + 2 * p.cap * i / 60;
    bowl.push(add(add(p.sphere, p.axis, -SC.sphere_radius_m * Math.cos(t)), p.side, SC.sphere_radius_m * Math.sin(t)));
  }
  ctx.strokeStyle = col.net; ctx.lineWidth = 3; tracePath(bowl); ctx.stroke();
  ctx.lineWidth = 1; tracePath([p.rimWall, p.rimCenter]); ctx.stroke();
  ctx.lineWidth = 3; tracePath([p.rimCenter, add(p.rimCenter, p.side, SC.handle_length_m)]); ctx.stroke();
  dot(p.tcp, 4.5, col.net);
  dot(p.contact, 3.5, col.accent);

  if (state.cursor) {
    const { r, h } = state.cursor;
    const q = signedDistance(Math.abs(r), h);
    const px = Math.sign(r || 1) * q.p[0];
    ctx.strokeStyle = q.d >= 0 ? col.ink : col.warn; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(X(r), Y(h)); ctx.lineTo(X(px), Y(q.p[1])); ctx.stroke();
    dot([px, q.p[1]], 3, ctx.strokeStyle);
  }
  ctx.restore();
}

cv.addEventListener('mousemove', (e) => {
  if (!view.s) return;
  const rect = cv.getBoundingClientRect();
  const r = (e.clientX - rect.left - view.x0) / view.s;
  const h = (view.y0 - (e.clientY - rect.top)) / view.s;
  state.cursor = { r, h };
  const q = signedDistance(Math.abs(r), h);
  $('cursor').textContent = `r ${r.toFixed(3)} m · h ${h.toFixed(3)} m · 경계까지 ${q.d >= 0 ? '+' : ''}${(q.d * 1000).toFixed(1)} mm `
    + (q.d >= 0 ? '(여유)' : '(벽 속 · 솥 바깥)');
  update();
});
cv.addEventListener('mouseleave', () => { state.cursor = null; $('cursor').textContent = ''; update(); });

// ---- 3D -------------------------------------------------------------------
const three = {};
function meshGeometry(b64) {
  const bin = atob(b64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  const q = new Int16Array(bytes.buffer);
  const pos = new Float32Array(q.length);
  for (let i = 0; i < q.length; i++) pos[i] = q[i] * DATA.scale;
  const geometry = new THREE.BufferGeometry();
  geometry.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geometry.computeVertexNormals();
  return geometry;
}
let azimuth = 0;                                           // 스쿱을 놓을 방위 [rad]. 0 = 로봇 +X (로봇에서 먼 쪽)
const lift = (v) => new THREE.Vector3(v[0] * Math.cos(azimuth), v[0] * Math.sin(azimuth), v[1]);

function init3D() {
  const box = $('view3d');
  if (typeof THREE === 'undefined' || !THREE.OrbitControls) {
    $('msg3d').textContent = '3D 라이브러리(three.js)를 불러오지 못했습니다. 인터넷 연결을 확인하세요. 오른쪽 단면 그림은 그대로 동작합니다.';
    return;
  }
  $('msg3d').remove();
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, preserveDrawingBuffer: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.localClippingEnabled = true;
  box.appendChild(renderer.domElement);

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(38, 1, 0.01, 30);
  camera.up.set(0, 0, 1);
  camera.position.set(1.3, -1.95, 1.2);
  const controls = new THREE.OrbitControls(camera, renderer.domElement);
  controls.target.set(0.1, 0, 0.18);
  controls.update();

  const hemi = new THREE.HemisphereLight(0xffffff, 0x7d8594, 0.9);
  hemi.position.set(0, 0, 1);
  scene.add(hemi);
  const key = new THREE.DirectionalLight(0xffffff, 0.7); key.position.set(1.5, -2.5, 3); scene.add(key);
  const fill = new THREE.DirectionalLight(0xffffff, 0.3); fill.position.set(-2, 2, 1); scene.add(fill);
  scene.add(new THREE.AxesHelper(0.2));
  // 로봇은 −x 쪽 컨트롤 박스 위에 있다. 거리는 측정 전이라 방향만 표시한다.
  scene.add(new THREE.ArrowHelper(new THREE.Vector3(1, 0, 0),
    new THREE.Vector3(-(SUM.rim_top_r_m + 0.35), 0, SUM.rim_top_h_m), 0.25, 0xe03131, 0.06, 0.035));

  const cut = [new THREE.Plane(new THREE.Vector3(0, 1, 0), 0)];   // y >= 0 쪽만 남긴다
  const clipped = [];
  const potMat = new THREE.MeshStandardMaterial({ color: 0xc5cad1, metalness: 0.2, roughness: 0.55, side: THREE.DoubleSide, clippingPlanes: cut });
  clipped.push(potMat);
  scene.add(new THREE.Mesh(meshGeometry(DATA.meshes.pot), potMat));

  const rings = new THREE.Group();
  const arcColors = { wall_arc_1: 0x1971c2, bottom: 0x495057 };
  for (const piece of PIECES) {
    const color = arcColors[piece.name] || (piece.name.startsWith('wall_arc') ? 0xe8590c : 0x868e96);
    const mat = new THREE.LineBasicMaterial({ color });
    for (const side of [1, -1]) {
      rings.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(piece.pts.map(([r, h]) => new THREE.Vector3(side * r, -0.002, h))), mat));
    }
  }
  for (const [r, h] of DATA.rings) {
    const pts = [];
    for (let i = 0; i <= 128; i++) { const a = i / 128 * Math.PI * 2; pts.push(new THREE.Vector3(r * Math.cos(a), r * Math.sin(a), h)); }
    const mat = new THREE.LineBasicMaterial({ color: 0x868e96, transparent: true, opacity: 0.6, clippingPlanes: cut });
    clipped.push(mat);
    rings.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), mat));
  }
  scene.add(rings);

  const waterMat = new THREE.MeshStandardMaterial({ color: 0x339af0, transparent: true, opacity: 0.45, side: THREE.DoubleSide, clippingPlanes: cut, depthWrite: false });
  clipped.push(waterMat);
  const water = new THREE.Mesh(new THREE.CircleGeometry(OP.surface_radius_m, 128), waterMat);
  water.position.z = LEVEL;
  scene.add(water);

  const Rs = SC.sphere_radius_m, cap = toRad(SC.cap_half_angle_deg);
  const scoopMat = new THREE.MeshStandardMaterial({ color: 0x9775fa, metalness: 0.3, roughness: 0.45, side: THREE.DoubleSide });
  const scoop = new THREE.Group();
  scoop.matrixAutoUpdate = false;
  scoop.add(new THREE.Mesh(new THREE.SphereGeometry(Rs, 72, 24, 0, Math.PI * 2, Math.PI - cap, cap), scoopMat));
  const rimR = Rs * Math.sin(cap), rimY = -Rs * Math.cos(cap);
  const rim = new THREE.Mesh(new THREE.TorusGeometry(rimR, 0.004, 8, 96), scoopMat);
  rim.rotation.x = Math.PI / 2; rim.position.y = rimY; scoop.add(rim);
  const handle = new THREE.Mesh(new THREE.CylinderGeometry(SC.handle_diameter_m / 2, SC.handle_diameter_m / 2, SC.handle_length_m, 16), scoopMat);
  handle.rotation.z = -Math.PI / 2;                        // 원통 축 +y → +x (손잡이 방향)
  handle.position.set(rimR + SC.handle_length_m / 2, rimY, 0);
  scoop.add(handle);
  scene.add(scoop);

  const marker = (color, radius) => { const m = new THREE.Mesh(new THREE.SphereGeometry(radius, 16, 12), new THREE.MeshBasicMaterial({ color })); scene.add(m); return m; };
  const tcpDot = marker(0x7048e8, 0.009);
  const contactDot = marker(0xe8590c, 0.007);
  const pivots = WALLS.map((w) => { const m = marker(w.name === 'wall_arc_1' ? 0x1971c2 : 0xe8590c, 0.01); m.position.copy(lift(w.center_rh_m)); return m; });
  const pathLine = new THREE.Line(new THREE.BufferGeometry(), new THREE.LineDashedMaterial({ color: 0x7048e8, dashSize: 0.01, gapSize: 0.008 }));
  const spoke = new THREE.Line(new THREE.BufferGeometry(), new THREE.LineDashedMaterial({ color: 0x7048e8, dashSize: 0.012, gapSize: 0.01 }));
  scene.add(pathLine, spoke);

  const resize = () => {
    const w = box.clientWidth, h = box.clientHeight;
    renderer.setSize(w, h);
    camera.aspect = w / Math.max(h, 1);
    camera.updateProjectionMatrix();
  };
  new ResizeObserver(resize).observe(box);
  resize();
  Object.assign(three, { renderer, camera, cut, clipped, rings, water, scoop, tcpDot, contactDot, pivots, pathLine, spoke });
  (function loop() { requestAnimationFrame(loop); controls.update(); renderer.render(scene, camera); })();
}

function update3D(p, path) {
  if (!three.renderer) return;
  // 스쿱 방위를 지나는 연직면으로 자르고, 카메라 쪽 절반을 없애 안쪽 단면이 보이게 한다.
  const n = new THREE.Vector3(-Math.sin(azimuth), Math.cos(azimuth), 0);
  if (n.dot(three.camera.position) > 0) n.negate();
  three.cut[0].normal.copy(n);
  three.rings.rotation.z = azimuth;
  three.pivots.forEach((m, i) => m.position.copy(lift(WALLS[i].center_rh_m)));
  three.rings.visible = $('tRings').checked;
  three.water.visible = $('tWater').checked;
  const showScoop = $('tScoop').checked, showPath = $('tPath').checked;
  three.scoop.visible = three.tcpDot.visible = three.contactDot.visible = showScoop;
  const xAxis = lift(p.side).normalize(), yAxis = lift(p.axis).normalize();
  const zAxis = new THREE.Vector3().crossVectors(xAxis, yAxis);
  three.scoop.matrix.makeBasis(xAxis, yAxis, zAxis).setPosition(lift(p.sphere));
  three.scoop.matrixWorldNeedsUpdate = true;
  three.tcpDot.position.copy(lift(p.tcp));
  three.contactDot.position.copy(lift(p.contact));
  three.pathLine.visible = three.spoke.visible = showPath;
  for (const m of three.pivots) m.visible = showPath;
  three.pathLine.geometry.dispose();
  three.pathLine.geometry = new THREE.BufferGeometry().setFromPoints(path.map(lift));
  three.pathLine.computeLineDistances();
  three.spoke.geometry.dispose();
  three.spoke.geometry = new THREE.BufferGeometry().setFromPoints([lift(p.w.center_rh_m), lift(p.contact)]);
  three.spoke.computeLineDistances();
}

$('tCut').addEventListener('change', (e) => {
  if (!three.renderer) return;
  for (const m of three.clipped) { m.clippingPlanes = e.target.checked ? three.cut : []; m.needsUpdate = true; }
});
for (const id of ['tRings', 'tWater', 'tScoop', 'tPath']) $(id).addEventListener('change', update);
$('sAz').addEventListener('change', (e) => { azimuth = toRad(+e.target.value); update(); });

function update() {
  const p = planScoop(state.hContact, state.clearance, state.margin, true);
  const path = tcpPath(state.clearance, state.margin);
  $('oH').textContent = `${(state.hContact * 1000).toFixed(0)} mm (수위 ${(LEVEL * 1000).toFixed(0)})`;
  $('oC').textContent = `${(state.clearance * 1000).toFixed(0)} mm`;
  $('oM').textContent = `${state.margin}°`;
  // 한 부분이 실패해도 나머지(수치 표 · 3D)는 갱신되게 한다.
  for (const step of [() => draw2D(p, path), () => renderReadout(p), () => update3D(p, path)]) {
    try { step(); } catch (err) { console.error(err); }
  }
}

init3D();
update();
new ResizeObserver(() => update()).observe(cv);   // 캔버스 크기가 정해지거나 바뀌면 다시 그린다
</script>
</body>
</html>
'''


if __name__ == '__main__':
    main()
