import json

POSITIONS = {
    "SCOOP_W1_DEG"        : [20.71, -83.00, -139.31, -47.68,  90.01,  -69.29],
    "SCOOP_W2_DEG"        : [33.35, -101.85, -154.86, -12.85,  46.13,  -96.14],
    "SCOOP_W3_DEG"        : [24.54,  -92.51, -139.28,  -2.02,  14.10, -129.45],
    "SCOOP_W4_DEG"        : [51.50,  -93.16, -142.88, -25.98,  14.07,  -95.83],
    "SCOOP_SHAKE_DEG"     : [51.50,  -93.16, -142.88, -25.98,  -3.77,  -95.83],
    "DISCHARGE_START_DEG" : [51.50,  -93.16, -142.88, -25.98,  14.07,  -95.83],
    "W5_MOVE"  : [-10.47, -108.61, -145.39, -8.02, 14.07, -95.83],
    "W6_POUR"  : [-10.47, -108.61, -145.39, -8.02, 14.07,  25.01],
    "W7_FINAL" : [0.0, -90.0, -90.0, -90.0, 90.0, 0.0]
}

JSON_PATH = "positions_data_origin.json"

with open(JSON_PATH, "w", encoding="utf-8") as f:
    # indent=4: 사람이 읽기 좋게 들여쓰기 적용
    # ensure_ascii=False: 혹시 모를 한글 깨짐 방지
    json.dump(POSITIONS, f, indent=4, ensure_ascii=False)

print(f"✅ {JSON_PATH} 파일이 성공적으로 생성되었습니다.")