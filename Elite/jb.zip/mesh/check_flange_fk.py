#!/usr/bin/env python3
"""
관절 각도로 플랜지 위치를 직접 계산해 로봇이 보고하는 TCP 자세와 비교한다. 로봇에 명령을 보내지 않는다.

    python3 check_flange_fk.py                  robot_runtime.yaml robot.ip 로봇
    python3 check_flange_fk.py --self-test      로봇 없이 계산 검증

읽는 것
  Primary 30001  KinematicsInfo (컨트롤러에 저장된 MDH 파라미터)
  RTSI 30004     actual_joint_positions, actual_TCP_pose   ← 출력 레시피만 설정 (입력 없음)

계산
  ① 공식 URDF 기구학 (eli_cs_robot_description/config/cs612/default_kinematics.yaml)
  ② SDK KDL 플러그인 + 컨트롤러 MDH
  보고된 TCP 의 회전 (rx, ry, rz) 를 RPY 와 회전벡터로 각각 풀어 FK 회전과 몇 도 차이인지 본다.
  TCP 오프셋이 0 이면 보고된 TCP = 플랜지이므로 위치 · 회전이 FK 와 같아야 한다.
"""

import argparse
import sys
import time
from pathlib import Path

import numpy as np
import yaml

sys.dont_write_bytecode = True

from check_tcp_offset import rotvec_to_matrix, rpy_to_matrix  # noqa: E402

HERE = Path(__file__).resolve().parent
WS = next(p for p in HERE.parents if (p / 'src' / 'RIA_kettle').is_dir())   # 워크스페이스 (이 폴더 위치와 무관)
KINEMATICS_YAML = (WS / 'src' / 'vendor' / 'Elite_Robots_CS_ROS2_Driver' / 'eli_cs_robot_description'
                   / 'config' / 'cs612' / 'default_kinematics.yaml')
JOINTS = ('shoulder', 'upperarm', 'forearm', 'wrist_1', 'wrist_2', 'wrist_3')
CONVENTIONS = {'RPY': rpy_to_matrix, '회전벡터': rotvec_to_matrix}


def rot_z(q):
    c, s = np.cos(q), np.sin(q)
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1.0]])


def urdf_origin(xyz, rpy):
    """URDF <origin>: R = Rz(yaw) · Ry(pitch) · Rx(roll)."""
    T = np.eye(4)
    T[:3, :3] = rpy_to_matrix(rpy)
    T[:3, 3] = xyz
    return T


def urdf_fk(q, kinematics):
    """base_link → flange. 모든 관절은 로컬 z 축 회전, flange 는 wrist_3_link 와 같다."""
    T = np.eye(4)
    for name, angle in zip(JOINTS, q):
        k = kinematics[name]
        T = T @ urdf_origin([k['x'], k['y'], k['z']], [k['roll'], k['pitch'], k['yaw']])
        J = np.eye(4)
        J[:3, :3] = rot_z(angle)
        T = T @ J
    return T


def rotation_angle_deg(Ra, Rb):
    c = (np.trace(Ra.T @ Rb) - 1.0) / 2.0
    return float(np.degrees(np.arccos(np.clip(c, -1.0, 1.0))))


def load_kinematics():
    return yaml.safe_load(KINEMATICS_YAML.read_text(encoding='utf-8'))['kinematics']


# -- 로봇 읽기 ----------------------------------------------------------------------

def read_mdh(cs, ip, timeout_ms=1500):
    primary = cs.PrimaryClientInterface()
    if not primary.connect(ip, 30001):
        raise SystemExit(f'Primary 30001 연결 실패: {ip}')
    try:
        info = cs.KinematicsInfo()
        for _ in range(5):
            if primary.getPackage(info, timeout_ms):
                return [list(info.dh_alpha_), list(info.dh_a_), list(info.dh_d_)]
        raise SystemExit('KinematicsInfo 를 받지 못했습니다.')
    finally:
        primary.disconnect()


def read_rtsi(cs, ip, samples, frequency=125.0, timeout_s=5.0):
    client = cs.RtsiClientInterface()
    client.connect(ip, 30004)
    try:
        if not client.negotiateProtocolVersion():
            raise SystemExit('RTSI 프로토콜 협상 실패')
        recipe = client.setupOutputRecipe(['actual_joint_positions', 'actual_TCP_pose'], frequency)
        if not client.start():
            raise SystemExit('RTSI 스트림 시작 실패')
        rows, deadline = [], time.time() + timeout_s
        while len(rows) < samples and time.time() < deadline:
            recipes = [recipe]
            if client.receiveData(recipes, read_newest=True) > 0 and recipes:
                q = list(recipes[0].getValue('actual_joint_positions'))
                tcp = list(recipes[0].getValue('actual_TCP_pose'))
                if len(q) == 6 and len(tcp) == 6:
                    rows.append((q, tcp))
            time.sleep(0.02)
        client.pause()
        if not rows:
            raise SystemExit('RTSI 데이터를 받지 못했습니다.')
        return rows
    finally:
        client.disconnect()


def sdk_fk(cs, mdh, q):
    try:
        import elite_cs_sdk.elite_cs_sdk_python as native
    except ImportError:
        native = cs
    module_dir = Path(native.__file__).resolve().parent
    libs = sorted(module_dir.glob('*kdl*kinematics*.so'))
    if not libs or not hasattr(native, 'ClassLoader'):
        return None, 'KDL 플러그인을 찾지 못함'
    loader = native.ClassLoader(str(libs[0]))
    if not loader.loadLib():
        return None, 'KDL 플러그인 로드 실패'
    solver = loader.createKinematicsInstance('ELITE::KdlKinematicsPlugin')
    if solver is None:
        return None, 'KDL 인스턴스 생성 실패'
    solver.setMDH(*mdh)
    ok, pose = solver.getPositionFK(q)
    return (list(pose), '') if ok else (None, 'FK 실패')


# -- 보고 --------------------------------------------------------------------------

def compare(label, T_fk, tcp):
    p = np.asarray(tcp[:3])
    print(f'\n[{label}]')
    print(f'  FK 플랜지   x {T_fk[0, 3]:+.4f}  y {T_fk[1, 3]:+.4f}  z {T_fk[2, 3]:+.4f} m')
    print(f'  보고 TCP    x {p[0]:+.4f}  y {p[1]:+.4f}  z {p[2]:+.4f} m   → 위치 차이 {np.linalg.norm(T_fk[:3, 3] - p) * 1000:.2f} mm')
    for name, fn in CONVENTIONS.items():
        print(f'  보고 자세를 {name:4s} 로 풀면 FK 회전과 {rotation_angle_deg(T_fk[:3, :3], fn(tcp[3:])):7.3f}° 차이')
    flip = np.eye(4)
    flip[:3, :3] = rot_z(np.pi)
    d_flip = np.linalg.norm((flip @ T_fk)[:3, 3] - p) * 1000
    print(f'  (참고: base 를 z 축으로 180° 돌린 규약이면 위치 차이 {d_flip:.1f} mm)')


def main():
    from runtime_config import RT
    parser = argparse.ArgumentParser(description='관절 각도 FK 로 플랜지 위치를 계산해 보고된 TCP 와 비교 (읽기 전용).')
    parser.add_argument('--ip', default=RT.robot.ip)
    parser.add_argument('--samples', type=int, default=20)
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()

    kinematics = load_kinematics()
    if args.self_test:
        return self_test(kinematics)

    import elite_cs_sdk as cs
    mdh = read_mdh(cs, args.ip)
    rows = read_rtsi(cs, args.ip, args.samples)
    qs = np.array([r[0] for r in rows])
    tcps = np.array([r[1] for r in rows])
    q, tcp = qs.mean(axis=0), tcps.mean(axis=0)
    print(f'RTSI 샘플 {len(rows)}개, 관절 흔들림 최대 {np.degrees(np.ptp(qs, axis=0).max()):.4f}°, '
          f'TCP 위치 흔들림 최대 {np.ptp(tcps[:, :3], axis=0).max() * 1000:.3f} mm')
    print('관절 [deg]  ' + '  '.join(f'{v:+8.3f}' for v in np.degrees(q)))
    print('컨트롤러 MDH  alpha ' + ' '.join(f'{v:+.4f}' for v in mdh[0]))
    print('              a     ' + ' '.join(f'{v:+.4f}' for v in mdh[1]))
    print('              d     ' + ' '.join(f'{v:+.4f}' for v in mdh[2]))

    compare('① 공식 URDF 기구학', urdf_fk(q, kinematics), tcp)

    pose, error = sdk_fk(cs, mdh, list(q))
    if pose is None:
        print(f'\n[② SDK KDL + 컨트롤러 MDH] 계산 못 함: {error}')
    else:
        print(f'\n[② SDK KDL + 컨트롤러 MDH]')
        print(f'  FK 자세     {np.round(pose, 4).tolist()}')
        print(f'  보고 TCP    {np.round(tcp, 4).tolist()}')
        print(f'  위치 차이 {np.linalg.norm(np.asarray(pose[:3]) - tcp[:3]) * 1000:.2f} mm, '
              f'자세 숫자 차이 최대 {np.abs(np.asarray(pose[3:]) - tcp[3:]).max():.4f} rad')
        T = urdf_fk(q, kinematics)
        for name, fn in CONVENTIONS.items():
            print(f'  SDK FK 자세를 {name:4s} 로 풀면 URDF FK 회전과 {rotation_angle_deg(T[:3, :3], fn(pose[3:])):7.3f}° 차이')
    return 0


def self_test(kinematics):
    ok = True
    q0 = np.zeros(6)
    T = urdf_fk(q0, kinematics)
    k = kinematics
    # 영점 자세: 어깨 높이 + 두 링크 길이가 x 방향으로 뻗는다 (UR 계열 규약)
    expected = np.array([k['forearm']['x'] + k['wrist_1']['x'], None, None], dtype=object)
    good = abs(T[0, 3] - expected[0]) < 1e-9
    print(f'  [{"OK" if good else "FAIL"}] 영점 자세 플랜지 x = forearm.x + wrist_1.x ({T[0, 3]:+.4f} m)')
    ok &= good
    rng = np.random.default_rng(3)
    R = rotvec_to_matrix(rng.normal(size=3))
    good = abs(rotation_angle_deg(R, R)) < 1e-6 and abs(rotation_angle_deg(np.eye(3), rot_z(0.5)) - np.degrees(0.5)) < 1e-9
    print(f'  [{"OK" if good else "FAIL"}] 회전 각도 차이 계산')
    ok &= good
    q = rng.uniform(-np.pi, np.pi, 6)
    Rfk = urdf_fk(q, kinematics)[:3, :3]
    good = np.allclose(Rfk.T @ Rfk, np.eye(3)) and abs(np.linalg.det(Rfk) - 1) < 1e-9
    print(f'  [{"OK" if good else "FAIL"}] 임의 관절각에서 FK 회전행렬이 직교 · 오른손')
    ok &= good
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
