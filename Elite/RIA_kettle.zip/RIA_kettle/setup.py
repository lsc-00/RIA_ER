import os
from glob import glob

from setuptools import find_packages, setup

package_name = 'ria_kettle'

setup(
    name=package_name,
    version='0.1.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join('share', package_name, 'config'), glob('config/*.yaml')),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='jongbeom',
    maintainer_email='jb2292@naver.com',
    description='ENR-500 국솥 내솥 형상 모델과 스쿱 벽 따라가기 경로',
    license='Apache-2.0',
    entry_points={'console_scripts': []},
)
