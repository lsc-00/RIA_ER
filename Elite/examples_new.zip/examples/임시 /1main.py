import flet as ft
from UI import build_ui

# ==============================================================================
# 하이퍼파라미터 기본값 (여기서만 수정하면 됩니다)
# ==============================================================================
DEFAULT_PARAMS = {
    "STIR_RADIUS_CM": 31.0,   # 교반 반경 (cm) - 최대 32.5
    "STIR_DEPTH_CM":   1.0,   # 교반 깊이 (cm)
    "X_BIAS_CM":       0.0,   # 앞뒤 보정 (cm)
    "Y_BIAS_CM":       5.0,   # 좌우 보정 (cm)
}

if __name__ == "__main__":
    ft.run(
        lambda page: build_ui(page, DEFAULT_PARAMS),
        assets_dir="assets",
        view=ft.AppView.WEB_BROWSER,
        port=8550
    )