import flet as ft
import datetime
import threading
import time
import math
import struct
import elite_cs_sdk as cs
import os

# ==============================================================================
# [1] 로봇 설정 및 데이터
# ==============================================================================
ROBOT_IP = "192.168.1.200"

HOME_POS_DEG = [0.0, -90.0, -90.0, -90.0, 90.0, 0.0]
CENTER_XYZ = [0.80, -0.0, 0.3]
START_XYZ  = [0.50, -0.0, 0.3]
CENTER_JOINT_DEG = [20.71, -83.00, -139.31, -47.68, 90.01, -69.29]

CIRCLE_VEL = 3.0
CIRCLE_ACC = 2.5
SCOOP_VEL = 0.8
SCOOP_ACC = 1.0
SCOOP_BLEND = 0.05
SHAKE_VEL = 13.0
SHAKE_ACC = 15.0
SHAKE_BLEND = 0.01

SCOOP_W1_DEG = [20.71, -83.00, -139.31, -47.68, 90.01, -69.29]
SCOOP_W2_DEG = [33.35, -101.85, -154.86, -12.85, 46.13, -96.14]
SCOOP_W3_DEG = [24.54, -92.51, -139.28, -2.02, 14.10, -129.45]
SCOOP_W4_DEG = [51.50, -93.16, -142.88, -25.98, 14.07, -95.83]
SCOOP_SHAKE_DEG = [51.50, -93.16, -142.88, -25.98, -3.77, -95.83]

DISCHARGE_VEL = 1.0
DISCHARGE_ACC = 0.8
DISCHARGE_BLEND = 0.05
DISCHARGE_START_DEG = [51.50, -93.16, -142.88, -25.98, 14.07, -95.83]
W5_MOVE = [-10.47, -108.61, -145.39, -8.02, 14.07, -95.83]
W6_POUR = [-10.47, -108.61, -145.39, -8.02, 14.07, 25.01]
W7_FINAL = [0.0, -90.0, -90.0, -90.0, 90.0, 0.0]

def deg_to_rad(deg): return deg * (math.pi / 180.0)
def joints_to_str(joints_deg): return "[" + ", ".join([f"{deg_to_rad(j):.5f}" for j in joints_deg]) + "]"
def to_str(p): return "[" + ", ".join([f"{x:.5f}" for x in p]) + "]"

class CartesianInfoPackage(cs.PrimaryPackage):
    def __init__(self): super().__init__(4); self.pose = None
    def parser(self, data: bytes):
        try: self.pose = list(struct.unpack_from('>iBdddddddddddd', data)[2:8])
        except: self.pose = None

def get_current_pose(primary):
    pkg = CartesianInfoPackage()
    return pkg.pose if primary.getPackage(pkg, 1000) and pkg.pose else None

class RobotController:
    def __init__(self, log_callback):
        self.log = log_callback
        self.primary = cs.PrimaryClientInterface()
        self.dashboard = cs.DashboardClientInterface()
        self.pose_pkg = CartesianInfoPackage()

    def connect_primary(self):
        try: return self.primary.connect(ROBOT_IP, 30001)
        except: return False

    def disconnect_primary(self):
        try: self.primary.disconnect()
        except: pass
    
    def get_pose(self):
        if self.primary.getPackage(self.pose_pkg, 1000) and self.pose_pkg.pose:
            return self.pose_pkg.pose
        return None

    def dashboard_power_on(self):
        if not self.dashboard.connect(ROBOT_IP, 29999):
            self.log("❌ 대시보드 연결 실패")
            return False
        self.log("⚡ 로봇 전원 켜는 중...")
        self.dashboard.powerOn()
        time.sleep(7) 
        self.log("🔓 브레이크 해제 중...")
        self.dashboard.brakeRelease()
        time.sleep(5) 
        self.dashboard.disconnect()
        self.log("✅ 로봇 부팅 완료")
        return True

    def dashboard_power_off(self):
        if not self.dashboard.connect(ROBOT_IP, 29999):
            return False
        self.log("📴 로봇 전원 끄는 중...")
        self.dashboard.powerOff()
        time.sleep(2)
        self.dashboard.disconnect()
        return True

    def emergency_stop(self):
        self.log("🚨 [EMERGENCY STOP] 비상 정지 명령 전송!")
        self.primary.sendScript("stopj(10.0)")

    def run_home_pose(self):
        self.log("🚀 시스템 시작: 홈 위치로 이동 중...")
        self.primary.sendScript(f"movej({joints_to_str(HOME_POS_DEG)}, a=0.5, v=0.3)")
        time.sleep(6)
        self.log("✅ 홈 위치 도착 완료")

    def run_init_pose(self):
        self.log("🚀 [초기 위치] 이동 중...")
        self.primary.sendScript(f"movej({joints_to_str(CENTER_JOINT_DEG)}, a=0.8, v=0.5)")
        time.sleep(5)
        self.log("✅ 초기 위치 이동 완료")

    def run_stirring(self):
        self.log("🔄 [교반] 경로 계산 및 실행...")
        self.primary.sendScript(f"movej({joints_to_str(CENTER_JOINT_DEG)}, a=0.8, v=0.5)")
        time.sleep(4)
        pose = self.get_pose()
        if not pose:
            self.log("❌ 자세 읽기 실패"); return
        fix_rot = pose[3:]
        p_c, p_s = CENTER_XYZ + fix_rot, START_XYZ + fix_rot
        r = math.sqrt((p_s[0]-p_c[0])**2 + (p_s[1]-p_c[1])**2)
        ang = math.atan2(p_s[1]-p_c[1], p_s[0]-p_c[0])
        pts = [[p_c[0]+r*math.cos(ang-2*math.pi*i/36), p_c[1]+r*math.sin(ang-2*math.pi*i/36), p_s[2]] + fix_rot for i in range(73)]
        br = max(0.001, min((2*math.pi*r)/36*0.5, 0.05))
        cmds = ["def run_stir():"]
        cmds.append(f"  movel({to_str(pts[0])}, a=1.0, v=0.8)")
        cmds += [f"  movep({to_str(pt)}, a={CIRCLE_ACC}, v={CIRCLE_VEL}, r={br})" for pt in pts[1:]]
        cmds.append(f"  movep({to_str(pts[-1])}, a={CIRCLE_ACC}, v={CIRCLE_VEL}, r=0.0)")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        time.sleep(5); self.log("✅ 교반 명령 전송 완료")

    def run_scooping(self):
        self.log("🥄 [뜨기] 작업 실행")
        cmds = ["def run_scoop():"]
        cmds.append(f"  movej({joints_to_str(SCOOP_W1_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL})")
        cmds.append(f"  movej({joints_to_str(SCOOP_W2_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r=0.0)")
        cmds.append("  sleep(2.0)")
        cmds.append(f"  movej({joints_to_str(SCOOP_W3_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r={SCOOP_BLEND})")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        time.sleep(8)

    def run_shaking(self):
        self.log("👋 [털기] 작업 실행")
        cmds = ["def run_shake():"]
        cmds.append(f"  movej({joints_to_str(SCOOP_W4_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r=0.0)")
        for _ in range(4):
            cmds.append(f"  movej({joints_to_str(SCOOP_SHAKE_DEG)}, a={SHAKE_ACC}, v={SHAKE_VEL}, r={SHAKE_BLEND})")
            cmds.append(f"  movej({joints_to_str(SCOOP_W4_DEG)}, a={SHAKE_ACC}, v={SHAKE_VEL}, r={SHAKE_BLEND})")
        cmds.append(f"  movej({joints_to_str(SCOOP_W4_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r=0.0)")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        time.sleep(4)

    def run_discharge(self):
        self.log("🚚 [배출] 작업 실행")
        cmds = ["def run_discharge():"]
        cmds.append(f"  movej({joints_to_str(DISCHARGE_START_DEG)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append(f"  movej({joints_to_str(W5_MOVE)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r={DISCHARGE_BLEND})")
        cmds.append(f"  movej({joints_to_str(W6_POUR)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append("  sleep(2.0)")
        cmds.append(f"  movej({joints_to_str(W5_MOVE)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r={DISCHARGE_BLEND})")
        cmds.append(f"  movej({joints_to_str(DISCHARGE_START_DEG)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append(f"  movej({joints_to_str(W7_FINAL)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        time.sleep(12); self.log("✅ 배출 작업 완료")

    def run_integrated_test(self):
        self.log("▶ [전체 시퀀스] 실행")
        self.primary.sendScript(f"movej({joints_to_str(CENTER_JOINT_DEG)}, a=0.8, v=0.5)")
        time.sleep(4)
        pose = self.get_pose()
        if not pose: return
        fix_rot = pose[3:]
        p_c, p_s = CENTER_XYZ + fix_rot, START_XYZ + fix_rot
        r = math.sqrt((p_s[0]-p_c[0])**2 + (p_s[1]-p_c[1])**2)
        ang = math.atan2(p_s[1]-p_c[1], p_s[0]-p_c[0])
        pts = [[p_c[0]+r*math.cos(ang-2*math.pi*i/36), p_c[1]+r*math.sin(ang-2*math.pi*i/36), p_s[2]] + fix_rot for i in range(73)]
        br = max(0.001, min((2*math.pi*r)/36*0.5, 0.05))

        cmds = ["def run_fry_process():"]
        # Stir
        cmds.append(f"  movel({to_str(pts[0])}, a=1.0, v=0.8)")
        cmds += [f"  movep({to_str(pt)}, a={CIRCLE_ACC}, v={CIRCLE_VEL}, r={br})" for pt in pts[1:]]
        cmds.append(f"  movep({to_str(pts[-1])}, a={CIRCLE_ACC}, v={CIRCLE_VEL}, r=0.0)")
        # Scoop
        cmds.append(f"  movej({joints_to_str(SCOOP_W1_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL})")
        cmds.append(f"  movej({joints_to_str(SCOOP_W2_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r=0.0)")
        cmds.append("  sleep(2.0)")
        cmds.append(f"  movej({joints_to_str(SCOOP_W3_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r={SCOOP_BLEND})")
        # Shake
        cmds.append(f"  movej({joints_to_str(SCOOP_W4_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r=0.0)")
        for _ in range(4):
            cmds.append(f"  movej({joints_to_str(SCOOP_SHAKE_DEG)}, a={SHAKE_ACC}, v={SHAKE_VEL}, r={SHAKE_BLEND})")
            cmds.append(f"  movej({joints_to_str(SCOOP_W4_DEG)}, a={SHAKE_ACC}, v={SHAKE_VEL}, r={SHAKE_BLEND})")
        cmds.append(f"  movej({joints_to_str(SCOOP_W4_DEG)}, a={SCOOP_ACC}, v={SCOOP_VEL}, r=0.0)")
        # Discharge
        cmds.append(f"  movej({joints_to_str(DISCHARGE_START_DEG)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append(f"  movej({joints_to_str(W5_MOVE)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r={DISCHARGE_BLEND})")
        cmds.append(f"  movej({joints_to_str(W6_POUR)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append("  sleep(2.0)")
        cmds.append(f"  movej({joints_to_str(W5_MOVE)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r={DISCHARGE_BLEND})")
        cmds.append(f"  movej({joints_to_str(DISCHARGE_START_DEG)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append(f"  movej({joints_to_str(W7_FINAL)}, a={DISCHARGE_ACC}, v={DISCHARGE_VEL}, r=0.0)")
        cmds.append("end")
        self.primary.sendScript("\n".join(cmds))
        self.log("🏁 전체 시퀀스 명령 전송 완료")
        time.sleep(30)

# ==============================================================================
# [3] UI 메인 코드 (Flet)
# ==============================================================================
def main(page: ft.Page):
    # 1. 윈도우 설정
    page.title = "ENERTEC Control Panel"
    page.window.width = 1200
    page.window.height = 800
    page.padding = 0
    page.theme_mode = ft.ThemeMode.LIGHT
    page.bgcolor = ft.Colors.BLUE_GREY_50
    page.theme = ft.Theme(font_family="NanumGothic")

    # 윈도우 중앙 정렬 및 닫기 방지
    page.window.center()
    page.window.prevent_close = True 
    page.vertical_alignment = ft.MainAxisAlignment.CENTER
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER

    global log_list
    log_list = ft.ListView(expand=True, spacing=5, padding=10, auto_scroll=True)

    def log_handler(msg):
        ts = datetime.datetime.now().strftime("[%H:%M:%S]")
        if log_list.page:
            log_list.controls.append(ft.Text(f"{ts} {msg}", size=14, color=ft.Colors.BLACK87))
            try: page.update()
            except: pass

    robot = RobotController(log_handler)

    def direct_shutdown():
        page.snack_bar = ft.SnackBar(ft.Text("종료 중..."), open=True)
        page.update()
        def _shutdown():
            robot.dashboard_power_off()
            page.window.destroy()
            os._exit(0)
        threading.Thread(target=_shutdown, daemon=True).start()

    page.on_window_event = lambda e: direct_shutdown() if e.data == "close" else None

    def run_task(task_type):
        def _task():
            if task_type == "BOOTING":
                if robot.dashboard_power_on():
                    show_control()
                    time.sleep(1)
                    run_task("HOME")
                else:
                    log_handler("❌ 부팅 실패")
                return

            if not robot.connect_primary():
                log_handler("❌ 로봇 연결 실패")
                return
            try:
                if task_type == "INIT": robot.run_init_pose()
                elif task_type == "STIR": robot.run_stirring()
                elif task_type == "SCOOP": robot.run_scooping()
                elif task_type == "SHAKE": robot.run_shaking()
                elif task_type == "DISCHARGE": robot.run_discharge()
                elif task_type == "ALL": robot.run_integrated_test()
                elif task_type == "HOME": robot.run_home_pose()
                elif task_type == "STOP": robot.emergency_stop()
            except Exception as e: log_handler(f"⚠️ 에러: {e}")
            finally: robot.disconnect_primary()
        threading.Thread(target=_task, daemon=True).start()

    def on_btn_click(e):
        txt = e.control.content.controls[1].value if isinstance(e.control.content, ft.Row) else "ALL"
        task = "ALL"
        if "초기" in txt: task = "INIT"
        elif "교반" in txt: task = "STIR"
        elif "뜨기" in txt: task = "SCOOP"
        elif "털기" in txt: task = "SHAKE"
        elif "배출" in txt: task = "DISCHARGE"
        elif "비상" in txt: task = "STOP"
        run_task(task)

    def btn(text, icon, color):
        return ft.ElevatedButton(
            content=ft.Row([ft.Icon(icon, size=24, color="white"), ft.Text(text, size=18, weight="bold", color="white")], spacing=20),
            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=10), bgcolor=color, padding=20),
            width=float("inf"), height=70, on_click=on_btn_click
        )

    def build_control_panel():
        left_col = ft.Column([
            ft.Text("수동 제어", size=18, weight="bold"),
            btn("1. 초기 위치", ft.Icons.INPUT, ft.Colors.INDIGO_500),
            btn("2. 교반 작업", ft.Icons.LOOP, ft.Colors.BLUE_500),
            btn("3. 뜨기 작업", ft.Icons.ARROW_UPWARD, ft.Colors.CYAN_600),
            btn("4. 털기 작업", ft.Icons.VIBRATION, ft.Colors.TEAL_500),
            btn("5. 배출 / 이송", ft.Icons.OUTPUT, ft.Colors.GREEN_600)
        ], spacing=15)

        right_col = ft.Column([
            ft.Text("자동 제어 & 상태", size=18, weight="bold"),
            ft.Container(
                content=ft.ElevatedButton(
                    content=ft.Row(
                        [ft.Icon(ft.Icons.WARNING_AMBER_ROUNDED, size=40, color="white"), 
                         ft.Text("비상 정지 (STOP)", size=24, weight="bold", color="white")],
                        alignment=ft.MainAxisAlignment.CENTER
                    ),
                    style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=10), bgcolor=ft.Colors.RED_700),
                    width=float("inf"), height=80, on_click=on_btn_click
                ), padding=ft.padding.only(bottom=10)
            ),
            ft.Container(
                content=ft.ElevatedButton(
                    content=ft.Column([
                        ft.Icon(ft.Icons.PLAY_CIRCLE_FILLED, size=60, color="white"),
                        ft.Text("전체 시퀀스 자동 동작", size=26, weight="bold", color="white"),
                        ft.Text("AUTO SEQUENCE START", size=14, color="white70")
                    ], alignment="center", horizontal_alignment="center"),
                    style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=20), bgcolor=ft.Colors.RED_600),
                    width=float("inf"), height=200, on_click=on_btn_click
                ), padding=ft.padding.only(bottom=20)
            ),
            ft.Container(
                content=log_list,
                bgcolor="white", border_radius=10, border=ft.border.all(1, ft.Colors.GREY_300),
                expand=True, padding=10
            )
        ], spacing=15, expand=True)

        return ft.Row([
            ft.Container(left_col, expand=1, padding=30, bgcolor="white", border_radius=15, margin=10),
            ft.Container(right_col, expand=1, padding=30, border_radius=15)
        ], expand=True)

    def show_booting_screen():
        page.clean()
        page.add(
            # [수정] FittedBox 제거 및 expand 활용으로 반응형 구현
            ft.Container(
                content=ft.Column([
                    ft.ProgressRing(width=80, height=80, stroke_width=8, color=ft.Colors.BLUE),
                    ft.Text("시스템 부팅 중...", size=24, weight="bold", color=ft.Colors.BLUE_GREY_700),
                    ft.Text("로봇 전원을 켜고 브레이크를 해제하고 있습니다.", size=16, color=ft.Colors.GREY)
                ], alignment="center", horizontal_alignment="center"),
                alignment=ft.alignment.center,
                expand=True
            )
        )
        page.update()
        run_task("BOOTING")

    def show_home(e=None):
        page.clean()
        page.add(
            # [수정] 반응형 배경 및 중앙 정렬
            ft.Stack([
                ft.Image(src="Robot.png", fit=ft.ImageFit.COVER, expand=True, opacity=0.3),
                ft.Container(
                    content=ft.Column([
                        ft.Text("RIA Lab", size=60, weight="bold"),
                        ft.Text("협동 로봇 자동 조리 시스템", size=30, weight="w900"),
                        ft.Container(height=50),
                        ft.ElevatedButton("시작하기", style=ft.ButtonStyle(bgcolor=ft.Colors.BLUE_600, color="white", padding=30), 
                            on_click=lambda _: show_booting_screen()),
                        ft.Container(height=20),
                        ft.ElevatedButton("종료하기", style=ft.ButtonStyle(bgcolor=ft.Colors.RED_400, color="white", padding=30), 
                            on_click=lambda _: direct_shutdown())
                    ], alignment="center", horizontal_alignment="center"),
                    alignment=ft.alignment.center
                )
            ], expand=True)
        )
        page.update()

    def show_control(e=None):
        page.clean()
        header = ft.Container(
            content=ft.Row([
                ft.Text("RIA Lab", size=24, weight="bold"),
                ft.Container(expand=True),
                clock_text,
                ft.IconButton(ft.Icons.HOME, on_click=show_home),
                ft.IconButton(ft.Icons.CLOSE, icon_color="red", on_click=lambda _: direct_shutdown())
            ]), padding=20, bgcolor="white"
        )
        page.add(ft.Column([header, ft.Container(build_control_panel(), expand=True, bgcolor=ft.Colors.BLUE_GREY_50)], expand=True))
        page.update()

    clock_text = ft.Text("", size=16)
    def update_clock():
        while True:
            clock_text.value = datetime.datetime.now().strftime("현재시간 %H:%M:%S")
            try: page.update()
            except: break
            time.sleep(1)
    
    threading.Thread(target=update_clock, daemon=True).start()
    show_home()

ft.app(target=main, assets_dir="assets")