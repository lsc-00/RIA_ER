# ui/control_panel.py
# 좌측 수동 제어 버튼 패널을 담당합니다.
# 버튼 추가/수정/순서 변경은 config.py의 MANUAL_BUTTONS에서 하세요.

import flet as ft
from config import MANUAL_BUTTONS, LAYOUT, LABELS
from ui.state import AppState
from ui.param_panel import build_param_panel


def build_control_panel(
    state: AppState,
    page: ft.Page,
    on_run_task,
    on_reset_params,
    on_teaching=None,
) -> ft.Container:

    def _handle_click(task_type):
        if task_type == "TEACHING" and on_teaching:
            on_teaching()
        else:
            on_run_task(task_type)

    def make_btn(cfg: dict) -> ft.FilledButton:
        task = cfg["task"]
        b = ft.FilledButton(
            content=ft.Row([
                ft.Icon(cfg["icon"], size=24, color="white"),
                ft.Text(
                    cfg["label"],
                    size=LAYOUT["btn_font_size"],
                    weight="bold",
                    color="white",
                ),
            ], spacing=20),
            style=ft.ButtonStyle(
                shape=ft.RoundedRectangleBorder(radius=LAYOUT["btn_border_radius"]),
                bgcolor=cfg["color"],
                padding=20,
            ),
            width=float("inf"),
            height=LAYOUT["manual_btn_height"],
            on_click=lambda e, t=task: _handle_click(t),
        )
        state.register_action_button(b)
        return b

    def on_reset():
        state.reset_params()
        on_reset_params()  # 화면 새로고침

    buttons = [make_btn(cfg) for cfg in MANUAL_BUTTONS]

    return ft.Container(
        content=ft.Column([
            ft.Text(LABELS["manual_section"], size=18, weight="bold"),
            *buttons,
            build_param_panel(state, page, on_reset),
        ], spacing=15, scroll=ft.ScrollMode.AUTO),
        expand=1,
        padding=LAYOUT["panel_padding"],
        bgcolor="white",
        border_radius=LAYOUT["panel_border_radius"],
        margin=10,
    )