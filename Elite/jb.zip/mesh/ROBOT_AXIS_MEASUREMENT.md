# 로봇 TCP로 솥 중심 측정

카메라로 대략적인 중심을 구한 뒤, TCP가 보정된 단단한 포인터나 반경을 아는
구형 프로브로 내벽을 여러 점 측정해 솥 회전 중심의 로봇 base `x, y`를 구한다.
실제 조리망은 휘고 접촉점이 자세에 따라 바뀌므로 중심 측정용으로 권장하지 않는다.

```bash
cd ~/cs612_ws/src/vendor/dev_log/jb/mesh
./measure_kettle_axis_robot.sh                         # 뾰족한 TCP 포인터
./measure_kettle_axis_robot.sh --probe-radius-mm 3    # 반경 3 mm 구형 프로브
```

브라우저에서 `http://127.0.0.1:5001`을 연다. 이 프로그램은 RTSI의 현재 TCP를
읽기만 하며 로봇 이동 명령을 보내지 않는다. 기존 조그 화면이나 티치 방식으로
프로브를 천천히 내벽에 접촉시키고, 모션이 완전히 멈춘 뒤 `현재 TCP 기록`을 누른다.

- 기준 높이는 100 L 수면과 같은 로봇 base `z ≈ 0.300103 m`이다.
- 최소 6점, 가능하면 8~12점을 솥 둘레 120° 이상에 넓게 기록한다.
- CAD 반경 고정 원과 자유 반경 원을 동시에 맞추며 프로브 반경을 보정한다.
- 점 개수, 분포각, RMS, 반경 차이, z 높이 조건을 모두 통과해야 적용 버튼이 켜진다.
- 적용하면 `kettle_axis_robot_measurement.yaml`에 원본 측정을 남기고
  `kettle_profile.yaml`의 `placement.axis_xy_in_base_m`만 갱신한다.
- STL의 90° yaw는 중심 위치에 적용하지 않는다. robot base x, y를 그대로 쓴다.

자동 접촉이나 힘 감지는 하지 않는다. 처음 접근은 저속으로 하고 접촉할 때마다
조그 버튼을 놓아 로봇이 정지했는지 확인한다.

## 품질 기준만 시험

로봇 없이 가상 측정점으로 중심 계산과 웹 API를 검사한다.

```bash
./measure_kettle_axis_robot.sh --self-test
```

## 옵션

```text
--ip 192.168.0.100       로봇 IP
--port 5001              웹 포트
--probe-radius-mm 3      구형 프로브 반경
--wall-radius-mm 474.14  측정 높이의 CAD 내벽 반경
--z-m 0.300103           측정할 robot base z
```

다른 높이에서 측정할 경우 `--z-m`과 그 높이에 해당하는 `--wall-radius-mm`를
반드시 함께 지정해야 한다.
