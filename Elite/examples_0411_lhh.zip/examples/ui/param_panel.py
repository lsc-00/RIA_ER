# ui/param_panel.py
# 파라미터 슬라이더 패널을 담당합니다.
# 슬라이더 항목 추가/수정은 config.py의 PARAM_SLIDERS에서 하세요.

import flet as ft
from config import PARAM_SLIDERS, LABELS
from ui.state import AppState


def build_param_panel(
    state: AppState,
    page: ft.Page,
    on_reset,
) -> ft.Container:

    def fmt(v: float, unit: str) -> str:
        """단위에 따라 표시 형식 결정: % → 소수점 없음, 나머지 → 1자리"""
        return f"{v:.0f} {unit}" if unit == "%" else f"{v:.1f} {unit}"

    def fmt_input(v: float, unit: str) -> str:
        return f"{v:.0f}" if unit == "%" else f"{v:.1f}"

    def make_slider(cfg: dict) -> ft.Control:
        key     = cfg["key"]
        min_val = cfg["min"]
        max_val = cfg["max"]
        unit    = cfg["unit"]
        section = cfg.get("section")   # 섹션 헤더 문자열 or None

        value_text = ft.Text(
            fmt(state.current_params[key], unit),
            size=14, width=90,
        )
        input_field = ft.TextField(
            value=fmt_input(state.current_params[key], unit),
            width=85, height=40, text_size=14,
            content_padding=ft.padding.symmetric(horizontal=8, vertical=4),
            border_radius=8,
            suffix=ft.Text(unit, size=11, color=ft.Colors.BLUE_GREY_400),
        )
        slider = ft.Slider(
            value=state.current_params[key],
            min=min_val, max=max_val,
            divisions=cfg["divisions"],
            expand=True,
        )

        def on_slider_change(e):
            v = round(e.control.value, 1)
            state.current_params[key] = v
            value_text.value  = fmt(v, unit)
            input_field.value = fmt_input(v, unit)
            page.update()

        def on_input_submit(e):
            try:
                v = float(input_field.value)
                v = max(min_val, min(max_val, round(v, 1)))
                state.current_params[key] = v
                slider.value      = v
                value_text.value  = fmt(v, unit)
                input_field.value = fmt_input(v, unit)
            except ValueError:
                input_field.value = fmt_input(state.current_params[key], unit)
            page.update()

        slider.on_change      = on_slider_change
        input_field.on_submit = on_input_submit
        input_field.on_blur   = on_input_submit

        # 슬라이더 색상: 전체 배율은 강조색, 나머지는 기본
        is_speed_factor = (key == "SPEED_FACTOR_PCT")
        label_color = ft.Colors.DEEP_ORANGE_600 if is_speed_factor else ft.Colors.BLUE_GREY_700
        bg_color    = ft.Colors.ORANGE_50        if is_speed_factor else ft.Colors.BLUE_GREY_50

        slider_card = ft.Container(
            content=ft.Column([
                ft.Text(cfg["label"], size=13, weight="bold", color=label_color),
                ft.Row(
                    [slider, input_field, value_text],
                    vertical_alignment=ft.CrossAxisAlignment.CENTER,
                ),
            ], spacing=4),
            bgcolor=bg_color,
            border_radius=8,
            padding=ft.padding.symmetric(horizontal=12, vertical=8),
        )

        # 섹션 헤더가 있으면 구분선 + 헤더를 위에 붙임
        if section:
            return ft.Column([
                ft.Container(
                    content=ft.Row([
                        ft.Icon(ft.Icons.SPEED, size=16, color=ft.Colors.DEEP_ORANGE_600),
                        ft.Text(
                            section,
                            size=14, weight="bold",
                            color=ft.Colors.DEEP_ORANGE_600,
                        ),
                    ], spacing=6),
                    margin=ft.margin.only(top=6, bottom=2),
                ),
                ft.Divider(height=1, color=ft.Colors.ORANGE_200),
                slider_card,
            ], spacing=4)

        return slider_card

    slider_widgets = [make_slider(cfg) for cfg in PARAM_SLIDERS]

    return ft.Container(
        content=ft.Column([
            ft.Row([
                ft.Icon(ft.Icons.TUNE, color=ft.Colors.BLUE_700),
                ft.Text(LABELS["param_section"], size=16, weight="bold", color=ft.Colors.BLUE_700),
            ]),
            ft.Divider(height=1),
            *slider_widgets,
            ft.Divider(height=1),
            ft.FilledButton(
                content=ft.Row([
                    ft.Icon(ft.Icons.RESTART_ALT, color="white"),
                    ft.Text(LABELS["param_reset_btn"], color="white", size=13),
                ], spacing=8),
                style=ft.ButtonStyle(bgcolor=ft.Colors.BLUE_GREY_400),
                on_click=lambda e: on_reset(),
            ),
        ], spacing=10),
        bgcolor="white",
        border_radius=15,
        padding=20,
        margin=ft.margin.only(top=10),
    )