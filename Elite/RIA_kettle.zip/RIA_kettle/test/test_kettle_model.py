import numpy as np
import pytest

from ria_kettle import KettleModel, ScoopGeometry, WallScoopPlanner, find_config
from ria_kettle import kettle_model, scoop_path


@pytest.fixture(scope='module')
def kettle():
    return KettleModel.from_yaml(water_surface_z=None)      # 설계 수위 100 L 기준 (지금 수면은 water_level.yaml 마다 다름)


@pytest.fixture(scope='module')
def scoop():
    return ScoopGeometry.from_yaml()


def test_config_files_are_found():
    assert find_config('kettle_profile.yaml').exists()
    assert find_config('scoop.yaml').exists()
    assert find_config('water_level.yaml').exists()


def test_kettle_self_test(kettle):
    assert kettle_model._self_test(kettle)


def test_scoop_self_test(kettle, scoop):
    assert scoop_path._self_test(kettle, scoop, WallScoopPlanner(kettle, scoop))


def test_operating_level_matches_100_litres(kettle):
    assert kettle.soup_volume_L == pytest.approx(100.0)
    assert kettle.volume_L(kettle.level_h) == pytest.approx(100.0, abs=0.05)


def test_base_to_kettle_uses_measured_bottom(kettle):
    placement = kettle.placement
    if placement.get('axis_xy_in_base_m') is None:
        with pytest.raises(RuntimeError):
            kettle.base_to_kettle([0.7, 0.0, 0.0])
        return
    ax, ay = placement['axis_xy_in_base_m']
    p = kettle.base_to_kettle([ax, ay, placement['bottom_z_in_base_m'] + kettle.level_h])
    assert np.allclose(p, [0.0, 0.0, kettle.level_h])


def test_water_surface_z_moves_level_radius_and_surface_circle(kettle):
    bottom = kettle.placement['bottom_z_in_base_m']
    z = bottom + float(kettle.level_for_volume(52.0))
    low = KettleModel.from_yaml(water_surface_z=z)
    assert low.volume_L(low.level_h) == pytest.approx(52.0, abs=0.1)
    assert low.surface_z_in_base == pytest.approx(z)
    assert low.surface_radius < kettle.surface_radius
    x, y = kettle.placement['axis_xy_in_base_m']
    r = 0.5 * (low.surface_radius + kettle.surface_radius)          # 100 L 수면 안, 낮은 수면 밖
    assert kettle.surface_contains_xy(x + r, y) and not low.surface_contains_xy(x + r, y)
    with pytest.raises(ValueError):
        KettleModel.from_yaml(water_surface_z=bottom + 0.01)


def test_default_follows_water_level_file(kettle):
    z, _ = kettle_model.read_water_level()
    current = KettleModel.from_yaml()
    assert current.surface_z_in_base == pytest.approx(kettle.surface_z_in_base if z is None else z)


def test_parse_water_surface_z():
    parse = kettle_model.parse_water_surface_z
    assert parse('') == 'current' and parse(None) == 'current' and parse('current') == 'current'
    assert parse('design') is None
    assert parse('-0.2') == pytest.approx(-0.2) and parse(-0.2) == pytest.approx(-0.2)
