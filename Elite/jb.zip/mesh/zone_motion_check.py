#!/usr/bin/env python3
"""
구역별 스쿱 모션 초안 확인. 로봇에 명령을 보내지 않는다.

    python3 zone_motion_check.py              솥 충돌 여유 · 역기구학(관절 연속) · 수면 훑는 범위 + 그림
    python3 zone_motion_check.py --no-ik      역기구학 없이 (로봇 연결 불필요)
    python3 zone_motion_check.py --read-mdh   로봇에서 MDH 를 다시 읽어 cs612_mdh.yaml 에 저장 (읽기 전용 Primary)

그림
  zone_motions.png            위에서 본 구역 · 다섯 모션 경로 · 입구가 훑는 수면
  zone_motion_<구역>.png       모션마다 위에서 · X–Z · Y–Z 세 방향. 단계 ① 내린 직후 ~ ⑤ 들어 올림의 스쿱 윤곽.
                              옆모습 두 칸의 스쿱은 그 방향으로 비춘 그림자(투영), 솥 선은 축을 지나는 단면 윤곽이다.
                              실제 여유는 3D 로 계산한 값을 제목에 적는다.

모션 자체는 src/RIA_kettle/ria_kettle/zone_motion.py, 설정은 src/RIA_kettle/config/zone_motion.yaml.

역기구학
  컨트롤러 MDH + SDK KDL 플러그인 (move_home_safe.py 와 같은 계산). 홈 관절에서 시작해 경로 샘플마다 앞 관절각을
  초깃값으로 풀고, 한 샘플에서 관절이 checks.ik_max_joint_step_deg (robot_runtime.yaml) 넘게 뛰면 자세가 뒤집힌 것으로 본다.
  로봇 컨트롤러가 movel 을 실제로 풀 때와 다를 수 있다 (근사 확인).
수면 훑는 범위
  쓸기 동안 망 입구 면이 수면을 지나는 자리를 1 cm 칸으로 모은 것. 음식이 입구로 들어올 수 있는 자리의 근사.
"""

import argparse
import math
import sys
from pathlib import Path

import numpy as np
import yaml

sys.dont_write_bytecode = True

HERE = Path(__file__).resolve().parent
WS = next(p for p in HERE.parents if (p / 'src' / 'RIA_kettle').is_dir())   # 워크스페이스 (이 폴더 위치와 무관)
sys.path.insert(0, str(WS / 'src' / 'RIA_kettle'))
from ria_kettle import ScoopBody  # noqa: E402
from ria_kettle.kettle_model import parse_water_surface_z  # noqa: E402
from ria_kettle.zone_motion import CENTER, HOME, Waypoint, ZoneMotionPlanner, matrix_to_rpy  # noqa: E402
from runtime_config import RT, home_q, tcp_offset  # noqa: E402

MDH_CACHE = HERE / 'cs612_mdh.yaml'
OUTPUT_PNG = HERE / 'zone_motions.png'
GRID_M = 0.01                                        # 그림 · 수면 훑는 범위 칸 크기

# 색: 가운데 = 분류 1번(파랑), 가장자리 = 분류 2번(주황) — 구역 이름을 그림에 직접 적는다.
# 단계 ① ~ ⑤ = 한 색상(파랑) 순서형 250 → 650. 입구가 훑는 수면 = 주황 옅게.
COLOR = {'center': '#2a78d6', 'edge': '#eb6834'}
STAGE_SHADES = ['#86b6ef', '#5598e7', '#2a78d6', '#1c5cab', '#104281']
COVER = '#eb6834'
SURFACE, INK, INK_2, MUTED, GRID, AXIS = '#fcfcfb', '#0b0b0b', '#52514e', '#898781', '#e1e0d9', '#c3c2b7'


# -- 역기구학 -------------------------------------------------------------------

def load_mdh(refresh):
    if refresh or not MDH_CACHE.exists():
        import elite_cs_sdk as cs
        from check_flange_fk import read_mdh
        alpha, a, d = read_mdh(cs, RT.robot.ip)
        MDH_CACHE.write_text('# 컨트롤러 KinematicsInfo MDH (zone_motion_check.py --read-mdh 로 읽음, 읽기 전용)\n'
                             + yaml.safe_dump({'dh_alpha': list(map(float, alpha)), 'dh_a': list(map(float, a)),
                                               'dh_d': list(map(float, d))}), encoding='utf-8')
    doc = yaml.safe_load(MDH_CACHE.read_text(encoding='utf-8'))
    return [doc['dh_alpha'], doc['dh_a'], doc['dh_d']]


def track_ik(solver, samples):
    """경로 샘플을 차례로 역기구학. 반환: 관절각 배열 (N, 6) [rad], 문제 목록."""
    from move_home_safe import tcp_from_joints
    offset = tcp_offset()
    max_err, max_step = float(RT.checks.ik_max_position_error_m), float(RT.checks.ik_max_joint_step_deg)
    q = home_q()
    qs, problems = [], []
    for i, (stage, p, R) in enumerate(samples):
        # 도구 회전 오프셋은 0 으로 둔다 (robot.tcp_offset_rotation_rad — 0 이 아니면 여기 flange 자세도 고쳐야 함)
        flange = p - R @ np.asarray(offset[:3])
        ok, q_new, _ = solver.getPositionIK([*map(float, flange), *matrix_to_rpy(R)], list(q))
        if not ok:
            problems.append(f'{stage} 샘플 {i}: 역기구학 실패')
            break
        q_new = np.asarray(q_new, dtype=float)
        p_fk, _ = tcp_from_joints(solver, q_new, offset)
        if np.linalg.norm(p_fk - p) > max_err:
            problems.append(f'{stage} 샘플 {i}: 역기구학 해가 목표와 {np.linalg.norm(p_fk - p) * 1000:.1f} mm 다름')
            break
        step = np.degrees(np.abs(q_new - q)).max() if i else 0.0
        if step > max_step:
            problems.append(f'{stage} 샘플 {i}: 관절이 한 번에 {step:.0f}° 뜀 (자세 뒤집힘 의심)')
        qs.append(q_new)
        q = q_new
    return np.array(qs), problems


# -- 수면 훑는 범위 ----------------------------------------------------------------

def coverage_cells(points):
    return {(int(round(x / GRID_M)), int(round(y / GRID_M))) for x, y in points}


def surface_cells(planner):
    r = planner.kettle.surface_radius
    ax, ay = planner.axis_xy
    n = int(math.ceil(r / GRID_M))
    cells = {}
    for i in range(-n, n + 1):
        for j in range(-n, n + 1):
            x, y = ax + i * GRID_M, ay + j * GRID_M
            zone = planner.zone_of_xy(x, y)
            if zone:
                cells[(int(round(x / GRID_M)), int(round(y / GRID_M)))] = zone
    return cells


def dilate(cells):
    return {(i + di, j + dj) for i, j in cells for di in (-1, 0, 1) for dj in (-1, 0, 1)}


# -- 그림 ---------------------------------------------------------------------

def setup_matplotlib():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib import font_manager
    font = None
    for name in ('Noto Sans CJK KR', 'NanumGothic', 'Nanum Gothic', 'Noto Sans KR', 'NanumSquare_ac', 'NanumSquareRound',
                 'Noto Sans CJK JP', 'Noto Sans CJK TC', 'UnDotum', 'UnGraphic', 'Baekmuk Gulim'):
        if any(f.name == name for f in font_manager.fontManager.ttflist):
            font = name
            break
    if font:
        plt.rcParams['font.family'] = font
    plt.rcParams['axes.unicode_minus'] = False
    return plt, font


class Views:
    """세 방향 좌표. top: 위에서 본 모습(로봇 아래, +Y 왼쪽) · xz: 오른쪽(−Y)에서 · yz: 로봇 자리에서(+Y 왼쪽, 축을 뒤집어 그림)."""

    def __init__(self, planner):
        self.planner = planner
        self.ax, self.ay = planner.axis_xy

    def project(self, points, plane):
        p = np.atleast_2d(points)
        if plane == 'top':
            return -(p[:, 1] - self.ay), p[:, 0] - self.ax
        if plane == 'xz':
            return p[:, 0], p[:, 2]
        return p[:, 1], p[:, 2]

    def kettle(self, axes, plane, zone_lines=True):
        planner, k = self.planner, self.planner.kettle
        if plane == 'top':
            t = np.linspace(0, 2 * np.pi, 361)
            axes.plot(k.surface_radius * np.cos(t), k.surface_radius * np.sin(t), '-', color=INK_2, lw=1.2)
            axes.plot(float(k.rim_top[0]) * np.cos(t), float(k.rim_top[0]) * np.sin(t), ':', color=AXIS, lw=1.0)
            if zone_lines:
                rc = float(planner.cfg['zones']['center_radius_m'])
                axes.plot(rc * np.cos(t), rc * np.sin(t), '--', color=AXIS, lw=1.0)
                for deg in (0, 90, 180, 270):             # 가장자리 구역 경계 = ±X, ±Y 축 (위에서 본 좌표: (−r sin, r cos))
                    a = math.radians(deg)
                    axes.plot([-rc * math.sin(a), -k.surface_radius * math.sin(a)],
                              [rc * math.cos(a), k.surface_radius * math.cos(a)], '--', color=AXIS, lw=1.0)
            axes.annotate('로봇 쪽', xy=(0, -0.60), xytext=(0, -0.53), ha='center', va='top', color=INK_2, fontsize=9,
                          arrowprops=dict(arrowstyle='-|>', color=INK_2, lw=1.0))
            axes.text(-0.60, 0.0, '+Y\n왼쪽', color=INK_2, fontsize=9, ha='center', va='center')
            axes.set_aspect('equal')
            axes.set_xlim(-0.66, 0.64)
            axes.set_ylim(-0.64, 0.64)
            axes.axis('off')
            return
        b, bottom = k.boundary, float(k.placement['bottom_z_in_base_m'])
        c = self.ax if plane == 'xz' else self.ay
        for sgn in (1, -1):
            axes.plot(c + sgn * b[:, 0], bottom + b[:, 1], '-', color=INK_2, lw=1.4)
        axes.plot([c - k.surface_radius, c + k.surface_radius], [planner.surface_z] * 2, '-', color=COLOR['center'],
                  lw=1.0, alpha=0.45)
        axes.text(c + k.surface_radius - 0.01, planner.surface_z + 0.008, '수면 100 L', color=INK_2, fontsize=8, ha='right')

    def scoop(self, axes, w, plane, color, label=None):
        body = self.planner.body
        pts = body.points_base(w.position, w.R)
        cap = body.parts == ScoopBody.CAP
        u, v = self.project(pts[cap], plane)
        uv = np.c_[u, v]
        try:
            from scipy.spatial import ConvexHull
            poly = uv[ConvexHull(uv).vertices]
            axes.fill(poly[:, 0], poly[:, 1], color=color, alpha=0.20, lw=0)
            axes.plot(np.r_[poly[:, 0], poly[0, 0]], np.r_[poly[:, 1], poly[0, 1]], color=color, lw=1.6, label=label)
        except Exception:
            axes.plot(u, v, '.', ms=1, color=color, label=label)
        drawn = [uv]
        for part in dict.fromkeys(body.parts[~cap]):
            sel = body.parts == part
            pu, pv = self.project(pts[sel], plane)
            axes.plot(pu, pv, '-', color=color, lw=2.6 if part == '손목' else 1.8, solid_capstyle='round')
            drawn.append(np.c_[pu, pv])
        mu, mv = self.project(w.position, plane)
        axes.plot(mu, mv, 'o', ms=5, mfc=SURFACE, mec=color, mew=1.6)
        return np.vstack(drawn)                      # 칸 범위를 정할 때 손잡이 · 손목까지 들어가게

    def path(self, axes, m, plane):
        pts = [s[1] for s in m.samples if s[0] not in (HOME, '접근')]
        start = next(w for w in m.waypoints if w.stage == '접근').position
        u, v = self.project(np.vstack([start] + pts), plane)
        axes.plot(u, v, '--', color=MUTED, lw=1.1, label='표식 경로')
        k = len(u) // 2
        axes.annotate('', xy=(u[k + 1], v[k + 1]), xytext=(u[k], v[k]),
                      arrowprops=dict(arrowstyle='-|>', color=MUTED, lw=1.1, mutation_scale=12))
        return np.c_[u, v]


SWEEP_STAGES = ('쓸기', '벽접근')          # 벽접근 = 벽 마주 보기의 수평 접근
TILT_STAGES = ('세우기', '벽따라세우기')


def key_stages(m):
    wp = m.waypoints
    down = next(w for w in wp if w.stage == '내리기')
    sweeps = [w for w in wp if w.stage in SWEEP_STAGES] or [down]
    if len(sweeps) >= 3:
        mid = sweeps[len(sweeps) // 2]
    else:
        ss = [s for s in m.samples if s[0] in SWEEP_STAGES]
        mid = Waypoint(ss[len(ss) // 2][0], ss[len(ss) // 2][1], ss[len(ss) // 2][2]) if ss else down
    tilts = [w for w in wp if w.stage in TILT_STAGES] or [sweeps[-1]]
    return [('① 내린 직후', down), ('② 쓸기 중간', mid), ('③ 쓸기 끝', sweeps[-1]),
            ('④ 세운 뒤', tilts[-1]), ('⑤ 들어 올림', wp[-1])]


def _fit(axes, arrays, margin=0.03, invert_x=False):
    allpts = np.vstack(arrays)
    lo, hi = allpts.min(axis=0) - margin, allpts.max(axis=0) + margin
    axes.set_xlim((hi[0], lo[0]) if invert_x else (lo[0], hi[0]))
    axes.set_ylim(lo[1], hi[1])
    axes.set_aspect('equal', adjustable='box')


def _style(axes, xlabel, ylabel):
    axes.set_xlabel(xlabel, color=INK_2, fontsize=9)
    axes.set_ylabel(ylabel, color=INK_2, fontsize=9)
    axes.tick_params(colors=INK_2, labelsize=8)
    for s in axes.spines.values():
        s.set_color(AXIS)
    axes.grid(color=GRID, lw=0.6)
    axes.set_facecolor(SURFACE)


def draw_overview(plt, planner, motions, covered, path):
    views = Views(planner)
    fig, top = plt.subplots(figsize=(8.2, 8.2))
    fig.patch.set_facecolor(SURFACE)
    views.kettle(top, 'top')
    for zone, m in motions.items():
        color = COLOR['center' if zone == CENTER else 'edge']
        cells = covered[zone]
        if cells:
            cx, cy = views.project(np.array([[c[0] * GRID_M, c[1] * GRID_M, 0.0] for c in cells]), 'top')
            top.scatter(cx, cy, s=6, marker='s', color=color, alpha=0.16, linewidths=0)
        sweep = np.array([w.position for w in m.waypoints if w.stage in ('내리기', '쓸기')])
        px, py = views.project(sweep, 'top')
        top.plot(px, py, '-', color=color, lw=2.0, solid_capstyle='round')
        top.annotate('', xy=(px[-1], py[-1]), xytext=(px[-2], py[-2]),
                     arrowprops=dict(arrowstyle='-|>', color=color, lw=2.0, mutation_scale=16))
        top.plot(px[0], py[0], 'o', ms=8, mfc=SURFACE, mec=color, mew=2.0)
        if zone == CENTER:
            lx, ly = px[-1] + 0.07, py[-1] + 0.05
        else:
            c = math.radians(float(zone.split('_')[1]))
            lx, ly = views.project([planner.axis_xy[0] + 0.40 * math.cos(c), planner.axis_xy[1] + 0.40 * math.sin(c), 0.0], 'top')
            lx, ly = float(lx[0]), float(ly[0])
        top.text(lx, ly, m.label.replace('가장자리 ', ''), fontsize=10, color=INK, ha='center', va='center',
                 bbox=dict(boxstyle='round,pad=0.2', fc=SURFACE, ec='none', alpha=0.85))
    top.set_title('위에서 본 구역 · 표식 쓸기 경로 (○ 시작, ▶ 끝) · 옅은 칠 = 입구가 훑는 수면', fontsize=10, color=INK, loc='left')
    fig.tight_layout()
    fig.savefig(path, dpi=120, facecolor=SURFACE)
    plt.close(fig)


def _fmt_param(v):
    if isinstance(v, (tuple, list)):
        return '~'.join(f'{x:.2f}' for x in v)
    return f'{v:.2f}' if isinstance(v, float) else str(v)


def draw_motion(plt, planner, m, cells, path, target_xy=None):
    from matplotlib.lines import Line2D
    from matplotlib.patches import Patch
    views = Views(planner)
    fig, (top, xz, yz) = plt.subplots(1, 3, figsize=(20, 8.6), gridspec_kw={'width_ratios': [1.0, 1.25, 1.25]})
    fig.patch.set_facecolor(SURFACE)
    c = m.clearance
    params = ', '.join(f'{k} {_fmt_param(v)}' for k, v in m.params.items() if k.endswith('_m') and v is not None)
    if 'sweep_gamma_deg' in m.params:
        params += f', 쓸기 입구 {m.params["sweep_gamma_deg"]:.0f}° → 세우기 {m.params["lift_gamma_deg"]:.0f}°'
    if 'gamma_deg' in m.params:
        params += f', 입구 {m.params["gamma_deg"]:.0f}° → 벽 따라 {m.params.get("tilt_deg", 0.0):.0f}° 세움'
    fig.suptitle(f'{m.label} 모션 초안 — 경로 최소 여유 {c.clearance_m * 1000:+.0f} mm ({m.clearance_stage} · {c.part}) · '
                 f'팔 뻗음 최대 {m.reach_m:.2f} m · {params}',
                 x=0.01, ha='left', fontsize=12, color=INK)

    stages = key_stages(m)
    views.kettle(top, 'top')
    if cells:
        cx, cy = views.project(np.array([[i * GRID_M, j * GRID_M, 0.0] for i, j in cells]), 'top')
        top.scatter(cx, cy, s=5, marker='s', color=COVER, alpha=0.14, linewidths=0)
    views.path(top, m, 'top')
    for (name, w), shade in zip(stages, STAGE_SHADES):
        views.scoop(top, w, 'top', shade)
    top.set_title('위에서 (로봇은 아래)', fontsize=10, color=INK, loc='left')

    for axes, plane, title, xlabel in ((xz, 'xz', 'X–Z: 오른쪽(-Y)에서 본 투영 · 로봇은 왼쪽', '로봇 base X [m]  (로봇 → 먼 쪽)'),
                                        (yz, 'yz', 'Y–Z: 로봇 자리에서 솥을 본 투영 · +Y(왼쪽)가 왼쪽', '로봇 base Y [m]')):
        views.kettle(axes, plane)
        arrays = [views.path(axes, m, plane)]
        for (name, w), shade in zip(stages, STAGE_SHADES):
            arrays.append(views.scoop(axes, w, plane, shade, label=name))
        b, bottom = planner.kettle.boundary, float(planner.kettle.placement['bottom_z_in_base_m'])
        cc = planner.axis_xy[0] if plane == 'xz' else planner.axis_xy[1]
        arrays.append(np.c_[np.r_[cc + b[:, 0], cc - b[:, 0]], np.r_[bottom + b[:, 1], bottom + b[:, 1]]])
        _fit(axes, arrays, invert_x=(plane == 'yz'))
        _style(axes, xlabel, '로봇 base Z [m]')
        axes.set_title(title, fontsize=10, color=INK, loc='left')

    if target_xy is not None:                   # 목표 음식 (수면 위)
        t3 = np.r_[np.asarray(target_xy, dtype=float), planner.surface_z]
        for axes, plane in ((top, 'top'), (xz, 'xz'), (yz, 'yz')):
            u, v = views.project(t3, plane)
            axes.plot(u, v, marker='X', ms=12, color=COVER, mec=INK, mew=1.0, ls='none', zorder=6)

    handles = [Line2D([], [], color=s, lw=2.0, label=n) for (n, _), s in zip(stages, STAGE_SHADES)]
    if target_xy is not None:
        handles.append(Line2D([], [], marker='X', ms=10, color=COVER, mec=INK, ls='none', label='목표 음식'))
    handles += [Line2D([], [], color=MUTED, lw=1.1, ls='--', label='표식 경로 (접근 이후)'),
                Patch(color=COVER, alpha=0.3, label='입구가 훑는 수면')]
    fig.legend(handles=handles, loc='lower center', ncol=len(handles), frameon=False, fontsize=10, labelcolor=INK)
    fig.text(0.01, 0.935, '스쿱 윤곽 = 망 · 손잡이 · 손목을 그 방향으로 비춘 그림자 (굵은 선 = 손목), 흰 점 = 표식. '
             '솥 선 = 축을 지나는 단면 윤곽. 여유 · 팔 뻗음은 3D 로 계산한 값.', ha='left', fontsize=9, color=INK_2)
    fig.tight_layout(rect=(0, 0.06, 1, 0.92))
    fig.savefig(path, dpi=110, facecolor=SURFACE)
    plt.close(fig)


# -- 실행 ---------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description='구역별 스쿱 모션 초안 확인 (로봇 명령 없음).')
    parser.add_argument('--read-mdh', action='store_true', help='로봇에서 MDH 를 다시 읽는다 (읽기 전용)')
    parser.add_argument('--no-ik', action='store_true', help='역기구학 확인을 건너뛴다')
    parser.add_argument('--target', nargs=2, type=float, metavar=('R_CM', 'AZ_DEG'),
                        help='목표 음식 한 개 (솥 축 기준 반경 cm, 방위 deg: 0 = +X 먼 쪽, 90 = +Y 왼쪽) 로 좌표 입력 정책을 확인 · 그림')
    parser.add_argument('--wall-clearance', type=float, help='벽 마주 보기의 벽 쪽 세 단계 최소 여유 [mm] (확인용으로만 바꿈)')
    parser.add_argument('--water-z', type=parse_water_surface_z, default='current', metavar='Z|design',
                        help='수면 z [m] (확인용). 기본 = water_level.yaml, design = 설계 수위 100 L')
    args = parser.parse_args()

    planner = ZoneMotionPlanner.from_yaml(water_surface_z=args.water_z)
    solver = None
    if not args.no_ik:
        try:
            from move_home_safe import make_solver
            solver, _loader = make_solver(load_mdh(args.read_mdh))
        except SystemExit as exc:
            print(f'역기구학 확인 건너뜀: {exc}')

    if args.target:
        from ria_kettle.target_policy import WALL_STAGES, TargetPolicyPlanner
        tp = TargetPolicyPlanner(planner, planner.cfg)
        if args.wall_clearance is not None:
            planner.stage_min_clearance.update({s: args.wall_clearance / 1000.0 for s in WALL_STAGES})
        r, az = args.target[0] / 100.0, args.target[1]
        target = planner.axis_xy + r * np.array([math.cos(math.radians(az)), math.sin(math.radians(az))])
        plan = tp.plan(*target)
        print(f'목표 반경 {r * 100:.1f} cm, 방위 {az:.0f}° → base ({target[0]:.4f}, {target[1]:.4f}), 구역 {plan.zone}')
        print(f'정책 {plan.label}: {"OK" if plan.ok else "실패"}  비껴감 {plan.mouth_offset_m * 100:.1f} cm  {plan.reason}')
        print('  ' + ', '.join(f'{k} {_fmt_param(v)}' for k, v in plan.params.items()))
        if plan.check is None:
            return 1
        c = plan.check.clearance
        print(f'  최소 여유 {c.clearance_m * 1000:.0f} mm ({plan.check.clearance_stage} · {c.part}), 팔 뻗음 {plan.check.reach_m:.3f} m, '
              f'벽 쪽 다가감 {len(plan.check.closing)}곳, 단계별 최소 여유 [mm] '
              + ', '.join(f'{s} {v * 1000:.0f}' for s, v in plan.check.stage_min.items()))
        for pose, speed in tp.moves(plan):
            print(f'    movel [{", ".join(f"{v:+.4f}" for v in pose)}]  v {speed:.2f}')
        ik_ok = True
        if solver is not None:
            qs, problems = track_ik(solver, plan.samples)
            steps = np.degrees(np.abs(np.diff(qs, axis=0))).max() if len(qs) > 1 else 0.0
            print(f'  역기구학: {len(qs)}/{len(plan.samples)} 샘플, 한 샘플 최대 관절 변화 {steps:.1f}°')
            for p in problems:
                print('  ! ' + p)
            ik_ok = not problems
        plt, _font = setup_matplotlib()
        cells = coverage_cells(planner.mouth_waterline_xy(plan.samples, stages=SWEEP_STAGES))
        out = HERE / f'zone_target_r{args.target[0]:.0f}_az{args.target[1]:.0f}.png'
        draw_motion(plt, planner, plan, dilate(cells), out, target_xy=target)
        print(f'그림: {out.name}')
        return 0 if plan.ok and ik_ok else 1

    motions = planner.motions()

    zones_of_cell = surface_cells(planner)
    covered, any_cover = {}, set()
    print(f'솥 축 {np.round(planner.axis_xy, 4).tolist()}, 수면 z {planner.surface_z:+.4f}, 림 꼭대기 z {planner.rim_top_z:+.4f}')
    all_ok = True
    for zone, m in motions.items():
        cells = dilate(coverage_cells(planner.mouth_waterline_xy(m.samples))) & set(zones_of_cell)
        covered[zone] = cells
        any_cover |= cells
        own = [c for c, z in zones_of_cell.items() if z == zone]
        share = len(cells & set(own)) / max(len(own), 1)
        c = m.clearance
        print(f'\n[{m.label}] {"OK" if m.ok else "기준 미달"}: 최소 여유 {c.clearance_m * 1000:+.0f} mm ({m.clearance_stage} · {c.part}), '
              f'팔 뻗음 최대 {m.reach_m:.3f} m (기준 {m.max_reach_m:.2f}), 벽 쪽 다가감 {len(m.closing)}곳, '
              f'벽 근처 느린 구간 {sum(m.segment_slow)}/{len(m.segment_slow)}\n'
              f'  ' + ', '.join(f'{k} {v:.3f}' for k, v in m.params.items()) +
              f'\n  경유점 {len(m.waypoints)}, 샘플 {len(m.samples)}, 자기 구역 수면 중 입구가 훑는 비율 {share * 100:.0f}%')
        all_ok &= m.ok
        if solver is not None:
            qs, problems = track_ik(solver, m.samples)
            if len(qs):
                span = np.degrees(qs.max(axis=0) - qs.min(axis=0))
                steps = np.degrees(np.abs(np.diff(qs, axis=0))).max() if len(qs) > 1 else 0.0
                j5 = np.degrees(qs[:, 4])
                print(f'  역기구학: {len(qs)}/{len(m.samples)} 샘플, 한 샘플 최대 관절 변화 {steps:.1f}°, '
                      f'관절 움직임 폭 [deg] {np.round(span, 0).astype(int).tolist()}, J5 {j5.min():.0f}~{j5.max():.0f}°')
            for p in problems:
                print('  ! ' + p)
            all_ok &= not problems
    total = len(zones_of_cell)
    print(f'\n다섯 모션을 합쳐 입구가 훑는 수면 {len(any_cover) / total * 100:.0f}% (1 cm 칸 {total}개 중)')

    plt, font = setup_matplotlib()
    draw_overview(plt, planner, motions, covered, OUTPUT_PNG)
    paths = [OUTPUT_PNG]
    for zone, m in motions.items():
        path = HERE / f'zone_motion_{zone}.png'
        draw_motion(plt, planner, m, covered[zone], path)
        paths.append(path)
    print('그림: ' + ', '.join(p.name for p in paths) + ('' if font else '  (한글 글꼴이 없어 글자가 깨질 수 있음)'))
    return 0 if all_ok else 1


if __name__ == '__main__':
    sys.exit(main())
