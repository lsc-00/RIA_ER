# 파라미터 정리 — 스쿱 모션 · 로봇 실행 도구

2026-09-15 정리. 코드에 흩어져 있던 숫자를 설정 파일 두 개로 모았다. **코드에는 기본값이 없다** — 키가 빠지면 어느 파일의 무슨 키인지 알려 주는 에러로 멈춘다.

```bash
python3 ~/cs612_ws/src/vendor/dev_log/jb/mesh/runtime_config.py     # 두 파일의 지금 값을 한 번에 출력
```

---

## 0. 바뀌는 값 — 운용 중에 달라지는 것과 다시 넣는 방법

| 무엇이 바뀌나 | 파라미터 | 다시 재서 넣기 | 따라가는 곳 |
|---|---|---|---|
| **수면 높이** (물 채움 · 증발 · 음식 넣음) | `water_level.yaml surface_z_in_base_m` (이전 값은 `history`) | 테이프가 물에 닿게 조그 → `set_water_level.py --from-robot --apply` (또는 `--z` · `--volume`) | 계획기 (접근 · 쓸기 깊이 · 벽 마주 보기 깊이 · 구역 판정), 클릭 도구 좌표 변환 (PnP), `pixel_to_base_node` 수면 원 · 발행 z, `food_motion_node` 수면 원 |
| 솥 위치 (솥을 옮기거나 틸팅 후 복귀) | `kettle_profile.yaml placement.axis_xy_in_base_m` · `bottom_z_in_base_m` | `wall_touch_center.py far/near/left/right → apply` | 전부 |
| 펜던트 TCP (패널 재시작 때 0 으로 돌아간 적 있음) | `robot_runtime.yaml robot.tcp_offset_*` (기준값) | 펜던트에 다시 입력 → `check_tcp_offset.py` (다르면 종료 코드 2) | 실행 전 점검이 막음 |
| 카메라 (건드려 움직임) | 평면 보정 파일 (`plane_calibration.yaml`) | 조그 웹 보정 다시 · 서버 재시작 | 클릭 도구 · `pixel_to_base_node` |
| 스쿱 (교체 · 장착 각도) | `scoop.yaml` | 줄자 · 장착 각 확인 | 계획기 · 충돌 검사 |
| 음식 크기 (메뉴) | **아직 파라미터 없음** — `policy.edge_sweep_max_offset_m` 0.13 안에 음식 반지름 2.5 cm 가 녹아 있음 | — | 대각선 훑기 허용 비껴감 |

- 한 번만 다른 수면으로 계획해 보기: `--water-z -0.20` 또는 `--water-z design` (run_target_motion · click_target_motion · zone_motion_check).
- ROS 노드: 파라미터 `water_surface_z` (`''` = water_level.yaml, `design`, 숫자). 설정 파일은 노드가 시작할 때 읽는다 → 수면을 바꾸면 노드 재시작.
- 설정 파일은 설치본에서 실행해도 워크스페이스 `src/RIA_kettle/config/` 를 먼저 읽는다 (고친 값이 빌드 없이 반영).

---

## 어디에 무엇이

| 파일 | 내용 | 읽는 곳 |
|---|---|---|
| `src/RIA_kettle/config/water_level.yaml` | **지금 수면 높이** (바뀌는 값, `set_water_level.py` 가 씀) | `KettleModel.from_yaml` 기본 → 계획기 · 도구 · 노드 |
| `src/RIA_kettle/config/zone_motion.yaml` | **어떻게 뜨는가** — 수면 · 스쿱 자세 · 경로 규칙 · 속도 · 블렌드 · 정책 · 계산 정밀도 | `ria_kettle` 계획기 → 모든 jb/mesh 도구, 나중에 `food_motion_node` |
| `src/RIA_kettle/config/robot_runtime.yaml` | **로봇에서 어떻게 돌리는가** — IP · 홈 관절 · TCP 오프셋 · 점검 기준 · 정지 · 기록 · 공중 시연 · 홈 복귀 · 클릭 도구 | jb/mesh 로봇 도구 (`runtime_config.py`) |
| `src/RIA_kettle/config/kettle_profile.yaml` | 솥 형상 · 설치 위치 (측정으로 채움) | 계획기 · 노드 |
| `src/RIA_kettle/config/scoop.yaml` | 스쿱 치수 · 장착 (입구 방향 · 손잡이 · 손목) | 계획기 · 노드 |
| `src/RIA_bringup/config/food_motion.yaml` | `food_motion_node` ROS 파라미터 (옛 J4 모션 + 솥 검사) | 노드 — **새 정책 연결(3.4) 때 정리** |
| `src/RIA_calibration/config/tcp_jog.yaml` | 조그 웹 (조그 속도 · 초기 위치 · 카메라 클릭 이동) | 조그 서버 |
| `src/RIA_calibration/config/plane_calibration.yaml` | 카메라 픽셀 ↔ base 평면 보정 (`collect_samples` 가 생성) | `pixel_to_base_node` · 조그 웹 · 클릭 도구 |

파일마다 맨 위에 **파일 이름 · 역할 · 읽는 곳**, 항목마다 **뜻**을 주석으로 달았다. 프로그램이 다시 쓰는 파일은 만드는 코드의 머리말에 항목 설명을
넣어 다시 저장해도 남는다: `water_level.yaml` (`set_water_level.py`), `kettle_profile.yaml` (`extract_profile.py` · 축 위치 저장),
`plane_calibration.yaml` (`collect_samples`). 측정 기록(`jb/mesh/wall_touch_points.yaml` · `kettle_axis_measurement.yaml` · `cs612_mdh.yaml` ·
`motion_runs/*.yaml`)은 설정이 아니다.

### 바꾸는 방법

| 언제 | 방법 |
|---|---|
| 계속 쓸 값 | yaml 을 고친다. jb/mesh 도구는 **소스 파일을 바로 읽는다** (빌드 불필요). ROS 노드는 `colcon build --symlink-install --packages-select ria_kettle` 후 |
| 이번 실행만 | `--speed-scale 0.5` · `--wall-clearance 25` · `--water-z -0.20` · `--air auto` · `--no-smooth` (run_target_motion · click_target_motion), 클릭 창 `w` `0~3` `a` |
| 다른 설정 폴더로 통째로 | `RIA_KETTLE_CONFIG_DIR=/path/to/dir` (그 폴더에 있는 yaml 이 먼저) |
| 나중에 비교 | 실행 기록 `motion_runs/*.yaml` 의 `config` 에 그 실행에서 쓴 수면 · 자세 · 규칙(한 번만 바꾼 벽 쪽 여유 포함) · 속도 · 블렌드 · 실행 설정이 남는다 |

---

## 1. 지금 자주 만질 값 · 결정이 필요한 값

| 키 | 지금 | 뜻 | 상태 |
|---|---|---|---|
| `water_level.yaml surface_z_in_base_m` | −0.225 (약 52 L) | 지금 수면 높이. `null` = 100 L (−0.150) | 지금 52 L 는 시험 수위, **운용은 100 L 근처** (사용자 확인). 물을 채우면 `set_water_level.py --from-robot --apply` |
| `motion.marker_depth_m` | 0.025 | 쓸 때 표식이 수면 아래로 들어가는 깊이 | 사용자 기준 20~30 mm |
| `rules.min_clearance_m` | 0.035 | 경로 전체 스쿱 ↔ 솥 최소 여유 | 사용자 결정: 35 에서 디버깅하며 줄이기 |
| `rules.stage_min_clearance_m` | 벽 쪽 세 단계 0.035 | 벽 마주 보기의 벽 쪽 단계만 따로 | 줄이면 벽에 붙은 음식이 잡힌다 (100 L 에서 15 mm 면 0.6 cm 모자람) |
| `rules.near_wall_m` | 0.06 | 이 여유 안쪽 = 벽 근처 (다가감 금지 · 느리게 · 작은 블렌드) | 미결 |
| `speed.normal_m_s` · `near_wall_m_s` · `accel_m_s2` | 0.05 · 0.02 · 0.5 | 속도 · 가속도 | 미결 (실행 결과: 멈춤 0번, 편차 1.6 mm) |
| `smoothing.blend_radius_m` · `near_wall_blend_radius_m` | 0.02 · 0.005 | 모서리 블렌드 반경 | 미결 |
| `policy.pre_m` · `post_m` | 0.10 · 0.08 | 목표 앞뒤로 쓰는 거리 | 음식이 밀리는지 보고 조정 |
| `wall.gammas_deg` · `depths_m` · `tilt_deg` | [50..80] · [−0.02..0.05] · 25 | 벽 마주 보기 자세 후보 | 실물 확인 후 |
| `home_return.min_kettle_clearance_m` | 0.010 | 홈 복귀 경로 여유 | 모션 여유(35)보다 작다 — 홈 복귀는 벽에서 멀어지는 방향이라 |

---

## 2. `zone_motion.yaml` 전체

길이 m, 각도 deg. 방위 0° = +X (로봇에서 먼 쪽), 90° = +Y.

### `zones` — 구역
| 키 | 값 | 뜻 |
|---|---|---|
| `center_radius_m` | 0.30 | 이 반경 안 = 가운데 구역 (사용자 결정) |
| `edge_centers_deg` | [45, 135, 225, 315] | 가장자리 구역 중심 방위 (대각선, 사용자 결정) |
| `surface_margin_m` | 0.0 | 수면 원에서 이만큼 안쪽까지 구역 |

### `home_tcp` (수면은 `water_level.yaml` — 0 참고)
| 키 | 값 | 뜻 |
|---|---|---|
| `home_tcp.position_m` · `rpy_rad` | (0.7167, −0.1768, 0.1901) · (π, 0, −π/2) | 모든 계획의 출발점. `robot_runtime.yaml` 홈 관절 · TCP 오프셋과 짝 — 실행기가 FK 로 확인 (`checks.home_tcp_mismatch_m`) |

### `motion` — 스쿱 자세 · 높이
| 키 | 값 | 뜻 |
|---|---|---|
| `sweep_gamma_deg` | 50 | 쓸 때 입구가 수평보다 든 각도 (장착 상태 21°) |
| `lift_gamma_deg` | 75 | 세운 뒤 들어 올릴 때 입구 각도 |
| `marker_depth_m` | 0.025 | 쓸 때 표식 깊이 |
| `approach_above_surface_m` | 0.05 | 접근: 스쿱 가장 낮은 점이 수면보다 이만큼 위 |
| `lift_clearance_m` | 0.05 | 들어 올림: 스쿱 가장 낮은 점이 림 꼭대기보다 이만큼 위 |
| `tilt_step_deg` | 5 | 세우기 movel 간격 |
| `tilt_keep_depth` | true | 세우는 동안 망 바닥이 쓸기 깊이 아래로 안 내려가게 |
| `sweep_step_deg` | 7.5 | 가장자리 호 경유점 간격 |
| `entry_mode` | vertical | vertical = 수직으로 내려 표식을 물에 담근 뒤 물속에서 쓸기 각도로 세움 (단계 `물속자세`). 내려갈 때 입구 각은 21° 부터 올려, 맨 아래에서 벽 근처(`rules.near_wall_m`) 밖인 가장 작은 각 (100 L 가운데 시작점 27~30°; 벽 가까운 시작점 · 52 L 는 50° 그대로). tilted = 예전 (공중에서 이미 쓸기 자세). 수직 구간 길이는 `approach_above_surface_m` |
| `entry_gamma_step_deg` | 3 | vertical 진입 입구 각 탐색 간격 |

### `rules` — 경로 규칙 (3.1)
| 키 | 값 | 뜻 |
|---|---|---|
| `min_clearance_m` | 0.035 | 최소 여유 (망 · 손잡이 · 손목 전부) |
| `stage_min_clearance_m` | {벽접근, 벽따라세우기, 벽들어올리기: 0.035} | 단계별. 없는 단계는 위 값 |
| `near_wall_m` | 0.06 | 벽 근처 기준 |
| `closing_tolerance_m` | 0.003 | 벽 근처 점이 이만큼 넘게 벽 쪽으로 가면 '다가감' |
| `closing_allowed_stages` | [벽접근] | 다가가도 되는 단계 |

### `reach` — 팔 닿는 거리 (빠른 거르기)
| 키 | 값 | 뜻 |
|---|---|---|
| `shoulder_m` | (0, 0, 0.193) | J2 축 |
| `wrist_point_in_tool_m` | (0, 0.143, −0.610) | 도구 좌표의 J4 축 위 점 |
| `max_distance_m` | 1.18 | 어깨 ↔ 손목 상한 (1.174 통과, 1.264 실패) |

### `speed` — 속도 (한 번만: `--speed-scale`)
| 키 | 값 | 뜻 |
|---|---|---|
| `normal_m_s` | 0.05 | 평소 |
| `near_wall_m_s` | 0.02 | 벽 근처 구간이 있는 단계 전체 |
| `accel_m_s2` | 0.5 | movel 가속도 (0.10 은 짧은 구간에서 가속 · 정지 반복) |

### `smoothing` — 블렌드 (3.6)
| 키 | 값 | 뜻 |
|---|---|---|
| `blend_radius_m` | 0.02 | 경유점 블렌드 반경 (movel r) |
| `near_wall_blend_radius_m` | 0.005 | 벽 근처 구간에 붙은 경유점 |
| `max_segment_fraction` | 0.45 | 반경 ≤ 앞뒤 구간 중 짧은 것 × 이 값 (0.5 미만 — 이웃 블렌드끼리 안 겹치게) |
| `min_radius_m` | 0.001 | 이보다 작으면 0 |
| `shrink_factor` | 0.5 | 블렌드 경로가 규칙에 걸리면 곱함 |
| `max_rounds` | 16 | 줄이기 반복 상한 → 넘으면 블렌드 없이 |

### `policy` — 좌표 입력 정책 (3.2)
| 키 | 값 | 뜻 |
|---|---|---|
| `pre_m` · `post_m` | 0.10 · 0.08 | 입구 중심이 목표 앞 · 뒤로 쓰는 거리 |
| `min_pre_m` · `min_post_m` | 0.04 · 0.04 | 규칙 때문에 줄일 수 있는 최소 |
| `center_headings_deg` | [180, 135, 225, 90, 270] | 가운데 쓸기 방향 후보 (규칙 통과 중 비껴감 → 팔 뻗음 작은 것) |
| `lateral_offsets_m` | [0, ±0.02, ±0.04] | 입구 중심을 목표 옆으로 비껴 보는 값 |
| `edge_sweep_max_offset_m` | 0.13 | 대각선 훑기 허용 비껴감 (입구 반폭 − 음식 − 여유) |
| `wall_face_max_offset_m` | 0.0 | 벽 마주 보기: 잠긴 입구가 덮는 수면 밖 허용 거리 |

### `wall` — 벽 마주 보기
| 키 | 값 | 뜻 |
|---|---|---|
| `gammas_deg` | [50, 60, 70, 80] | 벽 쪽 수평 접근 입구 각도 후보 |
| `depths_m` | [−0.02, 0, 0.02, 0.05] | 그때 표식 깊이 후보 |
| `tilt_deg` · `tilt_step_deg` | 25 · 5 | 벽 원호 중심 둘레로 세우는 각도 · 간격 |
| `capture_lateral_m` | 0.03 | 덮는 수면을 잴 때 옆 폭 |
| `entry_mode` | tilted | 벽 마주 보기 진입 방식. 입구가 벽 쪽이라 수직 하강하려면 78~90° 가 필요해 기울여 접근 |

### `center` · `edge` — 구역 고정 모션 초안 (`--zone`)
| 키 | 값 | 뜻 |
|---|---|---|
| `center.heading_deg` | 180 | 쓰는 방향 |
| `center.start_max_m` · `end_max_m` | 0.30 · 0.30 | 시작 · 끝 거리 탐색 상한 |
| `edge.arc_radius_min_m` · `arc_radius_max_m` | 0.15 · 0.45 | 호 반경 탐색 범위 (min 은 대각선 훑기에도 쓰임) |

### `precision` — 계산 정밀도 (모양이 아니라 계산량)
| 키 | 값 | 뜻 |
|---|---|---|
| `sample_step_m` · `sample_step_deg` | 0.01 · 2.0 | 경로 규칙 확인 샘플 간격 |
| `body_step_m` · `coarse_body_step_m` | 0.01 · 0.02 | 스쿱 표면 점 간격 (최종 · 후보 거르기) |
| `search_tol_m` | 0.005 | 가장 큰 반경 · 길이 이분 탐색 |
| `wall_search_tol_m` | 0.002 | 벽 마주 보기 접근 끝 탐색 |
| `capture_grid_m` | 0.005 | 잠긴 입구 원판 점 간격 |
| `sweep_min_radius_m` | 0.05 | 대각선 호 반경 하한 (계산 안정용) |

---

## 3. `robot_runtime.yaml` 전체

| 절 · 키 | 값 | 뜻 | 쓰는 도구 |
|---|---|---|---|
| `robot.ip` | 192.168.0.100 | 로봇 주소 (각 도구 `--ip` 기본값) | 전부 |
| `robot.home_joints_deg` | [0, −90, −90, −90, 90, 0] | 홈 관절 | 실행기 · 홈 복귀 · 역기구학 확인 |
| `robot.tcp_offset_position_m` · `_rotation_rad` | (0, −0.025, 0.5) · 0 | 펜던트 TCP = 스쿱 표식 | 실행기 점검 · 역기구학 · `check_tcp_offset` |
| `checks.tcp_offset_tolerance_m` · `_deg` | 0.001 · 0.5 | 로봇 TCP 오프셋 ↔ 위 값 | 실행기 · `check_tcp_offset` (다르면 종료 코드 2) |
| `checks.home_joint_tolerance_deg` | 3 | 출발 전 홈 자세 판정 | 실행기 |
| `checks.fk_tcp_mismatch_m` | 0.003 | FK + 오프셋 ↔ 보고 TCP | 실행기 · 홈 복귀 |
| `checks.home_tcp_mismatch_m` | 0.005 | 홈 관절 FK TCP ↔ `zone_motion.yaml home_tcp` | 실행기 (새로 추가) |
| `checks.ik_max_joint_step_deg` | 15 | 샘플 사이 관절 변화 상한 (자세 뒤집힘) | 실행기 · `zone_motion_check` |
| `checks.ik_max_position_error_m` | 0.001 | 역기구학 해 오차 | 〃 |
| `checks.arm_min_clearance_m` | 0.04 | **로봇 팔 링크(충돌 메시) ↔ 솥 여유.** 계획 단계에서 후보를 거르고 실행 전에도 막음 (09-15 22:21 아래팔 림 충돌 뒤 추가) | 실행기 · 클릭 도구 (`arm_clearance.py`) |
| `checks.arm_links` · `arm_mesh_voxel_m` · `arm_outer_ring_m` | 위팔 · 아래팔 · 손목 1~3 · 0.005 · 0.30 | 검사할 링크 · 메시 점 간격 · 림 바깥에서 림 꼭대기보다 위에 있어야 하는 폭 | 〃 |
| `execution.max_rotation_per_move_deg` | 30 | 한 movel 최대 회전 (넘으면 나눔) | 실행기 |
| `execution.timeout_factor` · `timeout_extra_s` | 3 · 30 | 시간 초과 = 예상 × 3 + 30 s | 실행기 |
| `execution.stop_decel_m_s2` | 0.5 | stopl 감속 (SPACE · Ctrl+C · 시간 초과) | 실행기 · 클릭 도구 |
| `recording.rtsi_hz` | 125 | RTSI 기록 주기 | 실행기 |
| `recording.moving_speed_m_s` | 0.005 | 이 속도를 넘으면 '움직이는 중' (지표 구간 시작 · 끝) | 〃 |
| `recording.stop_speed_m_s` · `stop_min_s` | 0.002 · 0.15 | 움직이는 동안 '멈춤' 판정 | 〃 |
| `recording.trace_every` | 5 | 기록 파일 궤적 간격 | 〃 |
| `air_demo.water_margin_m` | 0.03 | 공중 시연 스쿱 ↔ 수면 | 실행기 `--air`, 클릭 `a` |
| `air_demo.search_start_m` · `search_step_m` · `max_offset_m` | 0.02 · 0.01 · 0.40 | auto 높이 탐색 | 〃 |
| `air_demo.lift_cap_m` | 0.10 | 공중 시연 마지막 들어 올리기 상한 | 〃 |
| `home_return.lift_tcp_z_m` | 0.20 | 이보다 낮으면 먼저 들어 올림 | `move_home_safe` (클릭 `h`) |
| `home_return.lift_lower_step_m` | 0.03 | 역기구학 안 되면 낮춰 볼 간격 | 〃 |
| `home_return.lift_ik_steps` · `lift_ik_max_joint_step_deg` | 10 · 20 | 들어 올리기 연속 역기구학 | 〃 |
| `home_return.min_kettle_clearance_m` | 0.010 | 복귀 경로 솥 여유 | 〃 |
| `home_return.linear_speed_m_s` · `linear_accel_m_s2` | 0.05 · 0.10 | 들어 올리기 movel | 〃 |
| `home_return.joint_speed_rad_s` · `joint_accel_rad_s2` | 0.20 · 0.30 | 홈 movej | 〃 |
| `home_return.timeout_s` · `stop_decel_rad_s2` | 90 · 2.0 | 시간 초과 · stopj 감속 | 〃 |
| `click_tool.image_topic` · `info_topic` | /camera/camera/color/… | 카메라 토픽 (`--image-topic` 기본값) | `click_target_motion` |
| `click_tool.air` · `speed_scale` | auto · 1.0 | `--air` · `--speed-scale` 기본값 | 〃 |
| `click_tool.wall_clearance_cycle_mm` | [35, 25, 15] | `w` 키 순환 값 | 〃 |
| `click_tool.pnp_switch_m` | 0.005 | 수면 ↔ 보정 평면 차이가 이보다 크면 PnP 로 클릭 좌표 계산 | 〃 |

---

## 4. 다른 설정 파일 (이번에 구조는 안 바꿈)

| 파일 · 키 | 지금 | 메모 |
|---|---|---|
| `kettle_profile.yaml placement.axis_xy_in_base_m` | (0.7738, −0.0036) | 방법 B 벽 짚기 (`wall_touch_center.py apply` 가 씀) |
| `kettle_profile.yaml placement.bottom_z_in_base_m` | −0.3737 | 100 L 기준선 실측에서 |
| `kettle_profile.yaml operating.level_h_m` | 0.2237 (100 L) | 설계 수위. 지금 수면은 `water_level.yaml` 이 덮어쓴다 (null 이면 이 값) |
| `scoop.yaml` 치수 · `mount.opening_axis_in_tool` · `capsules` · `shell_thickness_m` | ø385 × 100, 21°, 손잡이 · 손목 캡슐, 3 mm | 줄자 · 사용자 확인 |
| `food_motion.yaml kettle_min_clearance_m` | 0.02 | **`rules.min_clearance_m` 0.035 와 다름** — 노드를 새 정책으로 바꿀 때 zone_motion.yaml 을 읽게 해서 하나로 |
| `food_motion.yaml robot_ip` · 속도 · J4 값 | | 옛 J4 모션용. 3.4 에서 `robot_runtime.yaml` 과 겹치는 값 정리 |
| `pixel_to_base_node kettle_surface_margin_m` · `water_surface_z` · `cooking_surface_z` | 0.03 · `''` · 평면 보정 z | 수면 원 · 발행 z 는 지금 수면을 따라감. **x, y 변환은 아직 보정 평면 호모그래피** — 수면이 다르면 시작할 때 경고 (클릭 도구는 PnP 로 반영) |
| `food_motion_node water_surface_z` | `''` | 수면 원 판정이 지금 수면을 따라감 |
| `tcp_jog.yaml` | 조그 · 카메라 클릭 이동 (`camera_target_clearance_m` 등) | 조그 웹에는 솥 충돌 검사 없음 |

---

## 5. 파라미터로 만들지 않은 값

| 값 | 어디 | 이유 |
|---|---|---|
| 단계 이름 (`LIFT_STAGES`, `WALL_STAGES`, `HOME`) | 코드 | 알고리즘 구조 (값이 아니라 이름) |
| 포트 29999 · 30001 · 30004, RPY 규약 | 코드 | 컨트롤러 고정 |
| 대기 폴링 0.1 s, RTSI 루프 4 ms, 기록 앞뒤 0.3 s, 연결 대기 3 s | 실행기 · 홈 복귀 | 통신 타이밍. 바꿀 이유가 생기면 옮긴다 |
| 편차 계산에서 궤적 2개마다 1개 | `motion_metrics` | 지표 계산량 |
| 들어 올리기 최저 높이 (현재 + 2 cm), 시작 여유 − 2 mm | `move_home_safe` | 후보 목록 끝 · 시작부터 붙은 경우 판정 |
| 수위 범위 검사 (바닥 위 2 cm ~ 벽 끝) | `ZoneMotionPlanner` | 설정 실수 잡는 검사 |
| 테두리 꼭대기 찾기 점 간격 5 mm | `ScoopBody.rim_top_tool` | 특징점 하나 계산 |
| 입구가 훑는 수면 `band_m` 6 mm · `step_m` 1 cm, `GRID_M` 1 cm, 색 | 그림 도구 | 그림 전용 (함수 인자로 바꿀 수 있음) |
| 벽 짚기 판정 (높이 5 mm · 기울기 2° · 손목 5° · 교차 5 cm) | `wall_touch_center.py` 위쪽 상수 | 끝난 측정 도구. 다시 쓸 때 파일에서 |
| 비교값 0.300103 · CAD 수면 | `check_tcp_offset.py` | 09-14 조사 기록 (설정 아님) |

---

## 6. 바뀐 이름 (이전 → 지금)

| 이전 | 지금 |
|---|---|
| `zone_motion.yaml water.surface_z_in_base_m` | `water_level.yaml surface_z_in_base_m` (계획기뿐 아니라 솥 모델 기본값이라 노드까지 따라감) |
| `from_yaml(water_surface_z='config')` | `from_yaml(water_surface_z='current')` (`None` = 설계 100 L, 숫자 = 그 z) |
| `motion.min_clearance_m` · `stage_min_clearance_m` · `near_wall_m` · `closing_tolerance_m` · `closing_allowed_stages` | `rules.*` (같은 이름) |
| `motion.speed_m_s` · `near_wall_speed_m_s` · `accel_m_s2` | `speed.normal_m_s` · `speed.near_wall_m_s` · `speed.accel_m_s2` |
| `motion.blend_radius_m` · `near_wall_blend_radius_m` | `smoothing.*` (같은 이름) |
| `motion.sample_step_m` · `sample_step_deg` | `precision.*` (같은 이름) |
| 코드 `ScoopBody(step 0.01 / 0.02)`, 블렌드 0.45 · 1 mm · 절반 · 16회, 탐색 5 mm · 2 mm, 원판 5 mm, 호 하한 5 cm | `precision.*` · `smoothing.*` |
| jb/mesh 상수 `IP` · `HOME_DEG` · `EXPECTED_TCP_OFFSET` / `TCP_OFFSET` (파일 3~6곳에 중복) | `robot_runtime.yaml robot.*` 한 곳 |
| `TCP_OFFSET_TOL_*` · `HOME_JOINT_TOL_DEG` · `MAX_FK_MISMATCH_M` · `MAX_JOINT_STEP_DEG` · `MAX_IK_POSITION_ERR_M` | `checks.*` |
| `MAX_ROTATION_PER_MOVE_DEG` · 시간 초과 × 3 + 30 · `stopl(0.5)` | `execution.*` |
| `STOP_SPEED_M_S` · `STOP_MIN_S` · 125 Hz · 궤적 5개마다 · 움직임 0.005 m/s | `recording.*` |
| `AIR_WATER_MARGIN_M` · `AIR_MAX_M` · `AIR_LIFT_CAP_M` · 탐색 0.02 / 0.01 | `air_demo.*` |
| `LIFT_TCP_Z` · `MIN_KETTLE_CLEARANCE_M` · `LINEAR_V/A` · `JOINT_V/A` · `TIMEOUT_S` · 3 cm · 10 단계 · 20° · `stopj(2.0)` | `home_return.*` |
| `WALL_CLEARANCES_MM` · 카메라 토픽 · `--air auto` · PnP 5 mm | `click_tool.*` |

새로 생긴 점검: 홈 관절 FK TCP ↔ `home_tcp` (`checks.home_tcp_mismatch_m`), `check_tcp_offset.py` 가 설정과 비교해 다르면 종료 코드 2.
