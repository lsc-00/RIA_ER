#!/usr/bin/env python3
"""
스쿱을 솥에서 수직으로 들어 올린 뒤 홈 관절각으로 옮긴다. 현재 상태를 읽어 매번 경로를 새로 계산한다.

    python3 move_home_safe.py          계획 · 안전 확인만 출력 (움직이지 않음)
    python3 move_home_safe.py --go     확인을 통과하면 실제로 움직임

설정: robot_runtime.yaml 의 robot (IP · 홈 관절) · checks.fk_tcp_mismatch_m · home_return 절 (아래 괄호 안 이름)

동작
  A. TCP(스쿱 표식) 높이가 lift_tcp_z_m 보다 낮으면 수직으로 들어 올린다. 스쿱을 홈 자세로 세우며 → 자세 그대로 →
     높이를 lift_lower_step_m 씩 낮춰 가며, 역기구학이 되는 첫 방법 (lift_ik_steps 로 나눠 연속 역기구학)
  B. 홈 관절각 (robot.home_joints_deg) 으로 관절 이동

움직이기 전에 멈추는 조건
  - robotMode 가 RUNNING 이 아니거나 safetyMode 가 NORMAL 이 아님
  - 관절각 FK(컨트롤러 MDH) + 펜던트 TCP 오프셋으로 계산한 TCP 가 보고 TCP 와 checks.fk_tcp_mismatch_m 넘게 다름
  - 들어 올리기 · 관절 이동 경로 전체에서 스쿱(망 · 손잡이 · 손목)과 솥 경계 여유가 min_kettle_clearance_m 미만
    (예전의 "TCP 최저 z 0.15" 기준은 솥 모델 검사로 바꿈 — 도중 TCP 최저 높이는 참고로만 출력)
Ctrl+C 를 누르면 stopj (stop_decel_rad_s2) 를 보낸다.
"""

import argparse
import sys
import time
from pathlib import Path

import numpy as np

sys.dont_write_bytecode = True

import elite_cs_sdk as cs  # noqa: E402

from check_flange_fk import read_mdh, read_rtsi  # noqa: E402
from check_tcp_offset import parse_cartesian_info, rpy_to_matrix  # noqa: E402
from runtime_config import RT, home_q  # noqa: E402  (ria_kettle 경로도 잡는다)

from ria_kettle import KettleModel, ScoopBody, ScoopGeometry, ScoopMount, rotation_about  # noqa: E402
from ria_kettle.zone_motion import rotation_log  # noqa: E402


def mode_name(value):
    return getattr(value, 'name', str(value).rsplit('.', 1)[-1])


def fmt(values):
    return '[' + ', '.join(f'{v:.6f}' for v in values) + ']'


def rpy_from_matrix(R):
    from scipy.spatial.transform import Rotation
    return list(Rotation.from_matrix(R).as_euler('xyz'))


def make_solver(mdh):
    try:
        import elite_cs_sdk.elite_cs_sdk_python as native
    except ImportError:
        native = cs
    libs = sorted(Path(native.__file__).resolve().parent.glob('*kdl*kinematics*.so'))
    if not libs:
        raise SystemExit('KDL 기구학 플러그인을 찾지 못했습니다.')
    loader = native.ClassLoader(str(libs[0]))
    if not loader.loadLib():
        raise SystemExit('KDL 플러그인 로드 실패')
    solver = loader.createKinematicsInstance('ELITE::KdlKinematicsPlugin')
    solver.setMDH(*mdh)
    return solver, loader


def tcp_from_joints(solver, q, offset):
    ok, flange = solver.getPositionFK(list(q))
    if not ok:
        raise RuntimeError('FK 실패')
    R = rpy_to_matrix(flange[3:])
    p = np.asarray(flange[:3]) + R @ np.asarray(offset[:3])
    return p, R @ rpy_to_matrix(offset[3:])


def read_cartesian(primary):
    class CartesianInfo(cs.PrimaryPackage):
        def __init__(self):
            super().__init__(4)
            self.values = None

        def parser(self, data):
            try:
                self.values = parse_cartesian_info(data)
            except Exception:
                self.values = None

    for _ in range(5):
        pkg = CartesianInfo()
        if primary.getPackage(pkg, 1500) and pkg.values:
            return pkg.values
    raise SystemExit('TCP 자세를 읽지 못했습니다.')


def wait_done(dashboard):
    start = time.monotonic()
    saw_running = False
    while time.monotonic() - start < float(RT.home_return.timeout_s):
        name = mode_name(dashboard.runningStatus())
        if name not in ('STOPPED', 'UNKNOWN'):
            saw_running = True
        elif name == 'STOPPED' and (saw_running or time.monotonic() - start > 3.0):
            return True
        time.sleep(0.1)
    return False


def lift_ik(solver, pose, R_from, z_to, R_to, offset, q_seed, steps=None, max_step_deg=None):
    """TCP 를 (x, y) 그대로 z_to 까지 올리며 자세를 R_from → R_to 로 돌리는 직선 이동을 steps 로 나눠 연속 역기구학.
    해가 없거나 관절이 한 번에 max_step_deg 넘게 뛰면 None. 기본값은 home_return.lift_ik_steps · lift_ik_max_joint_step_deg."""
    steps = int(RT.home_return.lift_ik_steps) if steps is None else steps
    max_step_deg = float(RT.home_return.lift_ik_max_joint_step_deg) if max_step_deg is None else max_step_deg
    R_off = rpy_to_matrix(offset[3:])
    w = rotation_log(R_from.T @ R_to)
    angle = float(np.linalg.norm(w))
    q = np.asarray(q_seed, dtype=float)
    for t in np.linspace(0.0, 1.0, steps + 1)[1:]:
        R = R_from @ rotation_about(w, t * angle) if angle > 1e-12 else R_from
        R_f = R @ R_off.T
        flange = np.array([pose[0], pose[1], pose[2] + t * (z_to - pose[2])]) - R_f @ np.asarray(offset[:3])
        ok, q_new, _ = solver.getPositionIK([*map(float, flange), *rpy_from_matrix(R_f)], list(q))
        if not ok or np.degrees(np.abs(np.asarray(q_new) - q)).max() > max_step_deg:
            return None
        q = np.asarray(q_new, dtype=float)
    return q


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--go', action='store_true', help='확인을 통과하면 실제로 움직인다')
    parser.add_argument('--ip', default=RT.robot.ip)
    args = parser.parse_args()
    H = RT.home_return
    lift_z = float(H.lift_tcp_z_m)

    mdh = read_mdh(cs, args.ip)
    q_now = np.array(read_rtsi(cs, args.ip, 3)[-1][0])
    solver, _loader = make_solver(mdh)

    dashboard = cs.DashboardClientInterface()
    if not dashboard.connect(args.ip, 29999):
        raise SystemExit('Dashboard 연결 실패')
    primary = cs.PrimaryClientInterface()
    if not primary.connect(args.ip, 30001):
        dashboard.disconnect()
        raise SystemExit('Primary 연결 실패')
    try:
        mode, safety = mode_name(dashboard.robotMode()), mode_name(dashboard.safetyMode())
        pose, offset = read_cartesian(primary)
        print(f'robotMode {mode}, safetyMode {safety}')
        print(f'현재 TCP   {fmt(pose)}')
        print(f'TCP 오프셋 {fmt(offset)}')
        print(f'현재 관절 [deg] {np.round(np.degrees(q_now), 2).tolist()}')

        problems = []
        if mode != 'RUNNING':
            problems.append(f'로봇이 RUNNING 이 아님 ({mode})')
        if safety != 'NORMAL':
            problems.append(f'안전 모드가 NORMAL 이 아님 ({safety})')

        p_fk, _ = tcp_from_joints(solver, q_now, offset)
        mismatch = float(np.linalg.norm(p_fk - np.asarray(pose[:3])))
        print(f'관절각 FK + 오프셋으로 계산한 TCP 와 보고 TCP 차이 {mismatch * 1000:.2f} mm')
        if mismatch > float(RT.checks.fk_tcp_mismatch_m):
            problems.append('FK 로 계산한 TCP 가 보고 TCP 와 맞지 않음 — 오프셋 · 기구학 확인 필요')

        R_tcp = rpy_to_matrix(pose[3:])
        home = home_q()
        p_home, R_home_tcp = tcp_from_joints(solver, home, offset)
        do_lift = pose[2] < lift_z
        q_start, lift = q_now, None
        lines = ['def ria_move_home_safe():']
        if do_lift:
            # 스쿱이 기운 채 높이 올리면 손목이 멀어져 팔이 안 닿을 수 있다 (2026-09-15 공중 시연 끝 자세에서 실패)
            # → 올리면서 스쿱을 홈 자세로 세우기를 먼저, 안 되면 자세 그대로, 그래도 안 되면 높이를 lift_lower_step_m 씩 낮춘다
            step = float(H.lift_lower_step_m)
            candidates = [('스쿱을 홈 자세로 세우며', lift_z, R_home_tcp), ('자세 그대로', lift_z, R_tcp)]
            candidates += [('자세 그대로', float(z), R_tcp) for z in np.arange(lift_z - step, pose[2] + 0.02, -step)]
            for name, z, R_target in candidates:
                q_try = lift_ik(solver, pose, R_tcp, z, R_target, offset, q_now)
                if q_try is not None:
                    q_start, lift = q_try, (name, z, R_target)
                    break
            if lift is None:
                print('A. 들어 올리기: 어느 높이 · 자세로도 역기구학이 안 됨 → 지금 자세에서 바로 홈 관절 이동을 검사')
            else:
                name, z, R_target = lift
                lift_pose = [pose[0], pose[1], z, *rpy_from_matrix(R_target)]
                print(f'A. 들어 올리기 ({name}): TCP z {pose[2]:+.3f} → {z:+.3f}, '
                      f'관절 변화 최대 {np.abs(np.degrees(q_start - q_now)).max():.1f}°')
                lines.append(f'  movel({fmt(lift_pose)}, a={float(H.linear_accel_m_s2):.3f}, v={float(H.linear_speed_m_s):.3f}, r=0.000)')
        else:
            print(f'A. 생략: TCP z {pose[2]:+.3f} 가 이미 {lift_z:+.2f} 이상')

        lowest = None
        for t in np.linspace(0.0, 1.0, 201):
            p, _ = tcp_from_joints(solver, q_start + t * (home - q_start), offset)
            if lowest is None or p[2] < lowest[0][2]:
                lowest = (p, t)
        print(f'B. 홈 관절 이동: 관절 변화 최대 {np.abs(np.degrees(home - q_start)).max():.1f}°, '
              f'도중 TCP 최저 z {lowest[0][2]:+.3f} (t={lowest[1]:.2f}), 도착 예상 TCP {np.round(p_home, 4).tolist()}')
        # 예전에는 TCP 최저 z < MIN_TCP_Z 면 멈췄다. 솥 모델 충돌 검사(아래)가 스쿱 전체의 여유를 보므로 높이 기준은 참고로만 출력한다.
        # (2026-09-15: 공중 시연 끝 자세에서 TCP z 0.113 이지만 여유 102 mm 인 안전한 경로가 높이 기준에 막힘)

        # 솥 충돌 여유: 현재 → 수직 들어 올리기 → 홈 관절 이동 경로 전체
        kettle = KettleModel.from_yaml()
        body = ScoopBody(ScoopGeometry.from_yaml(), ScoopMount.from_yaml())
        start = body.clearance(kettle, pose[:3], R_tcp)
        samples = []
        if lift is not None:
            w = rotation_log(R_tcp.T @ lift[2])
            angle = float(np.linalg.norm(w))
            count = max(int(np.ceil((lift[1] - pose[2]) / 0.01)), int(np.ceil(np.degrees(angle) / 2.0)), 1)
            for t in np.linspace(0.0, 1.0, count + 1):
                R = R_tcp @ rotation_about(w, t * angle) if angle > 1e-12 else R_tcp
                samples.append(('A', np.r_[pose[0], pose[1], pose[2] + t * (lift[1] - pose[2])], R))
        for t in np.linspace(0.0, 1.0, 101):
            p, R = tcp_from_joints(solver, q_start + t * (home - q_start), offset)
            samples.append(('B', p, R))
        worst, stage = body.worst_clearance(kettle, samples)
        need = min(float(H.min_kettle_clearance_m), start.clearance_m - 0.002)
        print(f'솥 여유: 지금 {start.clearance_m * 1000:+.0f} mm ({start.part}), 경로 최소 {worst.clearance_m * 1000:+.0f} mm '
              f'({stage} 단계 {worst.part}, base {np.round(worst.point_base, 3).tolist()}), 기준 {need * 1000:+.0f} mm')
        if worst.clearance_m < need:
            problems.append(f'경로 중 스쿱이 솥 경계에 너무 가까움 ({stage} 단계 {worst.part} {worst.clearance_m * 1000:+.0f} mm)')
        lines.append(f'  movej({fmt(home)}, a={float(H.joint_accel_rad_s2):.3f}, v={float(H.joint_speed_rad_s):.3f}, r=0.000)')
        lines.append('end')
        script = '\n'.join(lines) + '\n'
        print('\n보낼 프로그램:\n' + script)

        if problems:
            for p in problems:
                print(f'중단: {p}')
            return 1
        if not args.go:
            print('--go 가 없어 움직이지 않았습니다.')
            return 0

        print('이동 시작 (Ctrl+C = 정지)')
        if not primary.sendScript(script):
            raise SystemExit('프로그램 전송 실패')
        try:
            done = wait_done(dashboard)
        except KeyboardInterrupt:
            primary.sendScript(f'stopj({float(H.stop_decel_rad_s2)})\n')
            print('정지 명령을 보냈습니다.')
            return 130
        pose, _ = read_cartesian(primary)
        err = float(np.linalg.norm(np.asarray(pose[:3]) - p_home)) * 1000
        print(('완료' if done else '시간 초과 — 펜던트 확인 필요') + f': 현재 TCP {fmt(pose)} (예상과 {err:.1f} mm)')
        return 0 if done else 1
    finally:
        primary.disconnect()
        dashboard.disconnect()


if __name__ == '__main__':
    sys.exit(main())
