#!/usr/bin/env python3
"""
국솥(에너텍 ENR-500) 내솥 형상 모델 — 설계 원호 기반.

kettle_profile.yaml 의 설계 형상(바닥 평면 + 서로 접하는 벽 원호 + 림 립)으로
벽 함수, 벽까지의 거리, 벽 원호의 중심(피벗), 국물 수위를 계산한다.

    python3 kettle_model.py      # 요약 + 자체 점검

    from kettle_model import KettleModel
    kettle = KettleModel.from_yaml()
    kettle.wall_radius(0.20)             # 높이 0.20 m 의 벽 반경
    kettle.wall_arc_at(0.20)             # 그 높이의 벽 원호(중심 = 피벗)와 각도
    kettle.signed_distance(0.30, 0.15)   # (r, h) 에서 경계까지 거리 (+ 여유 / - 충돌)
    kettle.level_h                       # 운용 수위 (water_level.yaml 의 지금 수면, null 이면 설계 100 L)
    KettleModel.from_yaml(water_surface_z=None)   # 설계 수위 100 L 로 (시험 · 비교)

좌표
  솥 좌표계. 원점 = 회전축과 바닥 평면의 교점, h 는 위쪽, 단위 m.
  회전체라 모든 계산을 (r, h) 단면에서 한다. r = 축에서의 수평 거리.
  솥이 똑바로 선 상태(틸팅 0°)만 나타낸다.

원호 각도
  원호 위 점의 각도 α 는 원호 중심에서 본 방향이다. 0 = 바로 아래, 벽 위쪽으로 갈수록 커진다.
  그 점의 벽 기울기(수직 기준) = 90° − α.

거리 부호
  + : 조리 공간 안, 또는 림보다 높은 빈 공간
  - : 벽 속, 또는 림보다 낮은 솥 바깥 (외피 · 기둥은 모델에 없으므로 전부 막힌 것으로 본다)
"""

import os
import sys
from pathlib import Path

import numpy as np
import yaml

CONFIG_ENV = 'RIA_KETTLE_CONFIG_DIR'
WATER_FILE = 'water_level.yaml'          # 지금 수면 (바뀌는 값)


def find_config(name):
    """설정 파일 위치를 찾는다.

    1. 환경변수 RIA_KETTLE_CONFIG_DIR
    2. 소스 트리의 config/ (src/RIA_kettle/config, src/vendor/dev_log/jb/mesh 의 바로가기에서 실행할 때도 여기로 온다)
    3. 설치본(install/)에서 실행할 때도 워크스페이스의 src/RIA_kettle/config/ — 수면처럼 자주 바뀌는 값을 고치면
       ROS 노드도 빌드 없이 다음 시작부터 반영되게
    4. 설치된 share/ria_kettle/config/
    """
    candidates = []
    if os.environ.get(CONFIG_ENV):
        candidates.append(Path(os.environ[CONFIG_ENV]).expanduser() / name)
    here = Path(__file__).resolve()
    candidates.append(here.parent.parent / 'config' / name)
    candidates += [p / 'src' / 'RIA_kettle' / 'config' / name
                   for p in here.parents if (p / 'src' / 'RIA_kettle' / 'config').is_dir()][:1]
    try:
        from ament_index_python.packages import get_package_share_directory
        candidates.append(Path(get_package_share_directory('ria_kettle')) / 'config' / name)
    except Exception:
        pass
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError(f'{name} 를 찾지 못했습니다: ' + ', '.join(str(c) for c in candidates))


def read_water_level(path=None):
    """지금 수면 (water_level.yaml). 반환: (surface_z_in_base_m 또는 None(설계 수위), 문서 dict)."""
    path = find_config(WATER_FILE) if path is None else Path(path)
    doc = yaml.safe_load(Path(path).read_text(encoding='utf-8')) or {}
    z = doc.get('surface_z_in_base_m')
    return (None if z is None else float(z)), doc


def parse_water_surface_z(value):
    """설정 · 명령줄 값 → KettleModel.from_yaml 의 water_surface_z.
    None · '' · 'current' = water_level.yaml, 'design' = 설계 수위 (100 L), 숫자 = 그 수면 z [m, 로봇 base]."""
    if value is None or (isinstance(value, str) and value.strip().lower() in ('', 'current')):
        return 'current'
    if isinstance(value, str) and value.strip().lower() == 'design':
        return None
    return float(value)


def _wrap(angle):
    """각도를 (-π, π] 로."""
    return (np.asarray(angle, dtype=float) + np.pi) % (2 * np.pi) - np.pi


def direction(alpha):
    """원호 중심에서 각도 alpha 방향의 단위벡터 (r, h). 0 = 바로 아래."""
    alpha = np.asarray(alpha, dtype=float)
    return np.stack([np.sin(alpha), -np.cos(alpha)], axis=-1)


class Line:
    kind = 'line'

    def __init__(self, name, start, end):
        self.name = name
        self.start = np.asarray(start, dtype=float)
        self.end = np.asarray(end, dtype=float)

    def distance(self, p):
        seg = self.end - self.start
        t = np.clip(((p - self.start) @ seg) / max(float(seg @ seg), 1e-18), 0.0, 1.0)
        diff = p - (self.start + t[:, None] * seg)
        return np.hypot(diff[:, 0], diff[:, 1])

    def sample(self, step):
        n = max(int(np.ceil(np.linalg.norm(self.end - self.start) / step)), 1)
        return self.start + np.linspace(0.0, 1.0, n + 1)[:, None] * (self.end - self.start)


class Arc:
    kind = 'arc'

    def __init__(self, name, center, radius, start, end):
        self.name = name
        self.center = np.asarray(center, dtype=float)
        self.radius = float(radius)
        self.start = np.asarray(start, dtype=float)
        self.end = np.asarray(end, dtype=float)
        self.start_angle = float(self.angle_of(self.start))
        self.sweep = float(_wrap(self.angle_of(self.end) - self.start_angle))

    def angle_of(self, p):
        v = np.asarray(p, dtype=float) - self.center
        return np.arctan2(v[..., 0], -v[..., 1])

    def point(self, alpha):
        return self.center + self.radius * direction(alpha)

    def distance(self, p):
        v = p - self.center
        on_circle = np.abs(np.hypot(v[:, 0], v[:, 1]) - self.radius)
        d = _wrap(self.angle_of(p) - self.start_angle)
        inside = (d >= min(0.0, self.sweep) - 1e-12) & (d <= max(0.0, self.sweep) + 1e-12)
        to_ends = np.minimum(np.hypot(*(p - self.start).T), np.hypot(*(p - self.end).T))
        return np.where(inside, on_circle, to_ends)

    def sample(self, step):
        n = max(int(np.ceil(abs(self.sweep) * self.radius / step)), 1)
        return self.point(self.start_angle + np.linspace(0.0, self.sweep, n + 1))


class KettleModel:
    """내솥 조리 공간. 설계 형상 조각(Line / Arc)을 바닥 중심부터 림 꼭대기까지 순서대로 받는다."""

    def __init__(self, pieces, operating=None, placement=None, cad_rings=None, sample_step=0.0002):
        self.pieces = list(pieces)
        self.walls = [p for p in self.pieces if p.kind == 'arc' and p.name.startswith('wall_arc')]
        if not self.walls:
            raise ValueError('설계 형상에 벽 원호(wall_arc_*)가 없습니다.')
        self.bottom_flat_radius = float(self.walls[0].start[0])
        self.wall_top = self.walls[-1].end.copy()
        self.rim_top = self.pieces[-1].end.copy()
        self.operating = dict(operating or {})
        self.placement = dict(placement or {})
        self.cad_rings = cad_rings
        self.water_source = f'설계 수위 {self.soup_volume_L:.0f} L (kettle_profile)'

        # 경계 점열. r 이 계속 커지는 한 줄이라 "경계보다 위인가" 를 r 로 보간해 판정한다.
        self.boundary = np.vstack([p.sample(sample_step)[:-1] for p in self.pieces] + [self.pieces[-1].end[None]])

        h = np.linspace(0.0, self.wall_top[1], 40001)
        area = np.pi * self.wall_radius(h) ** 2
        self._volume_h = h
        self._volume_m3 = np.r_[0.0, np.cumsum((area[1:] + area[:-1]) / 2 * np.diff(h))]

    @classmethod
    def from_yaml(cls, path=None, water_surface_z='current', **kwargs):
        """water_surface_z: 'current' = water_level.yaml 의 지금 수면 (null 이면 설계 수위),
        None = 설계 수위 (operating, 100 L), 숫자 = 그 수면 z [m, 로봇 base] (시험 · 이번 실행만)."""
        model = cls._from_profile(path, **kwargs)
        if water_surface_z == 'current':
            z, doc = read_water_level()
            if z is not None:
                model.set_surface_z(z, f'{WATER_FILE} {doc.get("measured_at", "")} {doc.get("method", "")}'.strip())
        elif water_surface_z is not None:
            model.set_surface_z(float(water_surface_z), '직접 지정')
        return model

    @classmethod
    def _from_profile(cls, path=None, **kwargs):
        path = find_config('kettle_profile.yaml') if path is None else path
        doc = yaml.safe_load(Path(path).read_text(encoding='utf-8'))
        pieces = []
        for p in doc['design']['pieces']:
            if p['type'] == 'line':
                pieces.append(Line(p['name'], p['start_rh_m'], p['end_rh_m']))
            elif p['type'] == 'arc':
                pieces.append(Arc(p['name'], p['center_rh_m'], p['radius_m'], p['start_rh_m'], p['end_rh_m']))
            else:
                raise ValueError(f"알 수 없는 조각 형식: {p['type']}")
        return cls(pieces, operating=doc.get('operating'), placement=doc.get('placement'),
                   cad_rings=(doc.get('cad_rings') or {}).get('rings'), **kwargs)

    # -- 벽 ------------------------------------------------------------------

    def _wall_alpha(self, h):
        h = np.atleast_1d(np.asarray(h, dtype=float))
        index = np.full(h.shape, -1)
        alpha = np.full(h.shape, np.nan)
        lower = -1e-12
        for i, arc in enumerate(self.walls):
            m = (index < 0) & (h >= lower) & (h <= arc.end[1] + 1e-12)
            alpha[m] = np.arccos(np.clip((arc.center[1] - h[m]) / arc.radius, -1.0, 1.0))
            index[m] = i
            lower = arc.end[1] - 1e-12
        return index, alpha

    def wall_arc_at(self, h):
        """높이 h(스칼라)의 벽 원호와 그 점의 각도 α [rad]. 원호 중심이 피벗이다."""
        h = float(h)
        if not -1e-12 <= h <= self.wall_top[1] + 1e-12:
            raise ValueError(f'h = {h:.4f} m 는 벽 범위(0 ~ {self.wall_top[1]:.4f} m) 밖입니다.')
        index, alpha = self._wall_alpha(h)
        return self.walls[int(index[0])], float(alpha[0])

    def wall_radius(self, h):
        """높이 h 의 벽 반경. 벽 범위 밖이면 nan."""
        shape = np.shape(h)
        index, alpha = self._wall_alpha(h)
        r = np.full(alpha.shape, np.nan)
        for i, arc in enumerate(self.walls):
            m = index == i
            r[m] = arc.center[0] + arc.radius * np.sin(alpha[m])
        return r.reshape(shape)[()]

    def wall_height(self, r):
        """반경 r 의 경계 높이. 바닥 평면이면 0, 벽 끝보다 바깥이면 nan."""
        shape = np.shape(r)
        r = np.atleast_1d(np.asarray(r, dtype=float))
        h = np.full(r.shape, np.nan)
        h[(r >= 0.0) & (r <= self.bottom_flat_radius)] = 0.0
        for arc in self.walls:
            m = (r > arc.start[0]) & (r <= arc.end[0] + 1e-12)
            alpha = np.arcsin(np.clip((r[m] - arc.center[0]) / arc.radius, -1.0, 1.0))
            h[m] = arc.center[1] - arc.radius * np.cos(alpha)
        return h.reshape(shape)[()]

    def wall_tilt_deg(self, h):
        """벽 기울기 [deg]. 0 = 수직, 90 = 수평."""
        shape = np.shape(h)
        _, alpha = self._wall_alpha(h)
        return (90.0 - np.degrees(alpha)).reshape(shape)[()]

    def inward_normal(self, h):
        """높이 h 의 벽에서 조리 공간 쪽(원호 중심 쪽)을 향하는 단위 법선 (n_r, n_h)."""
        shape = np.shape(h)
        _, alpha = self._wall_alpha(h)
        return (-np.sin(alpha)).reshape(shape)[()], np.cos(alpha).reshape(shape)[()]

    # -- 거리 ----------------------------------------------------------------

    def distance_to_boundary(self, r, h):
        """(r, h) 에서 경계까지 최단 거리 [m]. 부호 없음."""
        r, h = np.broadcast_arrays(np.asarray(r, dtype=float), np.asarray(h, dtype=float))
        p = np.stack([r.ravel(), h.ravel()], axis=1)
        d = np.min([piece.distance(p) for piece in self.pieces], axis=0)
        return d.reshape(r.shape)[()]

    def is_free(self, r, h):
        """조리 공간 안이거나 림보다 높으면 True."""
        r, h = np.broadcast_arrays(np.asarray(r, dtype=float), np.asarray(h, dtype=float))
        r_max, h_top = self.boundary[-1]
        floor = np.interp(r, self.boundary[:, 0], self.boundary[:, 1])
        return (((r <= r_max) & (h >= floor)) | (h >= h_top))[()]

    def signed_distance(self, r, h):
        """경계까지 부호 있는 거리 [m]. + 여유, - 충돌."""
        d = np.asarray(self.distance_to_boundary(r, h))
        return np.where(self.is_free(r, h), d, -d)[()]

    def sphere_clearance(self, r, h, radius):
        """중심이 (r, h) 인 반경 radius 의 구가 경계와 남기는 여유 [m].

        구 중심이 한 단면 위에 있으면 3D 회전면까지의 거리도 이 단면 거리와 같다.
        """
        return (np.asarray(self.signed_distance(r, h)) - radius)[()]

    def tangent_sphere_center(self, h_contact, radius, clearance=0.0):
        """높이 h_contact 의 벽에서 clearance 만큼 떨어져 접하는 구의 중심 (r, h)."""
        arc, alpha = self.wall_arc_at(h_contact)
        k = arc.radius - radius - clearance
        if k <= 0:
            raise ValueError(f'{arc.name} 반경 {arc.radius:.3f} m 가 구 반경 + 여유보다 작습니다.')
        c = arc.center + k * direction(alpha)
        return float(c[0]), float(c[1])

    # -- 국물 ----------------------------------------------------------------

    @property
    def max_volume_L(self):
        return float(self._volume_m3[-1] * 1000)

    def volume_L(self, level_h):
        """수위 level_h 까지 부피 [L]. 벽 끝보다 높으면 nan."""
        return np.interp(np.asarray(level_h, dtype=float), self._volume_h, self._volume_m3 * 1000,
                         left=0.0, right=np.nan)[()]

    def level_for_volume(self, volume_L):
        """국물 volume_L [L] 일 때 수위 [m]. 벽 끝까지 부피보다 많으면 nan."""
        return np.interp(np.asarray(volume_L, dtype=float), self._volume_m3 * 1000, self._volume_h,
                         left=0.0, right=np.nan)[()]

    @property
    def soup_volume_L(self):
        return float(self.operating.get('soup_volume_L', 100.0))

    @property
    def level_h(self):
        """운용 수위 [m]. yaml 의 operating 값, 없으면 soup_volume_L 로 계산."""
        if 'level_h_m' in self.operating:
            return float(self.operating['level_h_m'])
        return float(self.level_for_volume(self.soup_volume_L))

    @property
    def surface_radius(self):
        return float(self.wall_radius(self.level_h))

    def set_surface_z(self, surface_z, source=''):
        """수면 높이 (로봇 base z) 로 운용 수위를 바꾼다. 수면 반경 · 수면 원 판정 · 계획기가 같이 따라간다."""
        bottom = self.placement.get('bottom_z_in_base_m')
        if bottom is None:
            raise RuntimeError('kettle_profile.yaml placement.bottom_z_in_base_m 이 없어 수면 z 를 수위로 바꿀 수 없습니다.')
        level = float(surface_z) - float(bottom)
        if not 0.02 < level < float(self.wall_top[1]):
            raise ValueError(f'수면 z {float(surface_z):+.3f} 는 솥 바닥 위 {level * 1000:.0f} mm 라 벽 범위 밖입니다 '
                             f'({WATER_FILE} 확인).')
        self.operating = dict(self.operating)
        self.operating['level_h_m'] = level
        self.water_source = f'실측 z {float(surface_z):+.3f} (약 {float(self.volume_L(level)):.0f} L)' + (f', {source}' if source else '')

    @property
    def surface_z_in_base(self):
        """지금 수면의 로봇 base z [m]."""
        return float(self.placement['bottom_z_in_base_m']) + self.level_h

    # -- 로봇 좌표 -------------------------------------------------------------

    def base_to_kettle(self, points_base):
        """로봇 base 좌표 [m] → 솥 좌표. placement 의 축 x, y 와 바닥 z 가 있어야 한다."""
        axis = self.placement.get('axis_xy_in_base_m')
        bottom = self.placement.get('bottom_z_in_base_m')
        if axis is None or bottom is None:
            raise RuntimeError('로봇 base 기준 솥 위치가 아직 없습니다. kettle_profile.yaml 의 placement 에 '
                               'axis_xy_in_base_m (솥 축 x, y) 를 채우세요.')
        return np.asarray(points_base, dtype=float) - np.array([axis[0], axis[1], bottom])

    def radial_distance_xy(self, x, y):
        """로봇 base (x, y) 에서 솥 축까지 수평 거리 [m]."""
        p = self.base_to_kettle(np.stack(np.broadcast_arrays(np.asarray(x, dtype=float), np.asarray(y, dtype=float),
                                                              np.zeros(np.shape(x))), axis=-1))
        return np.hypot(p[..., 0], p[..., 1])[()]

    def surface_contains_xy(self, x, y, margin_m=0.0):
        """로봇 base (x, y) 가 운용 수면 원 안, 벽에서 margin_m 이상 안쪽이면 True."""
        return (np.asarray(self.radial_distance_xy(x, y)) <= self.surface_radius - float(margin_m))[()]

    def signed_distance_xyz(self, points, frame='kettle'):
        """3D 점들의 부호 있는 거리. frame 은 'kettle' 또는 'base'."""
        p = np.asarray(points, dtype=float)
        if frame == 'base':
            p = self.base_to_kettle(p)
        elif frame != 'kettle':
            raise ValueError("frame 은 'kettle' 또는 'base' 입니다.")
        return self.signed_distance(np.hypot(p[..., 0], p[..., 1]), p[..., 2])

    def describe(self):
        lines = [f'바닥 평면            r ≤ {self.bottom_flat_radius * 1000:.1f} mm']
        for i, arc in enumerate(self.walls, 1):
            lines.append(f'벽 원호 {i}            R {arc.radius * 1000:.2f} mm, 피벗 (r {arc.center[0] * 1000:.2f}, '
                         f'h {arc.center[1] * 1000:.2f}) mm, h {arc.start[1] * 1000:.1f} ~ {arc.end[1] * 1000:.1f} mm')
        for piece in self.pieces:
            if piece.kind == 'arc' and piece not in self.walls:
                lines.append(f'{piece.name:20s} R {piece.radius * 1000:.2f} mm, 중심 (r {piece.center[0] * 1000:.2f}, '
                             f'h {piece.center[1] * 1000:.2f}) mm')
            elif piece.kind == 'line' and piece.name != 'bottom':
                lines.append(f'{piece.name:20s} 직선 {np.linalg.norm(piece.end - piece.start) * 1000:.1f} mm')
        level = self.level_h
        lines += [
            f'벽 끝 (r, h)          ({self.wall_top[0] * 1000:.1f}, {self.wall_top[1] * 1000:.1f}) mm, 내경 {2 * self.wall_top[0] * 1000:.1f} mm',
            f'림 꼭대기 (r, h)      ({self.rim_top[0] * 1000:.1f}, {self.rim_top[1] * 1000:.1f}) mm',
            f'벽 끝까지 부피        {self.max_volume_L:.1f} L',
            f'운용 수위 ({self.soup_volume_L:.0f} L)     h {level * 1000:.1f} mm, 수면 반경 {self.surface_radius * 1000:.1f} mm, '
            f'벽 기울기 {self.wall_tilt_deg(level):.1f}°',
        ]
        return '\n'.join(lines)


def _self_test(model):
    results = []

    def check(name, got, expected, tol, unit=1000.0, suffix='mm'):
        ok = bool(np.isfinite(got) and abs(got - expected) <= tol)
        results.append(ok)
        print(f'  [{"OK" if ok else "FAIL"}] {name}: {got * unit:+.4f} {suffix} '
              f'(기대 {expected * unit:+.4f} ± {tol * unit:.4f})')

    if model.cad_rings:
        rings = np.array([[r, h] for r, h, _ in model.cad_rings])
        check('CAD 링 → 설계 형상까지 거리 (최대)',
              float(np.abs(model.distance_to_boundary(rings[:, 0], rings[:, 1])).max()), 0.0, 2e-5)

    for lower, upper in zip(model.walls[:-1], model.walls[1:]):
        jump = float(np.degrees(abs(_wrap(lower.angle_of(lower.end) - upper.start_angle))))
        check(f'{lower.name} → {upper.name} 이음점 기울기 차이', jump, 0.0, 1e-3, unit=1.0, suffix='°')

    h = 0.20
    tilt = np.radians(model.wall_tilt_deg(h))
    check('벽에서 수평 10 mm 바깥 → 음수', float(model.signed_distance(model.wall_radius(h) + 0.01, h)),
          -0.01 * np.cos(tilt), 3e-4)

    n_r, n_h = model.inward_normal(h)
    check('벽에서 법선 방향 10 mm 안쪽 → +10 mm',
          float(model.signed_distance(model.wall_radius(h) + 0.01 * n_r, h + 0.01 * n_h)), 0.01, 1e-6)

    cr, ch = model.tangent_sphere_center(h, 0.235, 0.01)
    check('구(반경 235 mm)를 벽에서 10 mm 띄워 배치 → 여유 10 mm',
          float(model.sphere_clearance(cr, ch, 0.235)), 0.01, 1e-6)

    check('수위 → 부피 → 수위 왕복', float(model.level_for_volume(model.volume_L(h))), h, 1e-6)

    if 'level_h_m' in model.operating:
        check('yaml 운용 수위 = 부피로 계산한 수위', float(model.level_for_volume(model.soup_volume_L)),
              float(model.operating['level_h_m']), 2e-5)

    rim_r, rim_h = model.rim_top
    above = float(model.signed_distance(rim_r + 0.05, rim_h + 0.01))
    below = float(model.signed_distance(rim_r + 0.05, rim_h - 0.10))
    ok = above > 0 > below
    results.append(ok)
    print(f'  [{"OK" if ok else "FAIL"}] 림 바깥: 위쪽 {above * 1000:+.1f} mm (여유), 아래쪽 {below * 1000:+.1f} mm (막힘)')
    return all(results)


def main():
    model = KettleModel.from_yaml(water_surface_z=None)      # 자체 점검은 설계 수위 100 L 기준
    print(model.describe())
    print('\n자체 점검')
    return 0 if _self_test(model) else 1


if __name__ == '__main__':
    sys.exit(main())
