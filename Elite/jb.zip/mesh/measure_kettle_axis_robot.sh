#!/usr/bin/env bash
# 로봇 TCP 접촉점으로 솥 중심(base x, y)을 측정하는 읽기 전용 웹 도구.
# 기본 화면: http://127.0.0.1:5001

set -euo pipefail
HERE="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
WS="$HERE"                                  # 워크스페이스: src/RIA_kettle 이 있는 상위 폴더 (이 폴더 위치와 무관)
while [ "$WS" != "/" ] && [ ! -d "$WS/src/RIA_kettle" ]; do WS="$(dirname -- "$WS")"; done

set +u
if [ -f /opt/ros/jazzy/setup.bash ]; then
    # shellcheck disable=SC1091
    source /opt/ros/jazzy/setup.bash
fi
if [ -f "$WS/install/setup.bash" ]; then
    # shellcheck disable=SC1091
    source "$WS/install/setup.bash"
fi
# shellcheck disable=SC1091
[ -f "$HOME/.bash_env" ] && source "$HOME/.bash_env"
set -u

export PYTHONDONTWRITEBYTECODE=1
exec python3 "$HERE/measure_kettle_axis_robot_server.py" "$@"
