#!/usr/bin/env python3
"""로봇 TCP 접촉점으로 솥 회전 중심의 base x, y를 구하는 읽기 전용 웹 도구.

RTSI의 actual_TCP_pose만 읽으며 로봇 이동·전원·브레이크·속도 명령은 보내지
않는다. 사용자가 별도의 조그 화면으로 프로브를 내벽에 접촉시킨 뒤 현재 TCP를
기록한다. STL yaw는 중심 좌표에 적용하지 않는다.
"""

from __future__ import annotations

import argparse
import datetime as dt
import math
import os
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import numpy as np
import yaml
from flask import Flask, jsonify, request, send_from_directory
from scipy.optimize import least_squares

HERE = Path(__file__).resolve().parent
PROFILE_YAML = HERE / 'kettle_profile.yaml'
MEASUREMENT_YAML = HERE / 'kettle_axis_robot_measurement.yaml'
HTML_FILE = HERE / 'robot_axis_measure.html'
RTSI_OUTPUT_RECIPE = HERE / 'rtsi_axis_output_recipe.txt'
RTSI_INPUT_RECIPE = HERE / 'rtsi_axis_input_recipe.txt'


@dataclass(frozen=True)
class AxisConfig:
    robot_ip: str
    cad_wall_radius_m: float
    probe_radius_m: float
    expected_z_m: float
    min_points: int = 6
    min_coverage_deg: float = 120.0
    max_rms_m: float = 0.003
    max_radius_error_m: float = 0.010
    max_z_span_m: float = 0.004
    max_z_error_m: float = 0.005

    @property
    def tcp_path_radius_m(self):
        return self.cad_wall_radius_m - self.probe_radius_m

    def validate(self):
        if not self.robot_ip:
            raise ValueError('robot_ip가 비어 있습니다.')
        if self.cad_wall_radius_m <= 0:
            raise ValueError('CAD 벽 반경은 0보다 커야 합니다.')
        if not 0 <= self.probe_radius_m < self.cad_wall_radius_m:
            raise ValueError('프로브 반경은 0 이상, CAD 벽 반경보다 작아야 합니다.')
        if self.min_points < 3:
            raise ValueError('최소 점 개수는 3 이상이어야 합니다.')


@dataclass(frozen=True)
class CircleFit:
    center: np.ndarray
    radius: float
    residuals: np.ndarray
    coverage_deg: float
    fixed_radius: bool

    @property
    def rms_m(self):
        return float(np.sqrt(np.mean(self.residuals ** 2)))

    @property
    def max_abs_m(self):
        return float(np.max(np.abs(self.residuals)))

    def document(self, probe_radius_m):
        return {
            'center_xy_m': [float(self.center[0]), float(self.center[1])],
            'tcp_path_radius_m': float(self.radius),
            'estimated_wall_radius_m': float(self.radius + probe_radius_m),
            'rms_mm': round(self.rms_m * 1000, 3),
            'max_abs_mm': round(self.max_abs_m * 1000, 3),
            'coverage_deg': round(self.coverage_deg, 2),
            'residuals_mm': [round(float(v) * 1000, 3) for v in self.residuals],
            'fixed_radius': self.fixed_radius,
        }


def coverage_deg(points_xy, center):
    angles = np.sort(np.arctan2(points_xy[:, 1] - center[1], points_xy[:, 0] - center[0]))
    gaps = np.diff(np.r_[angles, angles[0] + 2 * np.pi])
    return float(360.0 - np.degrees(np.max(gaps)))


def fit_circle_free(points_xy):
    """중심과 반경을 모두 맞춘다."""
    points_xy = np.asarray(points_xy, dtype=float).reshape(-1, 2)
    if len(points_xy) < 3:
        return None
    x, y = points_xy.T
    linear, *_ = np.linalg.lstsq(
        np.c_[2 * x, 2 * y, np.ones(len(x))], x * x + y * y, rcond=None)
    c0 = linear[:2]
    r0 = math.sqrt(max(float(linear[2] + c0 @ c0), 1e-12))
    result = least_squares(
        lambda p: np.hypot(x - p[0], y - p[1]) - abs(p[2]),
        [c0[0], c0[1], r0])
    center, radius = result.x[:2], abs(float(result.x[2]))
    residuals = np.hypot(x - center[0], y - center[1]) - radius
    return CircleFit(center, radius, residuals, coverage_deg(points_xy, center), False)


def fit_circle_fixed(points_xy, radius, initial=None):
    """알려진 TCP 궤적 반경을 고정하고 중심만 맞춘다."""
    points_xy = np.asarray(points_xy, dtype=float).reshape(-1, 2)
    if len(points_xy) < 3:
        return None
    x, y = points_xy.T
    start = points_xy.mean(axis=0) if initial is None else np.asarray(initial, dtype=float)
    result = least_squares(lambda c: np.hypot(x - c[0], y - c[1]) - radius, start)
    center = result.x.copy()
    residuals = np.hypot(x - center[0], y - center[1]) - radius
    return CircleFit(center, float(radius), residuals, coverage_deg(points_xy, center), True)


def load_profile(path=PROFILE_YAML):
    """100 L 수면의 벽 반경과 base 기준 수면 z를 읽는다."""
    doc = yaml.safe_load(Path(path).read_text(encoding='utf-8'))
    radius = float(doc['operating']['surface_radius_m'])
    level_h = float(doc['operating']['level_h_m'])
    bottom_z = doc.get('placement', {}).get('bottom_z_in_base_m')
    if bottom_z is None:
        raise ValueError(f'{Path(path).name}: placement.bottom_z_in_base_m가 비어 있습니다.')
    return radius, float(bottom_z) + level_h


class RtsiPoseReader:
    """Elite RTSI의 실제 TCP 자세를 읽기만 하는 연결."""

    def __init__(self, robot_ip, frequency_hz=20.0):
        self.robot_ip = robot_ip
        self.frequency_hz = float(frequency_hz)
        self._io = None
        self._lock = threading.Lock()

    def _connect_locked(self):
        if self._io is not None:
            return
        import elite_cs_sdk as cs
        io = cs.RtsiIOInterface(
            str(RTSI_OUTPUT_RECIPE), str(RTSI_INPUT_RECIPE), self.frequency_hz)
        if not io.connect(self.robot_ip):
            raise ConnectionError(f'RTSI 연결 실패: {self.robot_ip}:30004')
        self._io = io

    def read_pose(self):
        with self._lock:
            try:
                self._connect_locked()
                pose = [float(v) for v in self._io.getActualTCPPose()]
                if len(pose) != 6 or not all(math.isfinite(v) for v in pose):
                    raise RuntimeError(f'유효하지 않은 actual_TCP_pose: {pose}')
                return pose
            except Exception:
                self._disconnect_locked()
                raise

    def _disconnect_locked(self):
        io, self._io = self._io, None
        if io is not None:
            try:
                io.disconnect()
            except Exception:
                pass

    def close(self):
        with self._lock:
            self._disconnect_locked()


class MeasurementSession:
    def __init__(self, config):
        config.validate()
        self.config = config
        self.captures = []
        self.lock = threading.Lock()

    def add_pose(self, pose: Iterable[float]):
        pose = [float(v) for v in pose]
        if len(pose) != 6 or not all(math.isfinite(v) for v in pose):
            raise ValueError('TCP 자세는 유한한 숫자 6개여야 합니다.')
        item = {
            'captured_at': dt.datetime.now().isoformat(timespec='milliseconds'),
            'tcp_pose_base': pose,
        }
        with self.lock:
            self.captures.append(item)
        return item

    def undo(self):
        with self.lock:
            if not self.captures:
                return False
            self.captures.pop()
            return True

    def clear(self):
        with self.lock:
            self.captures.clear()

    def _snapshot(self):
        with self.lock:
            return [dict(item, tcp_pose_base=list(item['tcp_pose_base'])) for item in self.captures]

    def result(self):
        captures = self._snapshot()
        poses = np.array([c['tcp_pose_base'] for c in captures], dtype=float).reshape(-1, 6)
        xyz = poses[:, :3] if len(poses) else np.empty((0, 3))
        free = fit_circle_free(xyz[:, :2])
        fixed = fit_circle_fixed(
            xyz[:, :2], self.config.tcp_path_radius_m,
            None if free is None else free.center)
        warnings = []
        if len(captures) < self.config.min_points:
            warnings.append(f'점이 {len(captures)}개입니다. 최소 {self.config.min_points}개를 기록하세요.')
        if len(xyz):
            z_span = float(np.ptp(xyz[:, 2]))
            z_max_error = float(np.max(np.abs(xyz[:, 2] - self.config.expected_z_m)))
            if z_span > self.config.max_z_span_m:
                warnings.append(f'점들의 z 범위가 {z_span * 1000:.1f}mm입니다. 같은 높이에서 측정하세요.')
            if z_max_error > self.config.max_z_error_m:
                warnings.append(f'기준 높이와 최대 {z_max_error * 1000:.1f}mm 차이 납니다.')
        else:
            z_span = z_max_error = 0.0
        if fixed is not None:
            if fixed.coverage_deg < self.config.min_coverage_deg:
                warnings.append(
                    f'둘레 분포가 {fixed.coverage_deg:.1f}°입니다. '
                    f'{self.config.min_coverage_deg:.0f}° 이상 넓게 찍으세요.')
            if fixed.rms_m > self.config.max_rms_m:
                warnings.append(
                    f'고정 반경 원 맞춤 RMS가 {fixed.rms_m * 1000:.1f}mm입니다. '
                    '접촉이 부정확한 점을 다시 측정하세요.')
        if free is not None:
            radius_error = free.radius + self.config.probe_radius_m - self.config.cad_wall_radius_m
            if abs(radius_error) > self.config.max_radius_error_m:
                warnings.append(
                    f'자유 맞춤 벽 반경이 CAD와 {radius_error * 1000:+.1f}mm 다릅니다. '
                    '프로브 반경과 접촉 위치를 확인하세요.')
        else:
            radius_error = None
        ready = (
            len(captures) >= self.config.min_points
            and fixed is not None
            and fixed.coverage_deg >= self.config.min_coverage_deg
            and fixed.rms_m <= self.config.max_rms_m
            and z_span <= self.config.max_z_span_m
            and z_max_error <= self.config.max_z_error_m
            and radius_error is not None
            and abs(radius_error) <= self.config.max_radius_error_m)
        return {
            'captures': captures,
            'count': len(captures),
            'fixed_fit': None if fixed is None else fixed.document(self.config.probe_radius_m),
            'free_fit': None if free is None else free.document(self.config.probe_radius_m),
            'z_span_mm': round(z_span * 1000, 3),
            'z_max_error_mm': round(z_max_error * 1000, 3),
            'free_radius_error_mm': None if radius_error is None else round(radius_error * 1000, 3),
            'warnings': warnings,
            'ready_to_apply': ready,
        }

    def document(self):
        result = self.result()
        center = None if result['fixed_fit'] is None else result['fixed_fit']['center_xy_m']
        return {
            'measured_at': dt.datetime.now().isoformat(timespec='seconds'),
            'method': '수동 조그한 프로브를 같은 높이의 내벽에 접촉하고 RTSI actual_TCP_pose를 기록한 뒤 원 맞춤',
            'safety': '이 프로그램은 TCP를 읽기만 하며 로봇 이동 명령을 보내지 않는다.',
            'robot': {'ip': self.config.robot_ip, 'frame': 'base'},
            'geometry': {
                'cad_wall_radius_m': self.config.cad_wall_radius_m,
                'probe_radius_m': self.config.probe_radius_m,
                'fixed_tcp_path_radius_m': self.config.tcp_path_radius_m,
                'expected_tcp_z_m': self.config.expected_z_m,
            },
            'quality_limits': {
                'min_points': self.config.min_points,
                'min_coverage_deg': self.config.min_coverage_deg,
                'max_rms_mm': self.config.max_rms_m * 1000,
                'max_radius_error_mm': self.config.max_radius_error_m * 1000,
                'max_z_span_mm': self.config.max_z_span_m * 1000,
                'max_z_error_mm': self.config.max_z_error_m * 1000,
            },
            'captures': result['captures'],
            'fits': {'cad_radius_fixed': result['fixed_fit'], 'radius_free': result['free_fit']},
            'quality': {'ready_to_apply': result['ready_to_apply'], 'warnings': result['warnings']},
            'result': {'axis_xy_in_base_m': center},
        }

    def save(self, path=MEASUREMENT_YAML):
        doc = self.document()
        Path(path).write_text(
            '# measure_kettle_axis_robot.py가 저장한 로봇 TCP 솥 중심 측정 기록.\n'
            + yaml.safe_dump(doc, allow_unicode=True, sort_keys=False), encoding='utf-8')
        return doc

    def apply(self):
        result = self.result()
        if result['fixed_fit'] is None:
            raise ValueError('원을 맞추려면 점이 최소 3개 필요합니다.')
        if not result['ready_to_apply']:
            raise ValueError('품질 기준을 통과하지 않았습니다. 경고를 해결한 뒤 적용하세요.')
        doc = self.save()
        center = doc['result']['axis_xy_in_base_m']
        fit = doc['fits']['cad_radius_fixed']
        note = (
            f"로봇 TCP 내벽 {len(doc['captures'])}점 · 프로브 반경 "
            f"{self.config.probe_radius_m * 1000:.1f} mm · CAD 반경 고정 원 맞춤 · "
            f"RMS {fit['rms_mm']:.2f} mm · 둘레 {fit['coverage_deg']:.1f}° "
            f"({doc['measured_at']}). {MEASUREMENT_YAML.name} 참고.")
        from measure_kettle_axis import apply_to_profile
        apply_to_profile(center, note, PROFILE_YAML)
        return doc


def config_document(config):
    return {
        'robot_ip': config.robot_ip,
        'cad_wall_radius_mm': round(config.cad_wall_radius_m * 1000, 3),
        'probe_radius_mm': round(config.probe_radius_m * 1000, 3),
        'tcp_path_radius_mm': round(config.tcp_path_radius_m * 1000, 3),
        'expected_z_m': round(config.expected_z_m, 6),
        'min_points': config.min_points,
        'min_coverage_deg': config.min_coverage_deg,
        'max_rms_mm': config.max_rms_m * 1000,
        'max_radius_error_mm': config.max_radius_error_m * 1000,
        'max_z_span_mm': config.max_z_span_m * 1000,
        'max_z_error_mm': config.max_z_error_m * 1000,
    }


def create_app(reader, session):
    app = Flask(__name__)

    def current_pose():
        try:
            return reader.read_pose(), ''
        except Exception as exc:
            return None, str(exc)

    @app.get('/')
    def index():
        return send_from_directory(HERE, HTML_FILE.name)

    @app.get('/api/state')
    def state():
        pose, error = current_pose()
        return jsonify({
            'connected': pose is not None, 'connection_error': error,
            'current_pose': pose, 'config': config_document(session.config),
            'measurement': session.result()})

    @app.post('/api/capture')
    def capture():
        pose, error = current_pose()
        if pose is None:
            return jsonify({'ok': False, 'error': error}), 503
        item = session.add_pose(pose)
        return jsonify({'ok': True, 'capture': item, 'measurement': session.result()})

    @app.post('/api/undo')
    def undo():
        return jsonify({'ok': session.undo(), 'measurement': session.result()})

    @app.post('/api/clear')
    def clear():
        session.clear()
        return jsonify({'ok': True, 'measurement': session.result()})

    @app.post('/api/save')
    def save():
        doc = session.save()
        return jsonify({'ok': True, 'path': str(MEASUREMENT_YAML), 'document': doc})

    @app.post('/api/apply')
    def apply():
        body = request.get_json(silent=True) or {}
        if body.get('confirmation') != 'APPLY':
            return jsonify({'ok': False, 'error': '적용 확인값이 올바르지 않습니다.'}), 400
        try:
            doc = session.apply()
        except ValueError as exc:
            return jsonify({'ok': False, 'error': str(exc)}), 400
        return jsonify({'ok': True, 'path': str(PROFILE_YAML),
                        'axis_xy_in_base_m': doc['result']['axis_xy_in_base_m']})
    return app


def self_test():
    results = []

    def check(name, condition, detail):
        ok = bool(condition)
        results.append(ok)
        print(f'  [{"OK" if ok else "FAIL"}] {name}: {detail}')

    truth = np.array([0.742, -0.083])
    cad_radius, probe_radius, expected_z = 0.47414, 0.004, 0.300103
    rng = np.random.default_rng(612)
    angles = np.radians(np.linspace(-65, 160, 10))
    xy = truth + (cad_radius - probe_radius) * np.c_[np.cos(angles), np.sin(angles)]
    xy += rng.normal(0.0, 0.00035, xy.shape)
    z = expected_z + rng.normal(0.0, 0.00025, len(xy))
    config = AxisConfig('127.0.0.1', cad_radius, probe_radius, expected_z)
    session = MeasurementSession(config)
    for (x, y), height in zip(xy, z):
        session.add_pose([x, y, height, 0.0, 0.0, 0.0])
    result = session.result()
    center = np.array(result['fixed_fit']['center_xy_m'])
    error_mm = float(np.linalg.norm(center - truth) * 1000)
    check('알려진 반경 원 중심 복원', error_mm < 1.0, f'중심 오차 {error_mm:.3f}mm')
    check('프로브 반경 보정', abs(result['free_radius_error_mm']) < 1.0,
          f"벽 반경 오차 {result['free_radius_error_mm']:+.3f}mm")
    check('품질 기준 통과', result['ready_to_apply'], ', '.join(result['warnings']) or '경고 없음')

    class FakeReader:
        def read_pose(self):
            return [0.5, 0.1, expected_z, 0.0, 0.0, 0.0]

    app = create_app(FakeReader(), MeasurementSession(config))
    client = app.test_client()
    check('웹 화면', client.get('/').status_code == 200, 'GET /')
    response = client.post('/api/capture')
    check('현재 TCP 기록 API', response.status_code == 200 and response.get_json()['ok'],
          'POST /api/capture')
    blocked = client.post('/api/apply', json={'confirmation': 'APPLY'})
    check('품질 미달 적용 차단', blocked.status_code == 400, f'HTTP {blocked.status_code}')
    return all(results)


def main():
    parser = argparse.ArgumentParser(
        description='로봇 TCP 접촉점으로 솥 중심의 base x, y를 측정하는 읽기 전용 웹 도구')
    parser.add_argument('--ip', default=os.environ.get('ROBOT_IP', '192.168.0.100'))
    parser.add_argument('--host', default='127.0.0.1')
    parser.add_argument('--port', type=int, default=5001)
    parser.add_argument('--probe-radius-mm', type=float, default=0.0,
                        help='구형 프로브 반경. 뾰족한 TCP 포인터는 0')
    parser.add_argument('--wall-radius-mm', type=float,
                        help='측정 높이의 CAD 내벽 반경. 기본은 100 L 수면 반경')
    parser.add_argument('--z-m', type=float,
                        help='측정할 base z. 기본은 100 L 수면 높이')
    parser.add_argument('--self-test', action='store_true')
    args = parser.parse_args()
    if args.self_test:
        print('로봇 TCP 솥 중심 측정 자체 점검')
        return 0 if self_test() else 1

    profile_radius, profile_z = load_profile()
    config = AxisConfig(
        args.ip,
        profile_radius if args.wall_radius_mm is None else args.wall_radius_mm / 1000,
        args.probe_radius_mm / 1000,
        profile_z if args.z_m is None else args.z_m)
    config.validate()
    reader = RtsiPoseReader(args.ip)
    session = MeasurementSession(config)
    app = create_app(reader, session)
    print('로봇 TCP 솥 중심 측정 웹 화면')
    print(f'  http://{args.host}:{args.port}')
    print(f'  로봇: {args.ip}:30004 (RTSI 읽기 전용)')
    print(f'  기준 z: {config.expected_z_m:.6f} m')
    print(f'  CAD 벽 반경: {config.cad_wall_radius_m * 1000:.2f} mm')
    print(f'  프로브 반경: {config.probe_radius_m * 1000:.2f} mm')
    print('  주의: 접촉 전에 조그 동작을 완전히 정지하세요.')
    try:
        app.run(host=args.host, port=args.port, debug=False, threaded=True)
    finally:
        reader.close()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
