# ui/boot_overlay.py
# 부팅 중 / 부팅 실패 오버레이 화면을 담당합니다.

import flet as ft
from config import LABELS


class BootOverlay:
    def __init__(self, page: ft.Page):
        self.page = page
        self._overlay = ft.Container(
            content=ft.Column(
                [
                    ft.ProgressRing(
                        width=80, height=80,
                        stroke_width=8,
                        color=ft.Colors.BLUE,
                    ),
                    ft.Text(
                        LABELS["boot_title"],
                        size=24, weight="bold",
                        color=ft.Colors.BLUE_GREY_700,
                    ),
                    ft.Text(
                        LABELS["boot_subtitle"],
                        size=16,
                        color=ft.Colors.GREY,
                    ),
                ],
                alignment=ft.MainAxisAlignment.CENTER,
                horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            ),
            alignment=ft.Alignment(0, 0),
            bgcolor=ft.Colors.with_opacity(0.8, ft.Colors.WHITE),
            expand=True,
        )

    @property
    def _ring(self):
        return self._overlay.content.controls[0]

    @property
    def _title(self):
        return self._overlay.content.controls[1]

    @property
    def _subtitle(self):
        return self._overlay.content.controls[2]

    def show(self):
        """부팅 중 오버레이를 표시합니다."""
        self._ring.visible = True
        self._title.value  = LABELS["boot_title"]
        self._subtitle.value = LABELS["boot_subtitle"]
        if self._overlay not in self.page.overlay:
            self.page.overlay.append(self._overlay)
        self.page.update()

    def hide(self):
        """오버레이를 숨깁니다."""
        if self._overlay in self.page.overlay:
            self.page.overlay.remove(self._overlay)
            self.page.update()

    def show_failed(self):
        """부팅 실패 오버레이를 표시합니다."""
        self._ring.visible   = False
        self._title.value    = LABELS["boot_fail_title"]
        self._subtitle.value = LABELS["boot_fail_sub"]
        if self._overlay not in self.page.overlay:
            self.page.overlay.append(self._overlay)
        self.page.update()